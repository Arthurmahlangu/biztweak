export const awsConfig = {
    region: 'us-east-1',
    accessKeyId: 'AKIAWZJISUVZHP6ZHV45',
    secretAccessKey: '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'
};