import { current } from "@reduxjs/toolkit";
import { ReactNode } from "react";

export interface IRecomendationBase<T> {
  segment: string;
  userId: string;
  segmentResponses: T;
}

export interface IRecomendation extends IRecomendationBase  <ISegmentResponse> {
    // id : number,
    // created_at : string,
    segment : string,
    userId : string,
    segmentResponses : ISegmentResponse,


}
export interface IUserProfiles extends IRecomendation{
    phase: string
}
// assessment: "AssesSales"
// created_at: "2022-08-04T15:19:12.070428+00:00"
// id: 215
// industry: "Hospitality"
// phase: "I want to sell"
// segment: "customer"
// segmentResponses: {Customer: Array(11), Market: Array(5), Value: Array(5), Activities: Array(1), Resources: Array(1)}
// segmentValues: {customer: {…}, marketSales: {…}, value: {…}, activities: {…}, resources: {…}}
// userId: "9ac6f06d-1a29-4f26-ae76-1dd282875f58"
export interface ISegmentResponse { 
  // BusinessProcess: any
  Customer: Array<Customer>;
  Market: Array<Market>;
  Value: Array<Value>;
  Activities: Array<Activities>;
  Resources: Array<Resources>;
}
export interface Customer {
  key: string;
  value: string;
  type: number;
}
export interface Prototype {
  key: string;
  value: string;
  type: number;
}
export interface Functional {
  key: string;
  value: string;
  type: number;
}
export interface Revenue {
  key: string;
  value: string;
  type: number;
}

export interface Market {
  key: string;
  value: string;
  type: number;
}

export interface Value {
  key: string;
  value: string;
  type: number;
}
export interface Activities {
  key: string;
  value: string;
  type: number;
}

export interface Resources {
  key: string;
  value: string;
  type: number;
}
export interface Cost {
  key: string;
  value: string;
  type: number;
}
export interface Proof {
  key: string;
  value: string;
  type: number;
}
export interface CustomerRelation {
  key: string;
  value: string;
  type: number;
}
export interface Channels {
  key: string;
  value: string;
  type: number;
}
export interface eCommerce {
  key: string;
  value: string;
  type: number;
}
export interface Current {
  key: string;
  value: string;
  type: number;
}
export interface Partners {
  key: string;
  value: string;
  type: number;
}
export interface Traction {
  key: string;
  value: string;
  type: number;
}
export interface Unique {
  key: string;
  value: string;
  type: number;
}
export interface Financial {
  key: string;
  value: string;
  type: number;
}
export interface MarketInt {
  key: string;
  value: string;
  type: number;
}
export interface BusinessCustomers {
  key: string;
  value: string;
  type: number;
}
export interface OwnershipMindset {
  key: string;
  value: string;
  type: number;
}
export interface DeliveryExpertise {
  key: string;
  value: string;
  type: number;
}
export interface CurrentAlternatives {
  key: string;
  value: string;
  type: number;
}
export interface Legal {
  key: string;
  value: string;
  type: number;
}
export interface Compliance {
  key: string;
  value: string;
  type: number;
}
export interface Employee {
  key: string;
  value: string;
  type: number;
}
export interface Growth {
  key: string;
  value: string;
  type: number;
}
export interface BusinessProcess {
  key: string;
  value: string;
  type: number;
}
export interface Commercial {
  key: string;
  value: string;
  type: number;
}
export interface ICompany {
  count: ReactNode;
  userId: string;
  companyName: string;
  location: any;
  phase: string;
  industry: string;
  employees: number;
  monTurnover: number;
  annTurnover: number;
  product: string;
  registered: string;
  registrationNumber: string;
  registrationDate: Date;
  // action: string | undefined;
}

export interface IProfile {
  // id : string,
  display_name: string;
  email: string;
  Role: number;
}

export interface ICustomer extends IRecomendationBase<ICustomerResponse> {
  segment: string;
  userId: string;
  segmentResponses: ICustomerResponse;
}

export interface ICustomerResponse {
  Channels: Array<Channels>;
  Customer: Array<Customer>;
  MarketInt: Array<MarketInt>;
  Cost: Array<Cost>;
}
export interface IFunding extends IRecomendationBase<IFundingResponse> {
  segment: string;
  userId: string;
  segmentResponses: IFundingResponse;
}

export interface IFundingResponse {
  Channels: Array<Channels>;
  Customer: Array<Customer>;
  Revenue: Array<Revenue>;
  Value: Array<Value>;
  Financial: Array<Financial>;
  Proof: Array<Proof>;
}
export interface IConcept extends IRecomendationBase<IConceptResponse> {
  segment: string;
  userId: string;
  segmentResponses: IConceptResponse;
}
export interface IConceptResponse {
  Prototype: Array<Prototype>;
  Functional: Array<Functional>;
  Customer: Array<Customer>;
  Revenue: Array<Revenue>;
  Value: Array<Value>;
  Cost: Array<Cost>;
  Proof: Array<Proof>;
  Resources: Array<Resources>;
}
export interface IStartUp extends IRecomendationBase<IStartUpResponse> {
  segment: string;
  userId: string;
  segmentResponses: IStartUpResponse;
}
export interface IStartUpResponse {
  Prototype: Array<Prototype>;
  Functional: Array<Functional>;
  Customer: Array<Customer>;
  Revenue: Array<Revenue>;
  Value: Array<Value>;
  Cost: Array<Cost>;
  Proof: Array<Proof>;
  Resources: Array<Resources>;
}
export interface INoMoney extends IRecomendationBase<INoMoneyResponse> {
  segment: string;
  userId: string;
  segmentResponses: INoMoneyResponse;
}
export interface INoMoneyResponse {
  CustomerRelation: Array<CustomerRelation>;
  Channels: Array<Channels>;
  eCommerce: Array<eCommerce>;
  Functional: Array<Functional>;
  BusinessCustomers: Array<BusinessCustomers>;
  Customer: Array<Customer>;
  Market: Array<Market>;
  Revenue: Array<Revenue>;
  OwnershipMindset: Array<OwnershipMindset>;
}
export interface IPoor extends IRecomendationBase<IPoorResponse> {
  segment: string;
  userId: string;
  segmentResponses: IPoorResponse;
}
export interface IPoorResponse {
  eCommerce: Array<eCommerce>;
  Customer: Array<Customer>;
  Market: Array<Market>;
  OwnershipMindset: Array<OwnershipMindset>;
  MarketInt: Array<MarketInt>;
  DeliveryExpertise: Array<DeliveryExpertise>;
  Value: Array<Value>;
  Activities: Array<Activities>;
  CurrentAlternatives: Array<CurrentAlternatives>;
  Partners: Array<Partners>;
  Resources: Array<Resources>;
}
export interface IInvestment extends IRecomendationBase<IInvestmentResponse> {
  segment: string;
  userId: string;
  segmentResponses: IInvestmentResponse;
}
export interface IInvestmentResponse {
  Channels: Array<Channels>;
  Functional: Array<Functional>;
  Customer: Array<Customer>;
  BusinessCustomers: Array<BusinessCustomers>;
  Revenue: Array<Revenue>;
  OwnershipMindset: Array<OwnershipMindset>;
  Value: Array<Value>;
  CurrentAlternatives: Array<CurrentAlternatives>;
  Partners: Array<Partners>;
  Commercial: Array<Commercial>;
  Traction: Array<Traction>;
  Financial: Array<Financial>;
  Cost: Array<Cost>;
  Unique: Array<Unique>;
  Growth: Array<Growth>;
  BusinessProcess: Array<BusinessProcess>;
  Employee: Array<Employee>;
  Resources: Array<Resources>;
  Compliance: Array<Compliance>;
  Legal: Array<Legal>;
}
export interface IFullSuit {
  segment: string;
  userId: string;
  segmentResponses: IFullSuitResponse;
}

export interface IFullSuitResponse {
  Prototype: Array<Prototype>;
  Customer: Array<Customer>;
  Revenue: Array<Revenue>;
  Value: Array<Value>;
  Cost: Array<Cost>;
  Proof: Array<Proof>;
  Resourceses: Array<Resources>;
  CustomerRelation: Array<CustomerRelation>;
  Channels: Array<Channels>;
  eCommerce: Array<eCommerce>;
  Activities: Array<Activities>;
  Current: Array<Current>;
  Partners: Array<Partners>;
  Traction: Array<Traction>;
  Unique: Array<Unique>;
}
