import React, { useEffect, useState } from "react";
import { makeStyles, Theme } from '@material-ui/core/styles';
import AppBar from '@material-ui/core/AppBar';
import Tabs from '@material-ui/core/Tabs';
import Tab from '@material-ui/core/Tab';
import Typography from '@material-ui/core/Typography';
import Box from '@material-ui/core/Box';
import TextField from '@material-ui/core/TextField';
import Container from '@material-ui/core/Container';
import { ICompany, IRecomendation } from "../../Interfaces/IRecomendation";
import { Api } from "../../services/endpoints";
import './BlueAsses6.css'


interface TabPanelProps {
  children?: React.ReactNode;
  index: any;
  value: any;
}
function TabPanel(props: TabPanelProps) {
  const { children, value, index, ...other } = props;

  return (
    <div
      role="tabpanel"
      hidden={value !== index}
      id={`scrollable-auto-tabpanel-${index}`}
      aria-labelledby={`scrollable-auto-tab-${index}`}
      {...other}
    >
      {value === index && (
        <Box p={3}>
          <Typography>{children}</Typography>
        </Box>
      )}
    </div>
  );
}


const AllAsses = () => {

  const [allProfiles, setAllProfiles] = useState<ICompany[]>([]);
  const [allProfilesBase, setAllProfilesBase] = useState<ICompany[]>([]);
  const Prof = async () =>{
    const allProfiles = await Api.GET_AllProfiles()
    let result = allProfiles.result? allProfiles.result : [] as ICompany[];
    setAllProfilesBase(result);
    result = result.filter(
     profile => profile.phase == 'We are generating revenue, we would like to grow through investment');
    setAllProfiles(result)
  } 

  useEffect(() => {
    Prof()
  },[]);

  const filterAll = () => {

    const Alldata = _filterAll()
   setAllProfiles(Alldata)
  
   

	}

  const _filterAll = () => {

    let Alldata = allProfilesBase.filter(
      profile => profile.phase == 'I have products/services but I have poor sales');
      return Alldata;
    }
  
    const filterReg = () => {
      const Regdata = _filterReg()
       setAllProfiles(Regdata)
       
    }
  
    const _filterReg = () => {
      let Regdata = allProfilesBase.filter(
        profile =>  profile.registered == 'yes' && profile.phase == 'I have products/services but I have poor sales');
       return Regdata;
       
    }
  
    const filterNon = () => {
    const Nondata = _filterNon()
     setAllProfiles(Nondata)
    }
  
      const _filterNon = () => {
    let Nondata = allProfilesBase.filter(
      profile =>  profile.registered == 'no' && profile.phase == 'I have products/services but I have poor sales');
     return Nondata;
    }
  // const [allRecommendations, setAllRecommendations] = useState<IRecomendation[]>([]);
  // const test = async () => {
  //   const allRecommendations = await Api.GET_AllRecommendations()
  //   const result = allRecommendations.result ? allRecommendations.result : [] as IRecomendation[];
  //   setAllRecommendations(result)
  //   // console.log('reco',allRecommendations)
  // }

  // const [allAsses, setAllAsses] = useState<ICompany[]>([]);
  // const asses = async () => {
  //   const allAsses = await Api.GET_AllProfiles()
  //   const outcome = allAsses.result ? allAsses.result : [] as ICompany[];
  //   setAllAsses(outcome)
  //   console.log('profile', allAsses)
  // }

  // useEffect(() => {
  //   test();
  //   asses();
  // },[]);






  // const classes = useStyles();
  const [value, setValue] = React.useState(0);

  const handleChange = (event: React.ChangeEvent<{}>, newValue: number) => {
    setValue(newValue);
  };



  return (
    <div className="con">
      <Container>
        <div className="Asses">
          <div className="number">
            <Typography className="text">Total Companies</Typography>
          <h1 className="numer">{_filterAll().length}</h1>
          </div>
        </div>
        <div className="Asses">
          <div className="number">
            <Typography className="text">Registered Companies</Typography>
            <h1 className="numer">{_filterReg().length}</h1>
          </div>
        </div>
        <div className="Asses">
          <div className="number">
            <Typography className="text">Non-Registered Companies</Typography>
            <h1 className="numer">{_filterNon().length}</h1>
          </div>
        </div>
      </Container>
    </div>
  )
}

export default AllAsses