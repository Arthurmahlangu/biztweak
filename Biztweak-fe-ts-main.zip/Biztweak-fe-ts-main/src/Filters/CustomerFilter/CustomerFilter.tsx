import React, { useState, useEffect } from "react";
import Grid from "@material-ui/core/Grid";
// import Container from '@material-ui/core/Container';
import { Typography, Button } from "@material-ui/core";
// import HomeIcon from '@material-ui/icons/Home';
import { Link } from 'react-router-dom';
// import SearchBar from "material-ui-search-bar";
import Search from "../../components/topbar/Topbar";
import Side from "../../Admin/AdminComponents/sidebar/Sidebar";
import { Api } from '../../services/endpoints';
import { IProfile, ICompany } from "../../Interfaces/IRecomendation";
import BoxN from "./Box2"
import Blocks from "./BlueAsses2"
import Split from "./SplitFilter"
import ButtonGroup from '@mui/material/ButtonGroup';
import { DataGrid, GridRenderCellParams,GridToolbarExport, GridToolbarContainer} from '@mui/x-data-grid';
import VisibilityIcon from '@mui/icons-material/Visibility';
import EmailIcon from '@mui/icons-material/Email';








  
  


const linkStyle = {
  margin: "1rem",
  textDecoration: "none",
  color: 'white'
};


const CustomerFilter = () => {

  const [allProfiles, setAllProfiles] = useState<ICompany[]>([]);
  const [allProfilesBase, setAllProfilesBase] = useState<ICompany[]>([]);
  const Prof = async () =>{
    const allProfiles = await Api.GET_AllProfiles()
    let result = allProfiles.result? allProfiles.result : [] as ICompany[];
    setAllProfilesBase(result);
    result = result.filter(
     profile => profile.phase == 'I want to learn how to find customers');
    setAllProfiles(result)
  } 

  useEffect(() => {
    Prof()
  },[]);

const filterAll = () => {

  let data = allProfilesBase.filter(
    profile => profile.phase == 'I want to learn how to find customers');
   setAllProfiles(data)
	}

  const filterReg = () => {
    let data = allProfilesBase.filter(
      profile =>   profile.registered == 'yes' && profile.phase == 'I want to learn how to find customers');
     setAllProfiles(data)
	}

  const filterNon = () => {
  let data = allProfilesBase.filter(
    profile => profile.registered == 'no' && profile.phase == 'I want to learn how to find customers');
   setAllProfiles(data)
	}

  function CustomToolbar() {
    return (
      <GridToolbarContainer>
         <GridToolbarExport 
        csvOptions={{
          fileName: 'Get_Custoomer',
          delimiter: ';',
          utf8WithBom: true,
        }}
      />
      </GridToolbarContainer>
    );
  }
 
  return (
    <div>
      <div className="adminCon">
        <div className="adminTop">
          <div className="end">
            {/* <HomeIcon/> */}
          </div>
          <Grid container spacing={2}>
            <Grid item xs={12} sm={12} md={2} lg={2}>
              <Side />
            </Grid>

            <Grid item xs={12} sm={12} md={10} lg={10}>
              <Search />
              <Grid item xs={12} sm={12} md={9} lg={9}>
                <div className="Assesment">
                  <div className="toptop">
                    <BoxN />
                  </div>
                  <div className="filButton1">
                  </div>
                  <div className="wrapper">
                  <div className="proff" >
                      
                      <Button variant="outlined" onClick={() => { filterAll() }}>All</Button>
                      <Button variant="outlined" onClick={() => { filterReg() }}>Registered Business</Button>
	                    <Button variant="outlined" onClick={() => { filterNon() }}>Non Registered Business</Button>

                      <div className="">
                    <Link style={{ color: "silver", textDecoration: "none", cursor: "pointer" }} to='/List'><small>See All Profiles</small> </Link>
                  </div>
                        <div className="list">
                        <div style={{ height: 250, width: '85%' }}>
      <DataGrid
        columns={[
          { field: 'id',
              headerName : 'ID'
            }, 
            { field: 'companyName',
              headerName : 'Company'
            }, 
            { field: 'location',
              headerName : 'Location' 
            },
            { field: 'phase',
              headerName : 'Phase'
            }, 
            { field: 'industry',
            headerName : 'Industry' 
            },
            { field: 'employees',
              headerName : 'Employee'
            },  
            { field: 'annTurnover',
              headerName : 'Turnover'
            },
            { 
              field: 'action',
              headerName : 'Actions',
              renderCell: (params: GridRenderCellParams<number>) => (
              <strong>
                <Link to={`/AdminDash/Company/${params.id}`} style={{}}><VisibilityIcon/></Link>
                <Link to={{pathname:"/UserAdminMail"}} state={{user:params.row}} style={{}}><EmailIcon/></Link> 
              </strong>
            ), 
          },
          
        ]}
        rows={allProfiles}
        components={{
          Toolbar: CustomToolbar,
        }}
      />
    </div>
                        {/* <SellList /> */}
                        </div>
                      </div>
                    </div>
                  </div>  

              </Grid>
              <Grid item xs={12} sm={12} md={3} lg={3}>
                <div className="leftblock"  >
                  <Blocks />
                </div>
              </Grid>


              <div className="filButtons">
              </div>


            </Grid>
          </Grid>

        </div>
      </div>
    </div>
  )

}



export default CustomerFilter