import React, { useState, useEffect } from "react";
import Grid from "@material-ui/core/Grid";
// import Container from '@material-ui/core/Container';
import { Typography, Button } from "@material-ui/core";
// import HomeIcon from '@material-ui/icons/Home';
import { Link } from 'react-router-dom';
// import SearchBar from "material-ui-search-bar";
// import Search from "../components/topbar/Topbar";
// import Side from "../Admin/AdminComponents/sidebar/Sidebar";
// import List from "./List";
// import { Api } from '../services/endpoints';
// import { IProfile, IRecomendation } from "../Interfaces/IRecomendation";
// import { BarChart, Bar, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
// // import Icon from '@material-ui/core/Icon';
// import Details from './AdminComponents/featuredInfo/WidgetSm'
// import MailIcon from '@mui/icons-material/Mail';
// import CheckCircleIcon from '@mui/icons-material/CheckCircle';
// import CancelIcon from '@mui/icons-material/Cancel';
// import OpenWithIcon from '@mui/icons-material/OpenWith';
// import GroupIcon from '@mui/icons-material/Group';
// import AddShoppingCartIcon from '@mui/icons-material/AddShoppingCart';
// import GroupsIcon from '@mui/icons-material/Groups';
// import PaidIcon from '@mui/icons-material/Paid';
// import { supabase } from "../supabaseClient";
// import IProfiles from '../Admin/AdminComponents/featuredInfo/profile';
// import Bargraph from "../Admin/AdminComponents/Charts/Bar";
// import Bargraph2 from "../Admin/AdminComponents/Charts/Bar2";
// import AddCircleIcon from '@mui/icons-material/AddCircle';
// import AssistantPhotoIcon from '@mui/icons-material/AssistantPhoto';


// const linkStyle = {
//   margin: "1rem",
//   textDecoration: "none",
//   color: 'white'
// };

// const buttonStyle = {
//   textDecoration: "none",
//   color: 'white'
// };


// const textStyle={
//     margin: "0px",
//   }

// const SellFilter = () => {
//   const [allRecommendations, setAllRecommendations] = useState<IRecomendation[]>([]);
//   const [profile, setProfile] = useState([] as IProfile[]);
//   const test = async () => {
//     const allRecommendations = await Api.GET_AllRecommendations()
//     const result = allRecommendations.result ? allRecommendations.result : [] as IRecomendation[];
//     result.forEach((recommendation:any) => {
//       recommendation.completed = true;
//       for (const key in recommendation.segmentResponses) {
//           recommendation.segmentResponses[key].forEach((response: any) => {
//             if(response.answered === false) {
//               recommendation.completed = false;
//             }
//           })
//         }
//   });
//     setAllRecommendations(result)

//   }

//   const getProfiles = async () => {
//     try {
//       const user = supabase.auth.user()

//       let { data, error, status } = await supabase
//         .from('profile')
//         .select()

//       if (error && status !== 406) {
//         throw error
//       }

//       if (data) {

//         setProfile(data as IProfile[])
//         console.log('Kenny test ', data)
//       }
//     } catch (error) {
//     } finally {
//     }
//   }
  
//   useEffect(() => {
//     test()
//     // getUsers()
//     getProfiles();

//   });


//   //GetEmail
  
//   const user = supabase.auth.user();
//   const email = user?.email;
//   console.log("Admin email", email)
  
//   const data = [
//     {
//       name: 'Customer',
//       //   uv: 4000,
//       pv: 2400,
//       amt: 2400,
//     },
//     {
//       name: 'Page B',
//       //   uv: 3000,
//       pv: 1398,
//       amt: 2210,
//     },
//     {
//       name: 'Page C',
//       //   uv: 2000,
//       pv: 9800,
//       amt: 2290,
//     },
//     {
//       name: 'Page D',
//       //   uv: 2780,
//       pv: 3908,
//       amt: 2000,
//     },
//     {
//       name: 'Page E',
//       //   uv: 1890,
//       pv: 4800,
//       amt: 2181,
//     },
//     {
//       name: 'Page F',
//       //   uv: 2390,
//       pv: 3800,
//       amt: 2500,
//     },
//     {
//       name: 'Page G',
//       //   uv: 3490,
//       pv: 4300,
//       amt: 2100,
//     },
//     {
//       name: 'Page F',
//       //   uv: 2390,
//       pv: 3800,
//       amt: 2500,
//     },
//     {
//       name: 'Page G',
//       //   uv: 3490,
//       pv: 4300,
//       amt: 2100,
//     },
//   ];
//   const data2 = [
//     {
//       name: 'Customer',
//       //   uv: 4000,
//       pv: 4400,
//       amt: 2400,
//     },
//     {
//       name: 'Page B',
//       //   uv: 3000,
//       pv: 1398,
//       amt: 2210,
//     },
//   ];




//   return (
//     <div>
//       <div className="adminCon">
//         <div className="adminTop">
//           <div className="end">
//             {/* <HomeIcon/> */}
//           </div>
//           <Grid container spacing={2}>
//             <Grid item xs={12} sm={12} md={2} lg={2}>
//               <Side />
//             </Grid>

//             <Grid item xs={12} sm={12} md={10} lg={10}>
//               <Search />
//               <div className="Assesments">
//                 <div className="fitplease">
//                   <div className="widgetblk">
//                     <Typography className="num"><CheckCircleIcon className="checklogo"></CheckCircleIcon>{allRecommendations.filter((r: any) => r.completed).length}</Typography>
//                     <div>
//                     <h3 className="word">Completed Assesments</h3>
//                     </div>
//                   </div>
//                   <div className="widgetblk">
//                     <Typography className="num"><CancelIcon className="crosslogo"/>{allRecommendations.filter((r: any) => !r.completed).length}</Typography>
//                     <h3 className="word">Incomplete Assesments</h3>
//                   </div>

//                   <div className="widgetblk">
//                     <Typography className="num"><OpenWithIcon className="movelogo"/>{allRecommendations.length}</Typography>
//                     <h3 className="word">Total Assesments</h3>
//                   </div>
//                   <div className="widgetblk">
//                     <Typography className="num"><GroupIcon className="grouplogo"/>{profile.length}</Typography>
//                     <h3 className="word">Total Users</h3>
//                   </div>
//                 </div>
//                 <div className="fitplease">
//                   <div className="Usersnew">
//                     <div className="ViewMoreU">
//                     <h4> <Link to='/AdminUserList' >New Users {'>'}</Link></h4>
//                     </div>
//                     <div className="new">
//                     <Details/>
//                     </div>

//                   </div>
//                 </div>
//               </div>

//               <div className="overView">
//                 <Typography variant='h3' className="Bar-Title">Overview</Typography>
//                 <div className="bars">
//                   <div className="bar1">
//                     <h3>Business Concept : Bar Graph</h3>
//                     {/* <ResponsiveContainer width="100%" height="100%">
//                       <BarChart
//                         width={400}
//                         height={300}
//                         data={data}
//                         margin={{
//                           top: 5,
//                           right: 30,
//                           left: 10,
//                           bottom: 3,
//                         }}
//                       >
//                         <CartesianGrid strokeDasharray="3 3" />
//                         <Tooltip />
//                         <Bar dataKey="pv" fill="#fd7e14" />
//                       </BarChart>
//                     </ResponsiveContainer> */}
//                   <Bargraph />
//                   </div>
//                   <div className="bar2">
//                   <h3>Business Structure : Bar Graph</h3>
//                     {/* <ResponsiveContainer width="100%" height="100%">
//                       <BarChart
//                         width={400}
//                         height={200}
//                         data={data2}
//                         margin={{
//                           top: 5,
//                           right: 30,
//                           left: 20,
//                           bottom: 5,
//                         }}
//                       >
//                         <CartesianGrid strokeDasharray="3 3" />
//                         <Tooltip />
//                         <Bar dataKey="pv" fill="#28a745" />
//                       </BarChart>
//                     </ResponsiveContainer> */}
//                       <Bargraph2 />

//                   </div>
//                   <div className="buttongrp">
//                 <div className="buttonsend">
//                   <Button
//                     className="sendMail"
//                     variant="outlined"
//                   >
//                     <MailIcon className="icon"/><Link to='/AdminMail' style={buttonStyle}>Send Mail</Link>

//                   </Button>
//                   <div className="phaseBTNs">
//                     <div className="Phase2">
//                       <Button
//                         className="phase1BTN"
//                         variant="outlined"
//                       ><Link to='/SellFilter' style={buttonStyle}><div>< AddShoppingCartIcon/></div><div className="texts"><h5 style={textStyle}>How To Sell</h5></div></Link>

//                       </Button>
//                     </div>
//                     <div className="Phase2">
//                       <Button
//                         className="phase1BTN"
//                         variant="outlined"
//                       ><Link to='/FundingFilter' style={buttonStyle}><div>< PaidIcon /></div><div className="texts"><h5 style={textStyle}>Get Funding</h5></div>
//                       </Link></Button>
//                     </div>
//                     <div className="phase2">
//                       <Button
//                         className="phase1BTN"
//                         variant="outlined"
//                       ><Link to='/AdminMail' style={linkStyle}><div><GroupsIcon /></div>
//                       <div className="texts"><h5 style={textStyle}>Get Customers</h5></div></Link>
//                       </Button>
//                     </div>

//                   </div>
//                 </div>
//               </div>
//                 </div>
//               </div>
              
//               <div className="filButtons">
//                 <div className="newUsersBTN">
//                   <Button
//                     className="AddUsers"
//                     variant="outlined"
//                   >
//                     <Link to='/AdminAdd' style={buttonStyle}><AddCircleIcon/>Add New Users</Link>
//                   </Button>
//                 </div>
//                 <div className="regUsersBTN">
//                   <Button
//                     className="RegUsers"
//                     variant="outlined"
//                   ><GroupsIcon />
//                    <Link to='/AdminUserList' style={buttonStyle}>Total Registered Users</Link>
//                   </Button>
//                 </div>
//                 <div className="regUsersBTN">
//                   <Button
//                     className="RegUsers"
//                     variant="outlined"
//                   >
//                     <Link to='/AllAsses' style={buttonStyle}><AssistantPhotoIcon/>All Assesments</Link>
//                   </Button>
//                 </div>
//               </div>

//               <div className="prof">
//                 <Typography className="proftxt">Profiles by registered</Typography>
//                 <div className="SeeMore">
//                   <Link to='/List'>See All Profiles {'>'}</Link>
//                 </div>
//                 <div className="list">
//                   <List />
//                 </div>

//               </div>
//             </Grid>
//           </Grid>

//         </div>
//       </div>
//     </div>
//   )

// }



// export default SellFilter