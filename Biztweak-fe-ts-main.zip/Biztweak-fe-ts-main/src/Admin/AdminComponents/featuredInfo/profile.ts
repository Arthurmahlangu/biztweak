interface IProfile { 
    id:string, 
    display_name:string,
    email:string,
    Role:number,
    created_at:Date
 }
 
 export default IProfile