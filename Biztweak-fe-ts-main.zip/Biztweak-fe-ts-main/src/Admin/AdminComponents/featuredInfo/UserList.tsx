import React, { useState, useEffect } from "react";
import { Api } from '../../../services/endpoints';
import { DataGrid, GridRenderCellParams } from '@mui/x-data-grid';
import { ICompany } from "../../../Interfaces/IRecomendation";
import { supabase } from '../../../supabaseClient'
import IProfile from './profile'
import VisibilityIcon from '@mui/icons-material/Visibility';
// import DeleteIcon from '@mui/icons-material/Delete';
import { Link } from 'react-router-dom';
import IconButton from '@mui/material/IconButton';
import Stack from '@mui/material/Stack';
import DeleteIcon from '@mui/icons-material/Delete';
import EmailIcon from '@mui/icons-material/Email';

export default function UserList() {
  useEffect(() => {
    getProfiles();
  }, []);


  const [profile, setProfile] = useState([] as IProfile[])
 


  // const handleDelete = (IProfile) => {
  //   setProfile(profile.filter((user) => user.id !== IProfile.id));
  //   console.log(IProfile.id);
  // };

  const getProfiles = async () => {
    try {
      const user = supabase.auth.user()

      let { data, error, status } = await supabase
        .from('profile')
        .select().order('created_at', { ascending: false })

      if (error && status !== 406) {
        throw error
      }

      
        

      if (data) {

        setProfile(data.filter((prof) => prof.Role == 1));
        // setProfile(data as IProfile[])
        console.log('Kenny test ', data)
      }
    } catch (error) {
    } finally {
    }
  }


  return (
    <div className="Header">
      <div style={{ marginLeft: "25px" }}>
        <h1>User Profile List</h1>
        <div>
          <DataGrid style={{ height: '100vh', width: '80%', backgroundColor: "floralwhite" }}
            columns={[
              {
                field: 'id',
                headerName: 'ID'
              },
              {
                field: 'display_name',
                headerName: 'User Name'
              },
              {
                field: 'email',
                headerName: 'Email'
              },
              {
                field: 'Role',
                headerName: 'Role'
              },
              {
                field: 'created_at',
                headerName: 'Date Created'
              },
              { 
                field: 'action',
                headerName : 'Actions',
                renderCell: (params: GridRenderCellParams<number>) => (
                  <strong>
                    {/* <Link to={`/AdminDash/Company/${params.id}`} style={{}}><VisibilityIcon/></Link> */}
                    <Link to={{pathname:"/UserAdminMail"}} state={{user:params.row}} style={{}}><EmailIcon/></Link> 
                  </strong>
                
              ), 
            },
            ]}
            rows={profile}
          />
        </div>
      </div>

    </div>
  );
}