import React, { useState, useEffect } from "react";
import { Api } from '../../../services/endpoints';
import { DataGrid, GridRenderCellParams } from '@mui/x-data-grid';
import { supabase } from '../../../supabaseClient'
import IProfile from './profile'
import VisibilityIcon from '@mui/icons-material/Visibility';
import { Link } from 'react-router-dom';
import IconButton from '@mui/material/IconButton';
import Stack from '@mui/material/Stack';
import DeleteIcon from '@mui/icons-material/Delete';
import EmailIcon from '@mui/icons-material/Email';


export default function AdminList() {
  useEffect(() => {
     getProfiles();
   
  }, []);


  const [profile, setProfile] = useState([] as IProfile[])
  const [customer, setCustomers] = useState([] as IProfile[]);

  const handleDelete = (clickedUser : any ) => {
    debugger;
    console.log(clickedUser);
    setProfile(profile.filter((prof) => prof.id !== clickedUser.id));
    console.log(clickedUser.id);
  };

  

  const getProfiles = async () => {
    try {
      const user = supabase.auth.user()

      let { data, error, status } = await supabase
        .from('profile')
        .select().order('created_at', { ascending: false })

      if (error && status !== 406) {
        throw error
      }

      if (data) {
        setProfile(data.filter((prof) => prof.Role == 2));

        // setProfile(data as IProfile[])
        console.log('Kenny test ', data)
      }
    } catch (error) {
    } finally {
    }
  }


  return (
    <div className="Header">
      <div style={{ marginLeft: "25px" }}>
        <h1>Admin Profile List</h1>
        <div>
          <DataGrid style={{ height: 300, width: '80%', backgroundColor: "floralwhite" }}
            columns={[
              {
                field: 'id',
                headerName: 'ID'
              },
              {
                field: 'display_name',
                headerName: 'User Name'
              },
              {
                field: 'email',
                headerName: 'Email'
              },
              {
                field: 'Role',
                headerName: 'Role'
              },
              {
                field: 'created_at',
                headerName: 'Date Created'
              },
              { 
                field: 'action',
                headerName : 'Actions',
                renderCell: (params: GridRenderCellParams<number>) => (
                <strong>
                  <IconButton >
                   <Link to={{pathname:"/UserAdminMail"}} state={{user:params.row}} style={{}}><EmailIcon/></Link> 
                   </IconButton>
                   {/* <IconButton>
                  <Link to={`/AdminDash/Company/${params.id}`} style={{}}><VisibilityIcon/></Link>
                  </IconButton> */}
                  <IconButton onClick={() => handleDelete(params)}>
                  <DeleteIcon  />
                  </IconButton>
                </strong>
                  

              ), 
            },
            ]}
            rows={profile}
          />
        </div>
      </div>

    </div>
  );
}