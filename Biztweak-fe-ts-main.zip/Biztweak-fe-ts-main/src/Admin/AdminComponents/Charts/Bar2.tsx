import React, { useEffect, useState } from "react";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend
} from "recharts";
import { IRecomendation } from 'src/Interfaces/IRecomendation';
import { Api } from '../../../services/endpoints';


export default function StructureBar() {
      const [allRecommendations, setAllRecommendations] = useState<IRecomendation[]>([]);
      const [graphData, setGraphData] = useState<any>({});
  const test = async () =>{
    const allRecommendations = await Api.GET_AllRecommendations()
    const recommendations = allRecommendations.result? allRecommendations.result : [] as any[];
    console.log('recommendations', recommendations)
    buildGraphData(recommendations);
    setAllRecommendations(recommendations)
  }
  useEffect(() => {
    test()
   
  },[]);

  const buildGraphData = (recommendations: any[]) => {
    const concerpts: any[] = [];
    const structures: any[] = [];

    recommendations.forEach(recommendation => {
      recommendation.completed = true;
      for (const key in recommendation.segmentResponses) {
          recommendation.segmentResponses[key].forEach((response: any) => {
            if(response.answered === false) {
              recommendation.completed = false;
            }
          })
        }
    });

    recommendations.filter((r: any) => r.completed).forEach((recommendation: any) => {
      for (const key in recommendation.segmentResponses) {
        if(recommendation.segmentResponses[key].some((response: any) => response.type === 2)){
          concerpts.push(key);
        }
      }
    });

    const data = {} as any;
    concerpts.forEach(function (x) { data[x] = (data[x] || 0) + 1; });
    setGraphData(data);
  }

  const cleanName = (name: string): string => {
    switch(name) {
      case "BusinessCustomers": return "Business Customers";
      case "Ownership": return "Ownership Mindset";
      case "Market": return "Market and sales";
      case "Financial": return "Financial Management";
      case "Functional": return "Fucntional Capability";
      case "Commercial": return "Legal Commercial Contracts Agreements";
      case "Cost": return "Cost Structure";
      default: return name;
    }
  }

  const data = [] as any;

  for (const key in graphData) {
    const item = {} as any;
    item.name = cleanName(key);
    item.concept = graphData[key]
    data.push(item)
  }


  return (
    <BarChart
      width={300}
      height={300}
      data={data}
      margin={{
        top: 5,
        right: 30,
        left: 20,
        bottom: 80
      }}
      barSize={20}
    >
      <XAxis dataKey="name" scale="point" angle={-45} textAnchor="end" padding={{ left: 10, right: 10 }} />
      <YAxis />
      <Tooltip />
      {/* <Legend /> */}
      <CartesianGrid strokeDasharray="3 3" />
      <Bar dataKey="concept" fill="#018749" background={{ fill: "#eee" }} />
    </BarChart>
  );
}
