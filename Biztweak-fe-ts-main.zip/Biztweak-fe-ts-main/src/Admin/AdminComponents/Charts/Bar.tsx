import React, { useEffect, useState } from "react";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend
} from "recharts";
import { IRecomendation } from 'src/Interfaces/IRecomendation';
import { Api } from '../../../services/endpoints';


export default function ConceptBar() {

  const [allRecommendations, setAllRecommendations] = useState<any[]>([]);
  const [graphData, setGraphData] = useState<any>({});
  const test = async () =>{
      const allRecommendations = await Api.GET_AllRecommendations()
      const recommendations = allRecommendations.result? allRecommendations.result : [] as any[];
      console.log('recommendations', recommendations)
      buildGraphData(recommendations);
      setAllRecommendations(recommendations)
      // setInitialize(true)
  }
  useEffect(() => {
    test()
   
  }, []);

  const buildGraphData = (recommendations: any[]) => {
    const concerpts: any[] = [];
    const structures: any[] = [];

    recommendations.forEach(recommendation => {
      recommendation.completed = true;
      for (const key in recommendation.segmentResponses) {
          recommendation.segmentResponses[key].forEach((response: any) => {
            if(response.answered === false) {
              recommendation.completed = false;
            }
          })
        }
    });

    recommendations.filter((r: any) => r.completed).forEach((recommendation: any) => {
      for (const key in recommendation.segmentResponses) {
        if(recommendation.segmentResponses[key].some((response: any) => response.type === 1)){
          concerpts.push(key);
        }
      }
    });

    const data = {} as any;
    concerpts.forEach(function (x) { data[x] = (data[x] || 0) + 1; });
    setGraphData(data);
  }
    const cleanName = (name: string): string => {
      switch(name) {
        case "CustomerRelation": return "Customer Relation";
        case "keyPartners": return "key Partners";
        case "Unique": return "Unique Selling Point";
        case "BusinessCustomers": return "Business Customers"
        case "Customer": return "Customer Segment"
        case "Value": return "Value Proposition"
        case "Activities": return "Key Activities"
        case "Resources": return "Key Resources"
        case "Revenue": return "Revenue Streams"
        case "Proof": return "Proof of Concept"
        default: return name;
      }
    }
  
    const data = [] as any[];
    for (const key in graphData) {
      const item = {} as any;
      item.name = cleanName(key);
      item.concept = graphData[key]
      data.push(item)
    }
  
  return (
    <BarChart
      width={400}
      height={300}
      data={data}
      margin={{
        top: 5,
        right: 30,
        left: 20,
        bottom: 80
      }}
      barSize={20}
    >
      <XAxis dataKey="name" scale="point" angle={-45} textAnchor="end" padding={{ left: 10, right: 10 }} />
      <YAxis />
      <Tooltip />
      {/* <Legend /> */}
      <CartesianGrid strokeDasharray="3 3" />
      <Bar dataKey="concept" fill="#018749" background={{ fill: "#eee" }} />
    </BarChart>
  );
}
