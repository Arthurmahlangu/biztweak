import React, { useEffect, useState } from "react";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend
} from "recharts";
import { IRecomendation, IRecomendationBase } from 'src/Interfaces/IRecomendation';
import { Api } from '../../../services/endpoints';


export default function Structure() {
      const [allRecommendations, setAllRecommendations] = useState<any[]>([]);
  const test = async () =>{
      const allRecommendations = await Api.GET_AllRecommendations()
      const result = allRecommendations.result? allRecommendations.result : [] as any[];
      setAllRecommendations(result)
      // setInitialize(true)
  }
  useEffect(() => {
    test()
   
  },[]);
  //BusinessProcess Bar
  const filteredBizProcess = allRecommendations[0]?.segmentResponses.BusinessProcess && allRecommendations[0]?.segmentResponses.BusinessProcess.filter((seg : any)=> {
    return seg.value !== "No recommendation"
   
  }) 
  //Market Bar
  const filteredMarkPos = allRecommendations[0]?.segmentResponses.Market && allRecommendations[0]?.segmentResponses.Market.filter((seg : any) => {
    return seg.value !== "No recommendation"
   
  }) 
  //Ownership Mindset
  const filteredOwner = allRecommendations[0]?.segmentResponses.OwnershipMindset && allRecommendations[0]?.segmentResponses.OwnershipMindset.filter((seg : any) => {
    return seg.value !== "No recommendation"
   
  }) 
  //Employee Satisfaction
  const filteredEmployee = allRecommendations[0]?.segmentResponses.Employee && allRecommendations[0]?.segmentResponses.Employee.filter((seg : any) => {
    return seg.value !== "No recommendation"
   
  }) 
  //Functional Capability
  const filteredFunctional = allRecommendations[0]?.segmentResponses.Functional && allRecommendations[0]?.segmentResponses.Functional.filter((seg : any) => {
    return seg.value !== "No recommendation"
   
  }) 
  //BusinessCustomers
  const filteredBusinessCustomers = allRecommendations[0]?.segmentResponses.BusinessCustomers && allRecommendations[0]?.segmentResponses.BusinessCustomers.filter((seg : any) => {
    return seg.value !== "No recommendation"
   
  }) 
  //Growth Strategy

  const filteredGrowth = allRecommendations[0]?.segmentResponses.Growth && allRecommendations[0]?.segmentResponses.Growth.filter((seg : any) => {
    return seg.value !== "No recommendation"
   
  }) 
  //Delivery Expertise
  const filteredDelivery = allRecommendations[0]?.segmentResponses.Delivery && allRecommendations[0]?.segmentResponses.Delivery.filter((seg : any) => {
    return seg.value !== "No recommendation"
   
  }) 
//Compliance
const filteredCompliance = allRecommendations[0]?.segmentResponses.Compliance && allRecommendations[0]?.segmentResponses.Compliance.filter((seg : any) => {
  return seg.value !== "No recommendation"
 
}) 
//Financial Management
const filteredFinancial = allRecommendations[0]?.segmentResponses.Financial && allRecommendations[0]?.segmentResponses.Financial.filter((seg : any) => {
  return seg.value !== "No recommendation"
 
}) 
// constitution

//Commercial

//Labour
const filteredLabour = allRecommendations[0]?.segmentResponses.Labour && allRecommendations[0]?.segmentResponses.Labour.filter((seg : any) => {
  return seg.value !== "No recommendation"
 
})
//reg
 

 
 
    const data = [
  
      {
        name: 'Market',
        structure: typeof filteredMarkPos !== "undefined" ? filteredMarkPos.length : 0 ,
      },
      {
        name: 'Business Process',
        structure: typeof filteredBizProcess !== "undefined" ? filteredBizProcess.length : 0
      },
      {
        name: 'Ownership',
        structure: typeof filteredOwner !== "undefined" ? filteredOwner.length : 0
      },
      { 
        name: 'Employee',
        structure: typeof filteredEmployee !== "undefined" ? filteredEmployee.length : 0
      },
      {
        name: 'Functional',
        structure: typeof filteredFunctional !== "undefined" ? filteredFunctional.length : 0
      },
      {
        name: 'Business Customers',
        structure: typeof filteredBusinessCustomers !== "undefined" ? filteredBusinessCustomers.length : 0
      },
      {
        name: 'Growth Strategy',
        structure: typeof filteredGrowth !== "undefined" ? filteredGrowth.length : 0
      },
      {
        name: 'Delivery',
        structure: typeof filteredDelivery !== "undefined" ? filteredDelivery.length : 0
      },
      {
        name: 'Compliance',
        structure: typeof filteredCompliance !== "undefined" ? filteredCompliance.length : 0
      },
      {
        name: 'Financial',
        structure: typeof filteredFinancial !== "undefined" ? filteredFinancial.length : 0
      },
      {
        name: 'Labour',
        structure: typeof filteredLabour !== "undefined" ? filteredLabour.length : 0
      },
      
    
    
    
    ];
  return (
    <BarChart
      width={370}
      height={300}
      data={data}
      margin={{
        top: 5,
        right: 30,
        left: 20,
        bottom: 80
      }}
      barSize={20}
    >
      <XAxis dataKey="name" scale="point" angle={-45} textAnchor="end" padding={{ left: 10, right: 10 }} />
      <YAxis />
      <Tooltip />
      {/* <Legend /> */}
      <CartesianGrid strokeDasharray="3 3" />
      <Bar dataKey="structure" fill="#FF7518" background={{ fill: "#eee" }} />
    </BarChart>
  );
}
