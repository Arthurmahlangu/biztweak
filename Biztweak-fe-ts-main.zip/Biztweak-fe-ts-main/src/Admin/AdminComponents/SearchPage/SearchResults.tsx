import React, { useState, useEffect } from "react";
import Grid from "@material-ui/core/Grid";
import { Typography, Button } from "@material-ui/core";
import { Link, useLocation, useNavigate } from 'react-router-dom';
import Search from "../../../components/topbar/TopbarFull";
import Side from "../sidebar/Sidebar"
import { DataGrid } from '@mui/x-data-grid';
import { Api } from '../../../services/endpoints';
import { IProfile, IRecomendation } from '../../../Interfaces/IRecomendation';
import './SearchResults.css'


const linkStyle = {
  margin: "1rem",
  textDecoration: "none",
  color: 'white'
};
type searchState = {
	userData: Array <{
    
	}>, 
	companyData: Array<{
    companyName: string
    industry: string
	}>
  }

const SearchResult = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const profileResults = (location.state as searchState)?.userData;
const companyResults = (location.state as searchState)?.companyData;
console.log("profile state", companyResults , location.state )
// console.log("company state", location.state)
  return (
    <div>
      <div className="adminCon">
        <div className="adminTop">
          <div className="end">
            {/* <HomeIcon/> */}
          </div>
          <Grid container spacing={2}>
            <Grid item xs={12} sm={12} md={2} lg={2}>
              <Side />
            </Grid>

            <Grid item xs={12} sm={12} md={10} lg={10}>
              <Search />
                <div className="Userlist">
                <div className="Profile-Con">
                  <h1>User Profile Results</h1>
                  <div style={{ height: '100vh', width: '80%' }}>
                    <DataGrid style={{ height: '100vh', width: '80%' }}
                      columns={[
                        {
                          field: 'id',
                          headerName: 'ID'
                        },
                        {
                          field: 'display_name',
                          headerName: 'User Name'
                        },
                        {
                          field: 'email',
                          headerName: 'Email'
                        },

                      ]}
                      rows={profileResults}
                    />
                  </div>
                </div>
                <div className="Company-Prof">
                  <h1>Company Profile Results</h1>
                  <div style={{ height: '100vh', width: '80%' }}>
                    <DataGrid style={{ height: '100vh', width: '80%' }}
                      columns={[
                        {
                          field: 'id',
                          headerName: 'ID'
                        },
                        {
                          field: 'companyName',
                          headerName: 'User Name'
                        },
                        {
                          field: 'location',
                          headerName: 'Location'
                        },
                        {
                          field: 'phase',
                          headerName: 'Phase'
                        },
                          {
                          field: 'industry',
                          headerName: 'Industry'
                        },

                      ]}
                      rows={companyResults}
                    />
                  </div>
                </div>
              
                </div>
            </Grid>
          </Grid>

        </div>
      </div>
    </div>
  )

}



export default SearchResult