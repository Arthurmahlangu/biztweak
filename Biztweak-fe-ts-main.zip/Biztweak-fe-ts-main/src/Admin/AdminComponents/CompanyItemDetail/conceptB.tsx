import React from 'react';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
} from 'recharts';
import Container from 'react-bootstrap/Container';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';
import { useDispatch, useSelector } from 'react-redux';
import Typography from '@material-ui/core/Typography';
import {
  selectRecomendationState,
  setAllUserRecomendations,
  setSelectedRecomendation,
} from '../../../Slice/createSlice';
// import './chart.css'

interface props {
  selected: any;
}
const data = [
  {
    name: 'Page A',
    uv: 4000,
    pv: 2400,
    amt: 2400,
  },
  {
    name: 'Page B',
    uv: 3000,
    pv: 1398,
    amt: 2210,
  },
  {
    name: 'Page C',
    uv: 2000,
    pv: 9800,
    amt: 2290,
  },
  {
    name: 'Page D',
    uv: 2780,
    pv: 3908,
    amt: 2000,
  },
  {
    name: 'Page E',
    uv: 1890,
    pv: 4800,
    amt: 2181,
  },
  {
    name: 'Page F',
    uv: 2390,
    pv: 3800,
    amt: 2500,
  },
  {
    name: 'Page G',
    uv: 3490,
    pv: 4300,
    amt: 2100,
  },
];

export default function AdminConBar(props: any) {
  let barConceptSep = [] as any[];
  barConceptSep.push(props.selected[0]?.segmentResponses);

  let reData2 = [] as any[];
  if (
    props.selected[0]?.segmentResponses &&
    props.selected[0]?.segmentResponses != null
  ) {
    barConceptSep.forEach((conectList: any) => {
      const j = Object.keys(conectList && conectList).forEach((name: any) => {
        let f = conectList[name].some((cl: any) => cl.type == 1);
        if (f == true) {
          const obj = {} as any;
          obj[name] = conectList[name];
          reData2.push(obj);
        }
      });
    });
  }

  let barData = [] as any[];
  if (props.selected[0]?.segmentResponses != null) {
    barData = reData2.map((data: any) => {
      const convertData = Object.values(data) as any[];

      return convertData ? [0] && convertData[0].length : 0;
    });
  }
  console.log('length', barData);
  let checking = reData2.map((names: any, i: any) => {
    console.log('Right here', names);
    return Object.keys(names);
  });

  let newList = [] as any[];
  let barVal = checking.map((x: any, index: number) => {
    const headList = x.map((head: any) => {
      newList.push(head);
    });
  });
  console.log('find names', newList);
  let barInfoArray = [] as any[];
  if (props.selected[0]?.segmentResponses != null) {
    barInfoArray = Object.keys(reData2);
  }
  // let count   = 0;
  const barKey = newList.map((name: any, index: number) => ({
    name,
    conceptValue: barData[index],
  }));

  return (
    <div className="conceptBG">
      {<pre>{JSON.stringify(barKey)}</pre>}
      <ResponsiveContainer width="95%" height={300}>
        <BarChart
          width={500}
          height={300}
          data={[
            { name: 'Customer', conceptValue: 11 },
            { name: 'Value', conceptValue: 5 },
            { name: 'Activities', conceptValue: 1 },
            { name: 'Resources', conceptValue: 1 },
          ]}
          margin={{
            top: 5,
            right: 30,
            left: 20,
            bottom: 20,
          }}
          barSize={20}
        >
          <XAxis
            dataKey="name"
            angle={-45}
            textAnchor="end"
            padding={{ left: 2, right: 2 }}
          />
          <YAxis />
          <Tooltip />
          {/* <Legend /> */}
          <CartesianGrid strokeDasharray="3 3" />
          <Bar
            dataKey="conceptValue"
            fill="#8884d8"
            background={{ fill: '#eee' }}
          />
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
}
