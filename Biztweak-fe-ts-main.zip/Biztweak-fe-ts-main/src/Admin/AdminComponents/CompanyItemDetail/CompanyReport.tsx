import React, { useState, useEffect } from 'react';
import {
  Container,
  Grid,
  Button,
  Typography,
  Divider,
} from '@material-ui/core';
import { green, pink } from '@mui/material/colors';
import Avatar from '@mui/material/Avatar';
import Box from '@mui/material/Box';
import Card from '@mui/material/Card';
import CardActions from '@mui/material/CardActions';
import CardContent from '@mui/material/CardContent';
import Accordion from '@material-ui/core/Accordion';
import AccordionSummary from '@material-ui/core/AccordionSummary';
import AccordionDetails from '@material-ui/core/AccordionDetails';
import ExpandMoreIcon from '@material-ui/icons/ExpandMore';
import { Api } from '../../../services/endpoints';
import { IRecomendation } from '../../../Interfaces/IRecomendation';
import { useParams } from 'react-router-dom';
import AdminConBar from './conceptB';
import BarStructure from '../../../components/Report/BarStructure';
import { supabase } from '../../../supabaseClient';
import { useDispatch, useSelector } from 'react-redux';
import {
  selectRecomendationState,
  setAllUserRecomendations,
  setSelectedRecomendation,
} from '../../../Slice/createSlice';
import './CompanyReport.css';

const bull = (
  <Box
    component="span"
    sx={{ display: 'inline-block', mx: '2px', transform: 'scale(0.8)' }}
  >
    •
  </Box>
);




const CompanyReport = (props : any) => {
  
  const dispatch = useDispatch();

  const [initialize, setInitialize] = useState(false);
  const user = supabase.auth.user();
  const recommendations: Array<IRecomendation> = [];
  const [allRecommendations, setAllRecommendations] = useState<
    IRecomendation[]
  >([]);
  const [recommendation, setSelectedRecommendations] = useState<any>();
  useEffect(() => {
    !initialize && getReco();
  }, []);

  const getReco = async () => {
  
    setInitialize(true);
    const { data, error } = await supabase.from('Recomendations').select('*');
    const recoData = data;
    console.log("Report userData", data)
    if (data) {
      setSelectedRecommendations(data[0]);
    }
    dispatch(setAllUserRecomendations(recoData));
  };

  const state = useSelector(selectRecomendationState);

  const _setSelectedRecomendation = (selected: any) => {
    dispatch(setSelectedRecomendation(selected));
  };

  const _user = user?.id;
  useEffect(() => {
    getUserData();
  }, []);
  const getUserData = async () => {
    const { data, error } = await supabase
      .from('profile')
      .select(
        `
      id, display_name, Role
  `
      )
      .eq('id', _user);
    const role = data && data[0]?.Role;
    const userName = data && data[0]?.display_name;
  

    return userName;
  };

  const SelectedRecommendation = recommendation;

  let reData = [] as any[];
  if (SelectedRecommendation?.segmentResponses != null) {
    reData.push(SelectedRecommendation.segmentResponses);
    console.log('pushing ReData', SelectedRecommendation?.segmentResponses);
  }
 
  let reData2 = [] as any[];
  reData.forEach((conectList: any) => {
    console.log('c list', conectList);
    const j = Object.keys(conectList).forEach((name: any) => {
      let f = conectList[name].some((cl: any) => cl.type == 1);
      if (f == true) {
        const obj = {} as any;
        obj[name] = conectList[name];
        reData2.push(obj);
      }
    });
  });

  let reData3 = [] as any[];
  reData.forEach((conectList2: any) => {

    const h = Object.keys(conectList2).forEach((name: any) => {
      let g = conectList2[name].some((cl2: any) => cl2.type == 2);
      if (g == true) {
        const obj2 = {} as any;
        obj2[name] = conectList2[name];
        reData3.push(obj2);
      }
    });
  });
  // console.log("ReData list 2", reData3)
  const objectToArray = (obj: any) => Object.assign([], Object.values(obj));
  // console.log("object conversion" , reData)
  // console.log("testing 123", SelectedRecommendation?.segmentResponses)

  let testData = [] as any[];
  if (SelectedRecommendation?.segmentResponses != null) {
    reData2.forEach((a: any) => {
      Object.keys(a).forEach((b: any) => testData.push(b));
    });
    // console.log("testing 123", testData)
  }
  let testData2 = [] as any[];
  if (SelectedRecommendation?.segmentResponses != null) {
    reData3.forEach((a: any) => {
      Object.keys(a).forEach((b: any) => testData2.push(b));
    });
    // console.log("testing 123", testData2)
  }

  // Filtere outputs
  const filteredMark =
    SelectedRecommendation?.segmentResponses?.Market &&
    SelectedRecommendation?.segmentResponses?.Market.filter((seg: any) => {
      return seg.value !== 'No recommendation';
    });

  const filteredCus =
    SelectedRecommendation?.segmentResponses?.Customer &&
    SelectedRecommendation?.segmentResponses?.Customer.filter((seg: any) => {
      return seg.value !== 'No recommendation';
    });

  const filteredFin =
    SelectedRecommendation?.segmentResponses?.Financial &&
    SelectedRecommendation?.segmentResponses?.Financial.filter((seg: any) => {
      return seg.value !== 'No recommendation';
    });
  // console.log("Market list", filteredFin)

  const filteredMarkInt =
    SelectedRecommendation?.segmentResponses?.MarketInt &&
    SelectedRecommendation?.segmentResponses?.MarketInt.filter((seg: any) => {
      return seg.value !== 'No recommendation';
    });
  const filteredChannel =
    SelectedRecommendation?.segmentResponses?.Channel &&
    SelectedRecommendation?.segmentResponses?.Channel.filter((seg: any) => {
      return seg.value !== 'No recommendation';
    });
  const filteredFunctional =
    SelectedRecommendation?.segmentResponses?.Functional &&
    SelectedRecommendation?.segmentResponses?.Functional.filter((seg: any) => {
      return seg.value !== 'No recommendation';
    });
  const filteredCost =
    SelectedRecommendation?.segmentResponses?.Cost &&
    SelectedRecommendation?.segmentResponses?.Cost.filter((seg: any) => {
      return seg.value !== 'No recommendation';
    });
  const filteredBizCust =
    SelectedRecommendation?.segmentResponses?.BusinessCustomers &&
    SelectedRecommendation?.segmentResponses?.BusinessCustomers.filter(
      (seg: any) => {
        return seg.value !== 'No recommendation';
      }
    );
  const filteredRev =
    SelectedRecommendation?.segmentResponses?.Revenue &&
    SelectedRecommendation?.segmentResponses?.Revenue.filter((seg: any) => {
      return seg.value !== 'No recommendation';
    });
  const filteredOwner =
    SelectedRecommendation?.segmentResponses?.OwnershipMindset &&
    SelectedRecommendation?.segmentResponses?.OwnershipMindset.filter(
      (seg: any) => {
        return seg.value !== 'No recommendation';
      }
    );
  const filteredValue =
    SelectedRecommendation?.segmentResponses?.Value &&
    SelectedRecommendation?.segmentResponses?.Value.filter((seg: any) => {
      return seg.value !== 'No recommendation';
    });
  console.log('filter structre', filteredValue);
  const filteredCurrent =
    SelectedRecommendation?.segmentResponses?.CurrentAlternatives &&
    SelectedRecommendation?.segmentResponses?.CurrentAlternatives.filter(
      (seg: any) => {
        return seg.value !== 'No recommendation';
      }
    );
  const filteredPartners =
    SelectedRecommendation?.segmentResponses?.Partners &&
    SelectedRecommendation?.segmentResponses?.Partners.filter((seg: any) => {
      return seg.value !== 'No recommendation';
    });
  const filteredComercial =
    SelectedRecommendation?.segmentResponses?.Commercial &&
    SelectedRecommendation?.segmentResponses?.Commercial.filter((seg: any) => {
      return seg.value !== 'No recommendation';
    });
  const filteredTraction =
    SelectedRecommendation?.segmentResponses?.Traction &&
    SelectedRecommendation?.segmentResponses?.Traction.filter((seg: any) => {
      return seg.value !== 'No recommendation';
    });

  const filteredUnique =
    SelectedRecommendation?.segmentResponses?.Unique &&
    SelectedRecommendation?.segmentResponses?.Unique.filter((seg: any) => {
      return seg.value !== 'No recommendation';
    });
  const filteredGrowth =
    SelectedRecommendation?.segmentResponses?.Growth &&
    SelectedRecommendation?.segmentResponses?.Growth.filter((seg: any) => {
      return seg.value !== 'No recommendation';
    });
  const filteredBusinessProcess =
    SelectedRecommendation?.segmentResponses?.BusinessProcess &&
    SelectedRecommendation?.segmentResponses?.BusinessProcess.filter(
      (seg: any) => {
        return seg.value !== 'No recommendation';
      }
    );
  const filteredEmployee =
    SelectedRecommendation?.segmentResponses?.Employee &&
    SelectedRecommendation?.segmentResponses?.Employee.filter((seg: any) => {
      return seg.value !== 'No recommendation';
    });
  const filteredResources =
    SelectedRecommendation?.segmentResponses?.Resources &&
    SelectedRecommendation?.segmentResponses?.Resources.filter((seg: any) => {
      return seg.value !== 'No recommendation';
    });
  const filteredCompliance =
    SelectedRecommendation?.segmentResponses?.Compliance &&
    SelectedRecommendation?.segmentResponses?.Compliance.filter((seg: any) => {
      return seg.value !== 'No recommendation';
    });
  const filteredLegal =
    SelectedRecommendation?.segmentResponses?.Legal &&
    SelectedRecommendation?.segmentResponses?.Legal.filter((seg: any) => {
      return seg.value !== 'No recommendation';
    });

  return (
    <div className="CompanyReport-con">
      <Container>
        <div className="report">
          <Grid container>
            <Grid item xs={12} sm={12} md={2} lg={2}></Grid>
            <Grid item xs={12} sm={12} md={10} lg={10}>
              <div className="pChart"></div>
              <div className="bGraph">
                <Grid container>
                  <Grid item xs={12} sm={12} md={12} lg={12}>
                    <Accordion>
                      <AccordionSummary
                        expandIcon={<ExpandMoreIcon />}
                        aria-controls="panel1a-content"
                        id="panel1a-header"
                      >
                        <Typography>Business Concept</Typography>
                      </AccordionSummary>
                      <AccordionDetails className="acc-h">
                        <Accordion>
                          <AccordionSummary
                            expandIcon={<ExpandMoreIcon />}
                            aria-controls="panel1a-content"
                            id="panel1a-header"
                          >
                            {/* <Typography>Business Concept</Typography> */}
                          </AccordionSummary>
                          <AccordionDetails className="acc-h">
                            {recommendation ? (
                              <AdminConBar selected={recommendation} />
                            ) : (
                              <></>
                            )}
                          </AccordionDetails>
                        </Accordion>
                        <div className="concept">
                          <Typography variant="h6">Business Concept</Typography>
                          <Accordion>
                            <AccordionSummary
                              expandIcon={<ExpandMoreIcon />}
                              aria-controls="panel1a-content"
                              id="panel1a-header"
                              className="repoAccord"
                            >
                              <Typography>Business Concept</Typography>
                            </AccordionSummary>
                            <AccordionDetails>
                              <div className="list">
                                {reData2 &&
                                  reData2.map((x: any, index1: number) => {
                                    return (
                                      <>
                                        {Object.values(x).map(
                                          (accord: any, index: number) => {
                                            const filtered =
                                              accord &&
                                              accord.filter((seg: any) => {
                                                return (
                                                  seg.value ==
                                                  'No recommendation'
                                                );
                                              });
                                            console.log(
                                              'filtered list',
                                              filtered
                                            );
                                            const total = accord?.length;
                                            const accordPercent = Math.floor(
                                              (filtered?.length * 100) / total
                                            );
                                            console.log(
                                              'accord',
                                              accordPercent
                                            );

                                            return (
                                              <div key={index}>
                                                <Accordion>
                                                  <AccordionSummary
                                                    expandIcon={
                                                      <ExpandMoreIcon />
                                                    }
                                                    aria-controls="panel1a-content"
                                                    id="panel1a-header"
                                                    className="repoAccord"
                                                  >
                                                    <div className="Header">
                                                      <div className="Header1">
                                                        <Typography>
                                                          {testData[index1]}
                                                        </Typography>
                                                      </div>
                                                      <div className="Header2">
                                                        <Typography>
                                                          {accordPercent}
                                                          {'%'}
                                                        </Typography>
                                                      </div>
                                                    </div>
                                                  </AccordionSummary>
                                                  <AccordionDetails>
                                                    <div className="list">
                                                      {accord.map(
                                                        (
                                                          list: any,
                                                          index: number
                                                        ) => {
                                                          const recoColor =
                                                            list.value ===
                                                            'No recommendation'
                                                              ? '#8FBC8B'
                                                              : '#FBCEB1';

                                                          return (
                                                            <div
                                                              className="divider"
                                                              key={index}
                                                            >
                                                              <Accordion>
                                                                <AccordionDetails
                                                                  style={{
                                                                    backgroundColor:
                                                                      recoColor,
                                                                  }}
                                                                >
                                                                  {list.key}
                                                                </AccordionDetails>
                                                              </Accordion>
                                                            </div>
                                                          );
                                                        }
                                                      )}
                                                    </div>
                                                  </AccordionDetails>
                                                </Accordion>
                                              </div>
                                            );
                                          }
                                        )}
                                      </>
                                    );
                                  })}
                              </div>
                            </AccordionDetails>
                          </Accordion>
                          <Typography variant="h5">
                            Business Diagnosis
                          </Typography>
                          <Accordion>
                            <AccordionSummary
                              expandIcon={<ExpandMoreIcon />}
                              aria-controls="panel2a-content"
                              id="panel2a-header"
                              className="repoAccord"
                            >
                              <Typography>Priority Elements</Typography>
                            </AccordionSummary>
                            <AccordionDetails>
                              <div className="list">
                                {reData2.map((x: any, index1: number) => {
                                  return (
                                    <>
                                      {Object.values(x).map(
                                        (accord: any, index: number) => {
                                          const filtered =
                                            accord &&
                                            accord.filter((seg: any) => {
                                              return (
                                                seg.value == 'No recommendation'
                                              );
                                            });
                                          const total = accord?.length;
                                          const accordPercent = Math.floor(
                                            (filtered?.length * 100) / total
                                          );

                                          return (
                                            <div key={index}>
                                              <Accordion>
                                                <AccordionSummary
                                                  expandIcon={
                                                    <ExpandMoreIcon />
                                                  }
                                                  aria-controls="panel1a-content"
                                                  id="panel1a-header"
                                                  className="repoAccord"
                                                >
                                                  <div className="Header">
                                                    <div className="Header1">
                                                      <Typography>
                                                        {testData[index1]}
                                                      </Typography>
                                                    </div>
                                                    <div className="Header2">
                                                      <Typography>
                                                        {accordPercent}
                                                        {'%'}
                                                      </Typography>
                                                    </div>
                                                  </div>
                                                </AccordionSummary>
                                                <AccordionDetails>
                                                  <div className="list">
                                                    {accord.map(
                                                      (
                                                        list: any,
                                                        index: number
                                                      ) => {
                                                        const recoColor =
                                                          list.value ===
                                                          'No recommendation'
                                                            ? '#8FBC8B'
                                                            : '#FBCEB1';
                                                        return (
                                                          <div
                                                            className="divider"
                                                            key={index}
                                                          >
                                                            <Accordion>
                                                              <AccordionDetails
                                                                style={{
                                                                  backgroundColor:
                                                                    recoColor,
                                                                }}
                                                              >
                                                                {list.key}
                                                              </AccordionDetails>
                                                            </Accordion>
                                                          </div>
                                                        );
                                                      }
                                                    )}
                                                  </div>
                                                </AccordionDetails>
                                              </Accordion>
                                            </div>
                                          );
                                          // }else{
                                          //   return null
                                          // }
                                        }
                                      )}
                                    </>
                                  );
                                })}
                              </div>
                            </AccordionDetails>
                          </Accordion>

                          <Accordion>
                            <AccordionSummary
                              expandIcon={<ExpandMoreIcon />}
                              aria-controls="panel2a-content"
                              id="panel2a-header"
                              className="repoAccord"
                            >
                              <Typography>Best Performing Areas</Typography>
                            </AccordionSummary>
                            <AccordionDetails>
                              <div className="list">
                                {reData2.map((x: any, index1: number) => {
                                  return (
                                    <>
                                      {Object.values(x).map(
                                        (accord: any, index: number) => {
                                          const filtered =
                                            accord &&
                                            accord.filter((seg: any) => {
                                              return (
                                                seg.value == 'No recommendation'
                                              );
                                            });
                                          const total = accord?.length;
                                          const accordPercent = Math.floor(
                                            (filtered?.length * 100) / total
                                          );

                                          // if (accord)

                                          if (accordPercent >= 60) {
                                            return (
                                              <div key={index}>
                                                <Accordion>
                                                  <AccordionSummary
                                                    expandIcon={
                                                      <ExpandMoreIcon />
                                                    }
                                                    aria-controls="panel1a-content"
                                                    id="panel1a-header"
                                                    className="repoAccord"
                                                  >
                                                    <div className="Header">
                                                      <div className="Header1">
                                                        <Typography>
                                                          {testData[index1]}
                                                        </Typography>
                                                      </div>
                                                      <div className="Header2">
                                                        <Typography>
                                                          {accordPercent}
                                                          {'%'}
                                                        </Typography>
                                                      </div>
                                                    </div>
                                                  </AccordionSummary>
                                                  <AccordionDetails>
                                                    <div className="list">
                                                      {accord.map(
                                                        (
                                                          list: any,
                                                          index: number
                                                        ) => {
                                                          const recoColor =
                                                            list.value ===
                                                            'No recommendation'
                                                              ? '#8FBC8B'
                                                              : '#FBCEB1';
                                                          return (
                                                            <div
                                                              className="divider"
                                                              key={index}
                                                            >
                                                              <Accordion>
                                                                <AccordionDetails
                                                                  style={{
                                                                    backgroundColor:
                                                                      recoColor,
                                                                  }}
                                                                >
                                                                  {list.key}
                                                                </AccordionDetails>
                                                              </Accordion>
                                                            </div>
                                                          );
                                                        }
                                                      )}
                                                    </div>
                                                  </AccordionDetails>
                                                </Accordion>
                                              </div>
                                            );
                                          } else {
                                            return null;
                                          }
                                        }
                                      )}
                                    </>
                                  );
                                })}
                              </div>
                            </AccordionDetails>
                          </Accordion>

                          <Accordion>
                            <AccordionSummary
                              expandIcon={<ExpandMoreIcon />}
                              aria-controls="panel2a-content"
                              id="panel2a-header"
                              className="repoAccord"
                            >
                              <Typography>Major Gaps</Typography>
                            </AccordionSummary>
                            <AccordionDetails>
                              <div className="list">
                                {reData2.map((x: any, index1: number) => {
                                  return (
                                    <>
                                      {Object.values(x).map(
                                        (accord: any, index: number) => {
                                          const filtered =
                                            accord &&
                                            accord.filter((seg: any) => {
                                              return (
                                                seg.value == 'No recommendation'
                                              );
                                            });
                                          const total = accord?.length;
                                          const accordPercent = Math.floor(
                                            (filtered?.length * 100) / total
                                          );

                                          // if (accord)

                                          if (accordPercent < 60) {
                                            return (
                                              <div key={index}>
                                                <Accordion>
                                                  <AccordionSummary
                                                    expandIcon={
                                                      <ExpandMoreIcon />
                                                    }
                                                    aria-controls="panel1a-content"
                                                    id="panel1a-header"
                                                    className="repoAccord"
                                                  >
                                                    <div className="Header">
                                                      <div className="Header1">
                                                        <Typography>
                                                          {testData[index1]}
                                                        </Typography>
                                                      </div>
                                                      <div className="Header2">
                                                        <Typography>
                                                          {accordPercent}
                                                          {'%'}
                                                        </Typography>
                                                      </div>
                                                    </div>
                                                  </AccordionSummary>
                                                  <AccordionDetails>
                                                    <div className="list">
                                                      {accord.map(
                                                        (
                                                          list: any,
                                                          index: number
                                                        ) => {
                                                          const recoColor =
                                                            list.value ===
                                                            'No recommendation'
                                                              ? '#8FBC8B'
                                                              : '#FBCEB1';
                                                          return (
                                                            <div
                                                              className="divider"
                                                              key={index}
                                                            >
                                                              <Accordion>
                                                                <AccordionDetails
                                                                  style={{
                                                                    backgroundColor:
                                                                      recoColor,
                                                                  }}
                                                                >
                                                                  {list.key}
                                                                </AccordionDetails>
                                                              </Accordion>
                                                            </div>
                                                          );
                                                        }
                                                      )}
                                                    </div>
                                                  </AccordionDetails>
                                                </Accordion>
                                              </div>
                                            );
                                          } else {
                                            return null;
                                          }
                                        }
                                      )}
                                    </>
                                  );
                                })}
                              </div>
                            </AccordionDetails>
                          </Accordion>
                        </div>
                      </AccordionDetails>
                    </Accordion>
                    <Accordion>
                      <AccordionSummary
                        expandIcon={<ExpandMoreIcon />}
                        aria-controls="panel1a-content"
                        id="panel1a-header"
                      >
                        <Typography className="">Business Structure</Typography>
                      </AccordionSummary>
                      <AccordionDetails className="acc-h">
                        <Accordion>
                          <AccordionSummary
                            expandIcon={<ExpandMoreIcon />}
                            aria-controls="panel1a-content"
                            id="panel1a-header"
                          >
                            <Typography className=""></Typography>
                          </AccordionSummary>
                          <AccordionDetails className="acc-h">
                            <BarStructure />
                          </AccordionDetails>
                        </Accordion>
                        <div className="structure">
                          <Typography variant="h6">
                            Business Stucture
                          </Typography>
                          <Accordion>
                            <AccordionSummary
                              expandIcon={<ExpandMoreIcon />}
                              aria-controls="panel1a-content"
                              id="panel1a-header"
                              className="repoAccord"
                            >
                              <Typography>Business Structure</Typography>
                            </AccordionSummary>
                            <AccordionDetails>
                              <div className="list">
                                {reData3 &&
                                  reData3.map((x: any, index: number) => {
                                    return (
                                      <>
                                        {Object.values(x).map(
                                          (accord: any, index: number) => {
                                            const filtered =
                                              accord &&
                                              accord.filter((seg: any) => {
                                                return (
                                                  seg.value ==
                                                  'No recommendation'
                                                );
                                              });
                                            const Empoylent =
                                              accord &&
                                              accord.filter((seg: any) => {
                                                return (
                                                  seg.value ==
                                                  'No recommendation'
                                                );
                                              });
                                            const total = accord?.length;
                                            const accordPercent = Math.floor(
                                              (filtered?.length * 100) / total
                                            );

                                            console.log(
                                              'accord',
                                              accordPercent
                                            );
                                            return (
                                              <div key={index}>
                                                <Accordion>
                                                  <AccordionSummary
                                                    expandIcon={
                                                      <ExpandMoreIcon />
                                                    }
                                                    aria-controls="panel1a-content"
                                                    id="panel1a-header"
                                                    className="repoAccord"
                                                  >
                                                    <div className="Header">
                                                      <div className="Header1">
                                                        <Typography>
                                                          {testData2[index]}
                                                        </Typography>
                                                      </div>
                                                      <div className="Header2">
                                                        <Typography>
                                                          {accordPercent}
                                                          {'%'}
                                                        </Typography>
                                                      </div>
                                                    </div>
                                                  </AccordionSummary>
                                                  <AccordionDetails>
                                                    <div className="list">
                                                      {accord.map(
                                                        (
                                                          list: any,
                                                          index: number
                                                        ) => {
                                                          const recoColor =
                                                            list.value ===
                                                            'No recommendation'
                                                              ? '#8FBC8B'
                                                              : '#FBCEB1';

                                                          return (
                                                            <div
                                                              className="divider"
                                                              key={index}
                                                            >
                                                              <Accordion>
                                                                <AccordionDetails
                                                                  style={{
                                                                    backgroundColor:
                                                                      recoColor,
                                                                  }}
                                                                >
                                                                  {list.key}
                                                                </AccordionDetails>
                                                              </Accordion>
                                                            </div>
                                                          );
                                                        }
                                                      )}
                                                    </div>
                                                  </AccordionDetails>
                                                </Accordion>
                                              </div>
                                            );
                                          }
                                        )}
                                      </>
                                    );
                                  })}
                              </div>
                            </AccordionDetails>
                          </Accordion>
                          <Typography variant="h5">
                            Business Diagnosis
                          </Typography>
                          <Accordion>
                            <AccordionSummary
                              expandIcon={<ExpandMoreIcon />}
                              aria-controls="panel2a-content"
                              id="panel2a-header"
                              className="repoAccord"
                            >
                              <Typography>Priority Elements</Typography>
                            </AccordionSummary>
                            <AccordionDetails>
                              <div className="list">
                                {reData3.map((x: any, index1: number) => {
                                  return (
                                    <>
                                      {Object.values(x).map(
                                        (accord: any, index: number) => {
                                          const filtered =
                                            accord &&
                                            accord.filter((seg: any) => {
                                              return (
                                                seg.value == 'No recommendation'
                                              );
                                            });
                                          const total = accord?.length;
                                          const accordPercent = Math.floor(
                                            (filtered?.length * 100) / total
                                          );

                                          return (
                                            <div key={index}>
                                              <Accordion>
                                                <AccordionSummary
                                                  expandIcon={
                                                    <ExpandMoreIcon />
                                                  }
                                                  aria-controls="panel1a-content"
                                                  id="panel1a-header"
                                                  className="repoAccord"
                                                >
                                                  <div className="Header">
                                                    <div className="Header1">
                                                      <Typography>
                                                        {testData2[index1]}
                                                      </Typography>
                                                    </div>
                                                    <div className="Header2">
                                                      <Typography>
                                                        {accordPercent}
                                                        {'%'}
                                                      </Typography>
                                                    </div>
                                                  </div>
                                                </AccordionSummary>
                                                <AccordionDetails>
                                                  <div className="list">
                                                    {accord.map(
                                                      (
                                                        list: any,
                                                        index: number
                                                      ) => {
                                                        const recoColor =
                                                          list.value ===
                                                          'No recommendation'
                                                            ? '#8FBC8B'
                                                            : '#FBCEB1';
                                                        return (
                                                          <div
                                                            className="divider"
                                                            key={index}
                                                          >
                                                            <Accordion>
                                                              <AccordionDetails
                                                                style={{
                                                                  backgroundColor:
                                                                    recoColor,
                                                                }}
                                                              >
                                                                {list.key}
                                                              </AccordionDetails>
                                                            </Accordion>
                                                          </div>
                                                        );
                                                      }
                                                    )}
                                                  </div>
                                                </AccordionDetails>
                                              </Accordion>
                                            </div>
                                          );
                                          // }else{
                                          //   return null
                                          // }
                                        }
                                      )}
                                    </>
                                  );
                                })}
                              </div>
                            </AccordionDetails>
                          </Accordion>

                          <Accordion>
                            <AccordionSummary
                              expandIcon={<ExpandMoreIcon />}
                              aria-controls="panel2a-content"
                              id="panel2a-header"
                              className="repoAccord"
                            >
                              <Typography>Best Performing Areas</Typography>
                            </AccordionSummary>
                            <AccordionDetails>
                              <div className="list">
                                {reData3.map((x: any, index1: number) => {
                                  return (
                                    <>
                                      {Object.values(x).map(
                                        (accord: any, index: number) => {
                                          const filtered =
                                            accord &&
                                            accord.filter((seg: any) => {
                                              return (
                                                seg.value == 'No recommendation'
                                              );
                                            });
                                          const total = accord?.length;
                                          const accordPercent = Math.floor(
                                            (filtered?.length * 100) / total
                                          );

                                          // if (accord)

                                          if (accordPercent >= 60) {
                                            return (
                                              <div key={index}>
                                                <Accordion>
                                                  <AccordionSummary
                                                    expandIcon={
                                                      <ExpandMoreIcon />
                                                    }
                                                    aria-controls="panel1a-content"
                                                    id="panel1a-header"
                                                    className="repoAccord"
                                                  >
                                                    <div className="Header">
                                                      <div className="Header1">
                                                        <Typography>
                                                          {testData2[index1]}
                                                        </Typography>
                                                      </div>
                                                      <div className="Header2">
                                                        <Typography>
                                                          {accordPercent}
                                                          {'%'}
                                                        </Typography>
                                                      </div>
                                                    </div>
                                                  </AccordionSummary>
                                                  <AccordionDetails>
                                                    <div className="list">
                                                      {accord.map(
                                                        (
                                                          list: any,
                                                          index: number
                                                        ) => {
                                                          const recoColor =
                                                            list.value ===
                                                            'No recommendation'
                                                              ? '#8FBC8B'
                                                              : '#FBCEB1';
                                                          return (
                                                            <div
                                                              className="divider"
                                                              key={index}
                                                            >
                                                              <Accordion>
                                                                <AccordionDetails
                                                                  style={{
                                                                    backgroundColor:
                                                                      recoColor,
                                                                  }}
                                                                >
                                                                  {list.key}
                                                                </AccordionDetails>
                                                              </Accordion>
                                                            </div>
                                                          );
                                                        }
                                                      )}
                                                    </div>
                                                  </AccordionDetails>
                                                </Accordion>
                                              </div>
                                            );
                                          } else {
                                            return null;
                                          }
                                        }
                                      )}
                                    </>
                                  );
                                })}
                              </div>
                            </AccordionDetails>
                          </Accordion>

                          <Accordion>
                            <AccordionSummary
                              expandIcon={<ExpandMoreIcon />}
                              aria-controls="panel2a-content"
                              id="panel2a-header"
                              className="repoAccord"
                            >
                              <Typography>Major Gaps</Typography>
                            </AccordionSummary>
                            <AccordionDetails>
                              <div className="list">
                                {reData3.map((x: any, index1: number) => {
                                  return (
                                    <>
                                      {Object.values(x).map(
                                        (accord: any, index: number) => {
                                          const filtered =
                                            accord &&
                                            accord.filter((seg: any) => {
                                              return (
                                                seg.value == 'No recommendation'
                                              );
                                            });
                                          const total = accord?.length;
                                          const accordPercent = Math.floor(
                                            (filtered?.length * 100) / total
                                          );

                                          // if (accord)

                                          if (accordPercent < 60) {
                                            return (
                                              <div key={index}>
                                                <Accordion>
                                                  <AccordionSummary
                                                    expandIcon={
                                                      <ExpandMoreIcon />
                                                    }
                                                    aria-controls="panel1a-content"
                                                    id="panel1a-header"
                                                    className="repoAccord"
                                                  >
                                                    <div className="Header">
                                                      <div className="Header1">
                                                        <Typography>
                                                          {testData2[index1]}
                                                        </Typography>
                                                      </div>
                                                      <div className="Header2">
                                                        <Typography>
                                                          {accordPercent}
                                                          {'%'}
                                                        </Typography>
                                                      </div>
                                                    </div>
                                                  </AccordionSummary>
                                                  <AccordionDetails>
                                                    <div className="list">
                                                      {accord.map(
                                                        (
                                                          list: any,
                                                          index: number
                                                        ) => {
                                                          const recoColor =
                                                            list.value ===
                                                            'No recommendation'
                                                              ? '#8FBC8B'
                                                              : '#FBCEB1';
                                                          return (
                                                            <div
                                                              className="divider"
                                                              key={index}
                                                            >
                                                              <Accordion>
                                                                <AccordionDetails
                                                                  style={{
                                                                    backgroundColor:
                                                                      recoColor,
                                                                  }}
                                                                >
                                                                  {list.key}
                                                                </AccordionDetails>
                                                              </Accordion>
                                                            </div>
                                                          );
                                                        }
                                                      )}
                                                    </div>
                                                  </AccordionDetails>
                                                </Accordion>
                                              </div>
                                            );
                                          } else {
                                            return null;
                                          }
                                        }
                                      )}
                                    </>
                                  );
                                })}
                              </div>
                            </AccordionDetails>
                          </Accordion>
                        </div>
                      </AccordionDetails>
                    </Accordion>
                    <Accordion>
                      <AccordionSummary
                        expandIcon={<ExpandMoreIcon />}
                        aria-controls="panel1a-content"
                        id="panel1a-header"
                      >
                        <Typography className="">
                          Report Recommendation
                        </Typography>
                      </AccordionSummary>
                      <AccordionDetails className="acc-h">
                        <Grid container spacing={2}>
                          <Grid item xs={12} sm={12} md={12} lg={12}>
                            <Accordion>
                              <AccordionSummary
                                expandIcon={<ExpandMoreIcon />}
                                aria-controls="panel2a-content"
                                id="panel2a-header"
                                className="arcHeader"
                              >
                                <Avatar
                                  sx={{ bgcolor: green[500] }}
                                  className="avatorPosition"
                                ></Avatar>
                                <div className="sectionHeading">
                                  Strategic Planning
                                </div>
                              </AccordionSummary>
                              <AccordionDetails>
                                <div className="list">
                                  {filteredGrowth?.length == 0 ? (
                                    <Typography>
                                      No Strategic Planning Recomendation
                                    </Typography>
                                  ) : (
                                    filteredGrowth?.map((mark: any) => {
                                      return (
                                        <>
                                          <p>{mark.value}</p>
                                        </>
                                      );
                                    })
                                  )}
                                </div>
                              </AccordionDetails>
                            </Accordion>
                            <Accordion>
                              <AccordionSummary
                                expandIcon={<ExpandMoreIcon />}
                                aria-controls="panel2a-content"
                                id="panel2a-header"
                              >
                                <Avatar
                                  sx={{ bgcolor: green[500] }}
                                  className="avatorPosition"
                                ></Avatar>
                                <div className="sectionHeading">
                                  Markerting and Sales
                                </div>
                              </AccordionSummary>
                              <AccordionDetails>
                                <div className="list">
                                  {filteredMark?.length == 0 ? (
                                    <Typography>
                                      No Market and Sales Recomendation
                                    </Typography>
                                  ) : (
                                    filteredMark?.map((mark: any) => {
                                      return (
                                        <>
                                          <p>{mark.value}</p>
                                        </>
                                      );
                                    })
                                  )}
                                </div>
                              </AccordionDetails>
                            </Accordion>
                            <Accordion>
                              <AccordionSummary
                                expandIcon={<ExpandMoreIcon />}
                                aria-controls="panel2a-content"
                                id="panel2a-header"
                              >
                                <Avatar
                                  sx={{ bgcolor: green[500] }}
                                  className="avatorPosition"
                                ></Avatar>
                                <div className="sectionHeading">
                                  Product Development
                                </div>
                              </AccordionSummary>
                              <AccordionDetails>
                                <div className="list">
                                  {filteredValue?.length == 0 ? (
                                    <Typography>
                                      No Strategic Planning Recomendation
                                    </Typography>
                                  ) : (
                                    filteredValue?.map((mark: any) => {
                                      return (
                                        <>
                                          <p>{mark.value}</p>
                                        </>
                                      );
                                    })
                                  )}
                                </div>
                              </AccordionDetails>
                            </Accordion>
                            <Accordion>
                              <AccordionSummary
                                expandIcon={<ExpandMoreIcon />}
                                aria-controls="panel2a-content"
                                id="panel2a-header"
                              >
                                <Avatar
                                  sx={{ bgcolor: green[500] }}
                                  className="avatorPosition"
                                ></Avatar>
                                <div className="sectionHeading">
                                  Financial Managemennt
                                </div>
                              </AccordionSummary>
                              <AccordionDetails>
                                <div className="list">
                                  {filteredFin?.length == 0 ? (
                                    <Typography>
                                      No Financial Management Recomendation
                                    </Typography>
                                  ) : (
                                    filteredFin?.map((mark: any) => {
                                      return (
                                        <>
                                          <p>{mark.value}</p>
                                        </>
                                      );
                                    })
                                  )}
                                </div>
                              </AccordionDetails>
                            </Accordion>
                            <Accordion>
                              <AccordionSummary
                                expandIcon={<ExpandMoreIcon />}
                                aria-controls="panel2a-content"
                                id="panel2a-header"
                              >
                                <Avatar
                                  sx={{ bgcolor: green[500] }}
                                  className="avatorPosition"
                                ></Avatar>
                                <div className="sectionHeading">
                                  Legal + Compliance
                                </div>
                              </AccordionSummary>
                              <AccordionDetails>
                                <Typography>
                                  <div className="list">
                                    {filteredLegal?.length == 0 ? (
                                      <Typography>
                                        No Legal Recomendation
                                      </Typography>
                                    ) : (
                                      filteredLegal?.map((mark: any) => {
                                        return (
                                          <>
                                            <p>{mark.value}</p>
                                          </>
                                        );
                                      })
                                    )}
                                  </div>
                                </Typography>
                              </AccordionDetails>
                            </Accordion>
                          </Grid>
                          <Grid item xs={12} sm={12} md={12} lg={12}>
                            <Accordion>
                              <AccordionSummary
                                expandIcon={<ExpandMoreIcon />}
                                aria-controls="panel2a-content"
                                id="panel2a-header"
                              >
                                <Avatar
                                  sx={{ bgcolor: green[500] }}
                                  className="avatorPosition"
                                ></Avatar>
                                <div className="sectionHeading">
                                  Market Intelligence
                                </div>
                              </AccordionSummary>
                              <AccordionDetails>
                                <div className="list">
                                  {filteredMarkInt?.length == 0 ? (
                                    <Typography>
                                      No Market Intelligence Recomendation
                                    </Typography>
                                  ) : (
                                    filteredMarkInt?.map((mark: any) => {
                                      return (
                                        <>
                                          <p>{mark.value}</p>
                                        </>
                                      );
                                    })
                                  )}
                                </div>
                              </AccordionDetails>
                            </Accordion>

                            <Accordion>
                              <AccordionSummary
                                expandIcon={<ExpandMoreIcon />}
                                aria-controls="panel2a-content"
                                id="panel2a-header"
                              >
                                <Avatar
                                  sx={{ bgcolor: green[500] }}
                                  className="avatorPosition"
                                ></Avatar>
                                <div className="sectionHeading">
                                  Talent Management
                                </div>
                              </AccordionSummary>
                              <AccordionDetails>
                                <div className="list">
                                  {filteredEmployee?.length == 0 ? (
                                    <Typography>
                                      No Talent Management Recomendation
                                    </Typography>
                                  ) : (
                                    filteredEmployee?.map((mark: any) => {
                                      return (
                                        <>
                                          <p>{mark.value}</p>
                                        </>
                                      );
                                    })
                                  )}
                                </div>
                              </AccordionDetails>
                            </Accordion>

                            <Accordion>
                              <AccordionSummary
                                expandIcon={<ExpandMoreIcon />}
                                aria-controls="panel2a-content"
                                id="panel2a-header"
                              >
                                <Avatar
                                  sx={{ bgcolor: green[500] }}
                                  className="avatorPosition"
                                ></Avatar>
                                <div className="sectionHeading">
                                  Business Process Management
                                </div>
                              </AccordionSummary>
                              <AccordionDetails>
                                <Typography>
                                  <div className="list">
                                    {filteredBusinessProcess?.length == 0 ? (
                                      <Typography>
                                        No Business Process Recomendation
                                      </Typography>
                                    ) : (
                                      filteredBusinessProcess?.map(
                                        (bizProcess: any) => {
                                          return (
                                            <>
                                              <p>{bizProcess.value}</p>
                                            </>
                                          );
                                        }
                                      )
                                    )}
                                  </div>
                                </Typography>
                              </AccordionDetails>
                            </Accordion>
                            <Accordion>
                              <AccordionSummary
                                expandIcon={<ExpandMoreIcon />}
                                aria-controls="panel2a-content"
                                id="panel2a-header"
                              >
                                <Avatar
                                  sx={{ bgcolor: green[500] }}
                                  className="avatorPosition"
                                ></Avatar>
                                <div className="sectionHeading">
                                  Employment Opportunities
                                </div>
                              </AccordionSummary>
                              <AccordionDetails>
                                <Typography>
                                  <div className="list">
                                    {filteredMarkInt?.length == 0 ? (
                                      <Typography>
                                        No Strategic Planning Recomendation
                                      </Typography>
                                    ) : (
                                      filteredMarkInt?.map((mark: any) => {
                                        return (
                                          <>
                                            <p>
                                              {mark.value.includes(
                                                'Job Opportunity'
                                              )
                                                ? mark.value
                                                : null}
                                            </p>
                                          </>
                                        );
                                      })
                                    )}
                                  </div>
                                  <div className="list">
                                    {filteredFin?.length == 0 ? (
                                      <Typography>
                                        No Employment opportunity
                                      </Typography>
                                    ) : (
                                      filteredFin?.map((mark: any) => {
                                        return (
                                          <>
                                            <p>
                                              {mark.value.includes(
                                                'Job Opportunity'
                                              )
                                                ? mark.value
                                                : null}
                                            </p>
                                          </>
                                        );
                                      })
                                    )}
                                  </div>
                                </Typography>
                              </AccordionDetails>
                            </Accordion>
                          </Grid>
                        </Grid>
                      </AccordionDetails>
                    </Accordion>
                  </Grid>
                </Grid>
              </div>
              <div className="report-accord"></div>
              <div className="recommendations">
                <div className="recoContainter">
                  {/* <Button
                            variant='outlined'
                             onClick={() => getReco()}
                            >
                                Get
                            </Button> */}
                  <br />
                  {/* <Button
                  variant='outlined'
                >
                  <Link to='/Profile'>Next</Link>
                </Button> */}
                </div>

                <div>{/* <Barspace/> */}</div>
              </div>
            </Grid>
          </Grid>
        </div>
        {/* <div className='foot'>
          <Footernew />
        </div> */}
      </Container>
    </div>
  );
};

export default CompanyReport;
