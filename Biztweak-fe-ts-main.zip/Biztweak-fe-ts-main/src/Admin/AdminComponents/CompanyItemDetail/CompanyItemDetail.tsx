import React, { useEffect, useState } from 'react';
import Typography from '@material-ui/core/Typography';
import Accordion from '@material-ui/core/Accordion';
import AccordionSummary from '@material-ui/core/AccordionSummary';
import AccordionDetails from '@material-ui/core/AccordionDetails';
import ExpandMoreIcon from '@material-ui/icons/ExpandMore';
import './CompanyItemDetail.css';
import { supabase } from '../../../supabaseClient'

interface props {
	id:number
    userId:string
}

const CompanyItemDetail = (props:any) => {
	const [expanded, setExpanded] = React.useState<string | false>(false);
	const [company, setCompany] = useState<any>({}); 
	const GetProfile = async () =>{
	
		let { data, error } = await supabase
		.from('Company')
		.select("*")
		.eq('id', props.id)

    if(error) {
		alert('Could not get company data.')
	}
    if(data){
		setCompany(data[0])
	}
  }  

	const handleChange =
    (panel: string) => (_event: any, isExpanded: boolean) => {
      setExpanded(isExpanded ? panel : false);
    };

	useEffect(() => {
		GetProfile()
	   
	  }, []);

      const IDuser = company?.userId;
      console.log("company user id", IDuser)

	return (
		<div className='itemDetails-con'>
            <Accordion expanded={expanded === '1'} onChange={handleChange('1')}>
                <AccordionSummary
                    expandIcon={<ExpandMoreIcon />}
                    aria-controls="panel1a-content"
                    id="panel1a-header"
                 >
                <Typography className="">ID</Typography>
                </AccordionSummary>
                <AccordionDetails className='acc-h'>
                    {company.id}
                </AccordionDetails>
            </Accordion>
			<Accordion expanded={expanded === '2'} onChange={handleChange('2')}>
                <AccordionSummary
                    expandIcon={<ExpandMoreIcon />}
                    aria-controls="panel1a-content"
                    id="panel1a-header"
                 >
                <Typography className="">COMPANY NAME</Typography>
                </AccordionSummary>
                <AccordionDetails className='acc-h'>
				{company.companyName}
                </AccordionDetails>
            </Accordion>
			<Accordion expanded={expanded === '3'} onChange={handleChange('3')}>
                <AccordionSummary
                    expandIcon={<ExpandMoreIcon />}
                    aria-controls="panel1a-content"
                    id="panel1a-header"
                 >
                <Typography className="">LOCATION</Typography>
                </AccordionSummary>
                <AccordionDetails className='acc-h'>
				{company.location}
                </AccordionDetails>
            </Accordion>
			<Accordion expanded={expanded === '4'} onChange={handleChange('4')}>
                <AccordionSummary
                    expandIcon={<ExpandMoreIcon />}
                    aria-controls="panel1a-content"
                    id="panel1a-header"
                 >
                <Typography className="">PHASE</Typography>
                </AccordionSummary>
                <AccordionDetails className='acc-h'>
				{company.phase}
                </AccordionDetails>
            </Accordion>
			<Accordion expanded={expanded === '5'} onChange={handleChange('5')}>
                <AccordionSummary
                    expandIcon={<ExpandMoreIcon />}
                    aria-controls="panel1a-content"
                    id="panel1a-header"
                 >
                <Typography className="">REGISTERED</Typography>
                </AccordionSummary>
                <AccordionDetails className='acc-h'>
                {company.registered}
                </AccordionDetails>
            </Accordion>
			<Accordion expanded={expanded === '6'} onChange={handleChange('6')}>
                <AccordionSummary
                    expandIcon={<ExpandMoreIcon />}
                    aria-controls="panel1a-content"
                    id="panel1a-header"
                 >
                <Typography className="">INDUSTRY</Typography>
                </AccordionSummary>
                <AccordionDetails className='acc-h'>
				{company.industry}
                </AccordionDetails>
            </Accordion>
			<Accordion expanded={expanded === '7'} onChange={handleChange('7')}>
                <AccordionSummary
                    expandIcon={<ExpandMoreIcon />}
                    aria-controls="panel1a-content"
                    id="panel1a-header"
                 >
                <Typography className="">EMPLOYEES</Typography>
                </AccordionSummary>
                <AccordionDetails className='acc-h'>
				{company.employees}
                </AccordionDetails>
            </Accordion><Accordion expanded={expanded === '8'} onChange={handleChange('8')}>
                <AccordionSummary
                    expandIcon={<ExpandMoreIcon />}
                    aria-controls="panel1a-content"
                    id="panel1a-header"
                 >
                <Typography className="">TURNOVER</Typography>
                </AccordionSummary>
                <AccordionDetails className='acc-h'>
				Annual Turnover: {company.annTurnover}  Month Turnover: {company.monTurnover}
                </AccordionDetails>
            </Accordion>
			<Accordion expanded={expanded === '9'} onChange={handleChange('9')}>
                <AccordionSummary
                    expandIcon={<ExpandMoreIcon />}
                    aria-controls="panel1a-content"
                    id="panel1a-header"
                 >
                <Typography className="">BIZ RATING</Typography>
                </AccordionSummary>
                <AccordionDetails className='acc-h'>
				??
                </AccordionDetails>
            </Accordion>
			<Accordion expanded={expanded === '10'} onChange={handleChange('10')}>
                <AccordionSummary
                    expandIcon={<ExpandMoreIcon />}
                    aria-controls="panel1a-content"
                    id="panel1a-header"
                 >
                <Typography className="">JOB OPPORTUNITIES CREATED</Typography>
                </AccordionSummary>
                <AccordionDetails className='acc-h'>
				??
                </AccordionDetails>
            </Accordion>
			<Accordion expanded={expanded === '11'} onChange={handleChange('11')}>
                <AccordionSummary
                    expandIcon={<ExpandMoreIcon />}
                    aria-controls="panel1a-content"
                    id="panel1a-header"
                 >
                <Typography className="">INTERVENTIONS</Typography>
                </AccordionSummary>
                <AccordionDetails className='acc-h'>
				??
                </AccordionDetails>
            </Accordion>
		</div>
	);
};

export default CompanyItemDetail;
