import React, {useState, useEffect, useCallback} from 'react';
import Typography from '@material-ui/core/Typography';
import TextField from '@material-ui/core/TextField';
import Container from '@material-ui/core/Container';
import { Button, Grid } from '@material-ui/core';
import Select from '@material-ui/core/Select';
import MenuItem from '@material-ui/core/MenuItem';
import './SendMail.css';
import { Editor } from "react-draft-wysiwyg";
import "react-draft-wysiwyg/dist/react-draft-wysiwyg.css";
import * as base from "../../../config";
import { EditorState } from 'draft-js'


import AWS from 'aws-sdk';

const SES = new AWS.SES(base.awsConfig);

const SendMail = (props:any) => {



    const [subject, setSubject] = useState('');
    const [message, setMessage] = useState('');
	const [companyUsers, setCompanyUsers] = useState([]);
	const [isDisabled, setDisabled] = useState(false);

	const [editorState, setEditorState] = useState(EditorState.createEmpty())

	const [users, setUsers] = useState([]);


	const userWithCompanyInfo = props.emailList.map((user:any)=>{
		const userCompany = props.companyList.filter((company:any) =>
		user.id == company.userId
		  );

	
		
		const complete = {...user, company:userCompany}
		return complete
	   
	  })

	  const registered:any = [];
	  const notRegistered:any = [];
	  userWithCompanyInfo.filter((x:any) => {
		  if(x?.company?.length > 0){
			  return x.company.filter((com:any) => {
				  if(com.registered === "no") {
					  notRegistered.push(Object.assign({},com, {email:x.email}))
				  }else{
					  registered.push(Object.assign({},com, {email:x.email}))
				  }
				  
			  }
				  //com.registered === 'yes'}
				  )
		  }
	  });

    const handleUsersChange = (event:any) => {
       event.preventDefault();
        const getKey = (array:any,key:any) => array.map((a:any) => a[key]);
		if(event.target.value === 0){
			setUsers(getKey(userWithCompanyInfo, 'email'));
		}
		if(event.target.value === 1){
			setUsers(getKey(registered,'email'))
		}

		if(event.target.value === 2){
			setUsers(getKey(notRegistered,'email'))
		}
        
    }

	const handleChangeSubject = (event:any) => {
		console.log("event", event)
        setSubject(event.target.value)
    }


	const onEditorStateChange = useCallback(
		(rawcontent:any) => {
			console.log("rawcontent",rawcontent, message)
		  setEditorState(rawcontent.blocks[0].text);
		},
		[editorState]
	  );

	  let uniqueUsers = users.filter((c, index) => {
		return users.indexOf(c) === index;
	});

	//console.log("Unique", uniqueUsers)

	const handleEmail = (event:any) => {
		setDisabled(true)
		event.preventDefault();
		setMessage('Sending Mail...');
        const emails = uniqueUsers;

        let params = {
            Source: 'hello@biztweak.org.za',
            Destination: {
              ToAddresses: emails,
            },
            ReplyToAddresses: ['hello@biztweak.org.za'],
            Message: {
              Body: {
                Html: {
                  Charset: 'UTF-8',
                  Data: `
                    <html>
                      <p> ${editorState} <p/>
                    </html>
                  `,
                },
              },
              Subject: {
                Charset: 'UTF-8',
                Data: `${subject}`,
              },
            },
          };
    
          const emailSent = SES.sendEmail(params).promise();
          emailSent
          .then((data) => {
			setMessage('Email sent successfully')
            console.log(data);
			setMessage('');
          })
          .catch((err) => {
			setMessage('');
            console.log(err);
          });
    }

	return (
		<div className="send-con">
			{/* <sideNav/> */}
			{/* <Grid lg={2}><p></p></Grid> */}
			<Grid lg={8} style={{ marginLeft: "10%", marginTop: "5%" }}>
				<div className="send">
					<div className="filter">
						<Typography>Filter {(users.length > 0 ? users.length : '')}</Typography>
						<Select
							style={{ padding: "10px !important" }}
							labelId="demo-simple-select-label"
							id="demo-simple-select"
							fullWidth
							variant="outlined"
						// value={age}
						    onChange={handleUsersChange}
						>
							<MenuItem value={0}>All Users</MenuItem>
							<MenuItem value={1}>Registered Business users</MenuItem>
							<MenuItem value={2}>None Registered Business users</MenuItem>
							{/* <MenuItem value={3}>Idea/Concept phase users</MenuItem>
							<MenuItem value={4}>Early Stage phase users</MenuItem>
							<MenuItem value={5}>Startup phase users</MenuItem>
							<MenuItem value={6}>Accelerate phase users</MenuItem> */}
						</Select>
					</div>
					<div className="subject">
						<Typography>Subject</Typography>
						<TextField size="small" fullWidth variant="outlined" className="subjectTypo" 
						onChange={(e) => handleChangeSubject(e)}
						/>
					</div>
					<div className="emailContent">
						<Typography>Email Content</Typography>
						{/* <TextField fullWidth variant="outlined" multiline maxRows={30} /> */}
						<Editor
								toolbarClassName="toolbarClassName"
								wrapperClassName="wrapperClassName"
								editorClassName="editorClassName"
								onChange={onEditorStateChange}
						/>
					</div>
					<h4>{message}</h4>
					<Button className="mailBtn" variant="outlined" style={{ marginTop: "5%" }} onClick={(e) => handleEmail(e)} disabled={isDisabled}>
						Send
					</Button>
				</div>
			</Grid >
			{/* <Grid lg={2}><p></p></Grid> */}
		</div >
	);
};

export default SendMail;
