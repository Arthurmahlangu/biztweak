import React from 'react'
import './TotRegistered.css'




const Registered = () => {


}

export default Registered