import React, { useState, useEffect } from "react";
import Grid from "@material-ui/core/Grid";
// import Container from '@material-ui/core/Container';
import { Typography, Button } from "@material-ui/core";
// import HomeIcon from '@material-ui/icons/Home';
import { Link } from 'react-router-dom';
// import SearchBar from "material-ui-search-bar";
import { supabase } from "../../src/supabaseClient";
import Search from "../components/topbar/TopbarFull";
import AdminMail from "../Admin/AdminComponents/SendMail/SendMail";
import Side from "./AdminComponents/sidebar/Sidebar";
import UserList from "./List";
import { Api } from '../services/endpoints';
import { IProfile, IRecomendation, ICompany } from "../Interfaces/IRecomendation";
import './AdminMail.css';


const linkStyle = {
  margin: "1rem",
  textDecoration: "none",
  color: 'white'
};


const AdminMai = () => {
  const [allRecommendations, setAllRecommendations] = useState<IRecomendation[]>([]);
  const [allProfiles, setAllProfiles] = useState<IProfile[]>([]);
  const [emails, setEmails] = useState([] as IProfile[]);
  const [companies, setCompanies] = useState([] as ICompany[]);
  const test = async () => {
    const allRecommendations = await Api.GET_AllRecommendations()
    const result = allRecommendations.result ? allRecommendations.result : [] as IRecomendation[];
    setAllRecommendations(result)

  }

  const getProfiles = async () => {
    try {
      const user = supabase.auth.user()

      let { data, error, status } = await supabase
        .from('profile')
        .select()

      if (error && status !== 406) {
        throw error
      }

      if (data) {
       
        // const getKey = (array:any,key:any) => array.map((a:any) => a[key]);
        // getKey(data,'email')
       // console.log("New",  getKey(data,'email'));
        setEmails(data)
      }
    } catch (error) {
    } finally {
    }
  }
  const getCompanies = async () => {
    try {
      const user = supabase.auth.user()

      let { data, error, status } = await supabase
        .from('Company')
        .select()

      if (error && status !== 406) {
        throw error
      }

      if (data) {
        setCompanies(data)
      }
    } catch (error) {
    } finally {
    }
  }

  useEffect(() => {
    getProfiles();
    getCompanies();
  }, [])

  return (
    <div>
      <div className="adminCon">
        <div className="adminTop">
          <div className="end">
            {/* <HomeIcon/> */}
          </div>
          <Grid container spacing={2}>
            <Grid item xs={12} sm={12} md={2} lg={2}>
              <Side />
            </Grid>

            <Grid item xs={12} sm={12} md={10} lg={10}>
              <Search />
                <div className="Emailform">
               
        <h1>Send mail to users</h1>
 
                  <AdminMail  emailList={emails} companyList={companies}/>
              
                </div>
            </Grid>
          </Grid>

        </div>
      </div>
    </div>
  )

}



export default AdminMai