import React, {  } from "react";
import Grid from "@material-ui/core/Grid";
// import Container from '@material-ui/core/Container';
// import HomeIcon from '@material-ui/icons/Home';
import { useParams } from 'react-router-dom';
// import SearchBar from "material-ui-search-bar";
import Search from "../components/topbar/TopbarFull";
import Side from "./AdminComponents/sidebar/Sidebar";
import './AdminCompany.css';
import CompanyItemDetail from "./AdminComponents/CompanyItemDetail/CompanyItemDetail";
import CompanyReport from "./AdminComponents/CompanyItemDetail/CompanyReport";



const AdminCompany = () => {
    const { id } = useParams();
    const { userId } = useParams();
    // const IDuser = company?.userId;
    console.log("Admincompany userid", userId)

  return (
    <div>
      <div className="adminCon">
        <div className="adminTop">
          <div className="end">
            {/* <HomeIcon/> */}
          </div>
          <Grid container spacing={2}>
            <Grid item xs={12} sm={12} md={2} lg={2}>
              <Side />
            </Grid>

            <Grid item xs={12} sm={12} md={10} lg={10}>
              <Search />
                <div className="Userlist">
                <Grid container spacing={2}>
                <Grid item xs={12} sm={12} md={6} lg={6}>
                <CompanyReport />
                </Grid>
                <Grid item xs={12} sm={12} md={6} lg={6}>
               <CompanyItemDetail id={id} />
         
                </Grid>
                </Grid>
                </div>
            </Grid>
          </Grid>

        </div>
      </div>
    </div>
  )

}



export default AdminCompany