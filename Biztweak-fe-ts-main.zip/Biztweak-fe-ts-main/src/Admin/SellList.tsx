import React , { useState, useEffect } from "react";
import { Api } from '../services/endpoints';
import { DataGrid } from '@mui/x-data-grid';
import { ICompany } from "../Interfaces/IRecomendation";

export default function SellList() {
  const [allProfiles, setAllProfiles] = useState<ICompany[]>([]);
  const Prof = async () =>{
    const allProfiles = await Api.GET_AllProfiles()
    const result = allProfiles.result? allProfiles.result : [] as ICompany[];
    setAllProfiles(result)
  } 

  useEffect(() => {
    Prof()
   
  },[]);
  
  console.log('Profile list', allProfiles)
  
  return (
    <div style={{ height: 250, width: '90%' }}>
      <DataGrid
        columns={[
          { field: 'id',
              headerName : 'ID'
            }, 
            { field: 'companyName',
              headerName : 'Company'
            }, 
            { field: 'location',
              headerName : 'Location' 
            },
            { field: 'Phase',
              headerName : 'Phase'
            }, 
            { field: 'industry',
            headerName : 'Industry' 
            },
            { field: 'employees',
              headerName : 'Employee'
            },  
            { field: 'annTurnover',
              headerName : 'Turnover'
            },
            { field: 'Action' },
          
        ]}
        rows={allProfiles}
      />
    </div>
  );
}