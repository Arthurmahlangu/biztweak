import React , { useState, useEffect } from "react";
import { Api } from '../services/endpoints';
import { DataGrid, GridRenderCellParams, GridValueGetterParams } from '@mui/x-data-grid';
import { ICompany } from "../Interfaces/IRecomendation";
import VisibilityIcon from '@mui/icons-material/Visibility';
import { Link } from 'react-router-dom';
import EmailIcon from '@mui/icons-material/Email';

export default function UserList() {
  const [allProfiles, setAllProfiles] = useState<ICompany[]>([]);
  const Prof = async () =>{
    const allProfiles = await Api.GET_AllProfiles()
    const result = allProfiles.result? allProfiles.result : [] as ICompany[];
    setAllProfiles(result)
  } 

  useEffect(() => {
    Prof()
   
  }, []);
  
  console.log('Profile list', allProfiles)
  
  return (
    <div style={{ height: 250, width: '90%' }}>
      <DataGrid
        columns={[
          { field: 'id',
              headerName : 'ID'
            }, 
            { field: 'companyName',
              headerName : 'Company'
            }, 
            { field: 'location',
              headerName : 'Location' 
            },
            { field: 'phase',
              headerName : 'Phase'
            }, 
            { field: 'industry',
            headerName : 'Industry' 
            },
            { field: 'employees',
              headerName : 'Employee'
            },  
            { field: 'annTurnover',
              headerName : 'Turnover'
            },
            { field: 'userId',
              headerName : 'User ID' 
            },
            { 
              field: 'action',
              headerName : 'Actions',
              // valueGetter: (params: GridValueGetterParams) =>(
              //   <Link to={{pathname:"/UserAdminMail"}} state={{user:params.row.id}} style={{}}><EmailIcon/></Link> 
              // ),
              
              renderCell: (params: GridRenderCellParams<any>) => (
              <strong>
                <Link to={`/AdminDash/Company/${params.id}`} style={{}}><VisibilityIcon/></Link>
                  {/* <Link navigate('/UserAdminMail', {state:{user:params}}); style={{}}><EmailIcon/></Link> */}
                  <Link to={{pathname:"/UserAdminMail"}} state={{user:params.row}} style={{}}><EmailIcon/></Link> 
                  
                
              </strong>
               
            ), 
          },
          
        ]}
        rows={allProfiles}
      />
    </div>
  );
}