import React from "react";
import { Typography } from "@material-ui/core";
import Container from '@material-ui/core/Container';

import './Article.css';
import { Button } from "@material-ui/core";
import { Link } from 'react-router-dom';
import Back from './Back';



const linkStyle = {
    margin: "1rem",
    textDecoration: "none",
    color: 'white'
  };  


const BootstrapBlog = () => (
    <div className="blogCon">
        <Container>
            <div className="blogHeader">
                <Typography className='blogHeader' variant='h4'>How to Bootstrap Your Business</Typography>
            </div>
            <div className="blogContent">
                <div className="par1">
                <Typography>
                    A great entrepreneur is resourceful, money smart and hardworking, all of which you need
                    to successfully bootstrap your way through the startup jungle.
                </Typography>
                </div>
                <div className="par2">
                    <Typography>
                    Bootstrapping a business gives you the chance to stay in control for as long as possible.
                    Besides that, scraping together money on your own will give you invaluable experience that
                    you will benefit from further down the road. It will force you to be smart about your money,
                    come up with creative solutions to every single problem you face, and put all your resources
                    , knowledge and abilities to good use.
                    </Typography>
                </div>
                <div className="par3">
                    <Typography>
                    To be successful in any business, an entrepreneur needs to use the available resources at his
                    disposal while limiting the borrowing of funds. Having 100%, ownership of the business and not
                    giving up an equity stake to an investor is on the wish list of every entrepreneur. This may
                    be accomplished with what is called bootstrapping. Once one becomes a bootstrapper, no one
                    will ever be on your back all the time, asking what has been done or directing on how you 
                    should run your business.
                    </Typography>
                </div>
                <div className="par4">
                    <Typography>
                    Bootstrapping refers to the process of starting a company with only personal savings, including
                    borrowed or invested funds from family or friends, as well as income from initial sales. Self-funded 
                    businesses do not rely on traditional financing methods, such as the support of investors, crowdfunding or bank loans.
                    </Typography>
                </div>
                <div className="par5">
                    <Typography>
                     1. Look for a business that needs less start-up capital <br/>
                     Starting up an excellent restaurant sounds like an awesome idea right? 
                     Many of us would obviously love to own one. However, such an investment 
                     needs a huge amount of capital injection. Thus, it is good to put it as a 
                     long-term objective. If you have less capital, it is advisable to start up 
                     with a food truck and accumulate enough profits to start your restaurant.
                    Thinking outside the box when it comes to business ideas is fine, but not 
                    if you don’t know what to expect. You need to have inside knowledge and 
                    good industry connections to make a success of any offshoot business. 
                    Stick to something you know and use the connections you have to make the 
                    most of your meagre cash. If you deal with people and companies that know 
                    you, you are more likely to get better deals. 
                    </Typography>
                </div>
                <div className="par6">
                    <Typography>
                    2. Work from Home <br/>
                       Monthly office rent payments are one of the most tedious expenses you can subject 
                       yourself to when starting your business. If you can comfortably work from home and 
                       provide all the services that your clients need, then you will be able to save a lot
                        of cash. Do not just save though, save and invest back into your business for 
                        expansion.
                       A fancy office may be in your future, but not yet. Take advantage of existing 
                       technology and software to work from home and collaborate with your team remotely. 
                       Many people are more productive working from home, and are willing to accept less 
                       pay for more flexibility. Most of your customers will not care about the fancy 
                       office anyway as long as you have a kick-ass website. 
                    </Typography>

                </div>
                <div className="par7">
                    <Typography>
                    3. Cut down your expenses<br/>
                       If you are planning to successfully bootstrap your business, one 
                       of the best methods is to cut down your daily expenses. For example, 
                       you may start your business from home to avoid monthly rental payments. 
                       Can you go for some days without going out to lunch? If you can consider 
                       doing so among many other steps, you can take to keep your expenses low. 
                       We know. Cutting down on luxuries and things you like sounds almost as 
                       enjoyable as realizing you just ate the last piece of candy without 
                       having been prepared for it. You know the struggle, right.
                       Nevertheless, if you are serious about your startup, cutting down your 
                       everyday expenses is key. The more you cut, the more you have to put into 
                       your business. In addition, while we are not going to tell you to move 
                       into your parents’ basement for the next three years, we will not judge 
                       you if you do. 
                    </Typography>
                </div>
                <div className="par8">
                    <Typography>
                    4. Integrate Digital marketing <br/>
                       Monthly office rent payments are one of the most tedious expenses you can 
                       subject yourself to when starting your business. If you can comfortably 
                       work from home and provide all the services that your clients need, then 
                       you will be able to save a lot of cash. Don't just save though, save and 
                       invest back into your business for expansion.
                    </Typography>
                </div>
                <div className="par9">
                    <Typography>
                    5. Pros and Cons of bootstrapping <br/>
                       • It allows entrepreneurs to retain full ownership of their business. When investors 
                       support a business, they do so in exchange for a percentage of ownership. Bootstrapping 
                       enables startup owners to retain their share of the equity.
                       • It forces business owners to create a model that really works. Most failed businesses 
                       struggle due to a poor business model. However, bootstrapping entrepreneurs are forced 
                       to develop processes that produce immediate, lasting cash flow, bypassing this outcome.
                       • It provides a sense of accomplishment. For some entrepreneurs, building something 
                       from the ground up without outside help is its own reward.
                       • It keeps control over direction in the owner’s hands. Taking on outside money also 
                       means taking on external pressure and responsibilities to satisfy those investors’ 
                       interests. While solutions to this exist within a traditional financing model, 
                       bootstrapping allows business owners to maintain full artistic direction and control 
                       over decisions.
                    </Typography>
                </div>
                <div className="par10">
                    <Typography>
                    Cons of bootstrapping<br/>
                        • It can be risky. Self-funded businesses can run out of funds more 
                        quickly and struggle to scale as their needs are met. This can limit a 
                        startup’s ability to reach its full potential.
                        • It limits support and opportunity. Traditional financing methods 
                        don’t just offer higher amounts of capital; they also unlock networking 
                        opportunities with top-level help, such as board members, shareholders 
                        and influencers. Bootstrapping a business limits that support and 
                        opportunity.
                        • It requires significant organization. Entrepreneurs who self-finance
                        must be extremely meticulous about keeping their books in order, lest 
                        issues (or opportunities!) arise later on.
                        • It is hard work. With potentially limited resources and connections 
                        in the beginning, bootstrapping entrepreneurs have to work harder and 
                        take on more roles. For some, this additional work can be well worth 
                        the effort.
                    </Typography>
                </div>
            </div>
            <div className='buttonblog'>
            <Back/>
            </div>
        </Container>
    </div>
)

export default BootstrapBlog