import React from "react";
import { Typography } from "@material-ui/core";
import Container from '@material-ui/core/Container';
import './Article.css'
import Back from './Back';




const linkStyle = {
    margin: "1rem",
    textDecoration: "none",
    color: 'white'
  };  



const  FiveTips = () => {
    return (
        <div className="blogCon">
        <Container>
            <div className="blogHeader">
                <Typography className='blogHeader' variant='h4'>Here are five tips to attract and engage customers on social media.</Typography>
            </div>
            <div className="blogContent">
                <div className="par1">
                <Typography>
                Social media gives your company the opportunity to connect and engage on a 
                personal level with both current and potential customers. This avenue is a 
                direct driver for business, as 74% of customers rely on social media to guide 
                their purchasing decisions. However, you need more than simply a social media 
                presence to help grow your business.
                </Typography>
                </div>
                <div className="par2">
                    <Typography>
                    As a small business, if you are not already taking advantage of social media, 
                    it’s safe to say you’re leaving a lot of money on the table. Social media is easily 
                    one of the most powerful tools that you can use to reach your ideal clients and 
                    introduce them to your brand, products, or services.
                    </Typography>
                </div>
                <div className="par3">
                    <Typography>
                    Whether you're just starting out or you are trying to revamp your 
                    existing strategy, here are some five tips on how you can attract and 
                    engage customers on social media.
                    </Typography>
                </div>
                <div className="par4">
                    <Typography>
                    Bootstrapping refers to the process of starting a company with only personal savings, including
                    borrowed or invested funds from family or friends, as well as income from initial sales. Self-funded 
                    businesses do not rely on traditional financing methods, such as the support of investors, crowdfunding or bank loans.
                    </Typography>
                </div>
                <div className="par5">
                    <Typography variant='h6'>1. Create and Share Informative and Educational Content </Typography>
                    <Typography>
                    Your potential customers are audience on social media who are looking out for authentic 
                    content relating to their pain areas. The content that you publish and share should be 
                    able to achieve a kind of connect with the audience. 
                    <br/>
                    Businesses often create posts that talk directly about their product, such as 
                    discussing features and why someone should buy it. Instead, create posts that 
                    help customers see why they need your product and how they can get more use from it.
                    <br/>
                    Educational content helps to position your brand as an authority. They start to 
                    look at you as a source of free, reliable and useful knowledge. When you focus on 
                    teaching and not selling, you gain trust.
                    </Typography>
                </div>
                <div className="par6">
                <Typography variant='h6'>2. Start Conversations on Social Media </Typography>
                    <Typography>
                    Though you have great educational and informative content, you cannot just sit back 
                    and wait for your audience to come up to you to spark a conversation. You need to find 
                    everal ways in which you can proactively initiate a conversation with your audience on 
                    social media.
                    <br/> 
                    Find out where is your target audience spending time on the social media. Start 
                    involving yourself in those communities by leaving valuable comments and 
                    contributions. On platforms, such as Twitter, you can conduct hashtag and 
                    keyword searches to find relevant content. Ensure to spend some time answering 
                    the questions relating to your industry and to participate in chats relevant to 
                    your business.
                    <br/>
                    For example, Product Launch Formula author Jeff Walker starts his product launch by asking his audience one simple question such as
                    Asking questions is by far one of the best ways to attract more customers on social media. 
                    Asking questions will 
                    encourage your audience to go into varying levels of thoughtfulness, which will trigger 
                    thoughtful and dedicated comments for your content.
                    </Typography>

                </div>
                <div className="par7">
                <Typography variant='h6'>3. Practice Social Listening/Social media monitoring </Typography>
                    <Typography>
                    Social listening to your audience is just as important as conversing with 
                    them on social media.
                    <br/>
                    Study has found that about 30,000 online searches have started with questions such as 
                    Where can I buy.  But unfortunately 60% never got a response since the brands are not 
                    monitoring the social media audience.
                    <br/>
                    Make a comprehensive list of keywords, hashtags and phrases that are relevant to your 
                    brand and business. Ensure to add all aspects such as your brand mentions, brand name, 
                    and misspellings of your brand name, your product names, your industry and any other relevant 
                    keywords to your monitoring list.
                    <br/>
                    You can conduct social listening manually but can be very overwhelming considering that there 
                    are millions of posts every single day.
                    <br/>
                    There are excellent social media management tools such as Cloohawk that can help you to track 
                    social media conversations. Develop a schedule for regular observation and participation 
                    with your audience.
                    <br/>
                    Listening to your audience will help your social media campaign to turn reactive and interactive 
                    by converting communication into conversations.
                    <br/>
                    </Typography>
                </div>
                <div className="par8">
                <Typography variant='h6'>4. Be Visible and Available on Social Media </Typography>
                    <Typography>
                    The higher your online visibility, greater are the chances for your audience to look out for 
                    your products and services.
                    <br/>
                    In simple terms, online visibility refers to the easiness with which consumers can find your 
                    company and its products in online locations.
                    <br/>
                    An effective online visibility campaign enhances your chances of being well known to your audience. 
                    This awareness will happen when the customer comes in look out for you, rather than you looking 
                    out for customers. So ensure that your profile is easily visible to the potential customers.
                    <br/>
                    Just being visible but not being available when audience approaches you, is of no use. 
                    Audience is expecting you to be available on social media at the time when they need you. 
                    In addition, when you are not responding or not available for their queries, you are going 
                    to hurt your bottom line.
                    <br/>
                    Research has shown that customers who receive a response to their queries are willing to spend 
                    more with that brand for a later purchase, and the response has to be within the first 60 minutes. 
                    </Typography>
                </div>
                <div className="par9">
                <Typography variant='h6'>5. Encourage Social Recommendations / Social Proof </Typography>
                    <Typography>
                    Most of the people rely on social proof from people who have been there before us.
                    <br/>
                    Social media has converted social proof as a greater force for buying decisions. 
                    Social media marketers are using the social media increasingly to share reviews, 
                    comments, likes, tweets and pins of their happy customers. This generates brand trust 
                    and drives huge sales.
                    <br/>
                    Make sure to embed social recommendations on your website and social pages. 
                    By sharing content from other businesses and people who are interesting and relevant 
                    to your followers, you can build trust and increase your value. When you share another 
                    person’s blog post or infographic, they are more likely to share your content with 
                    their followers — which increases your exposure as well.
                    <br/>
                    Encourage your satisfied customers to write personal recommendations and referrals. 
                    You should set up review and rating screen on your website so that customers can rate 
                    your products.
                    <br/>
                    Publish testimonials on your social media pages. Add real pictures, videos, and 
                    facts from happy customers to build trust around your products or services.
                    <br/>
                    No matter which of these tips you try, it's important to measure your results 
                    and experiment with content types until you find what works best for your audience. 
                    Review your posts' analytics and engagement rates; and, when you discover what your 
                    followers respond best to; plan to produce more of it.
                    <br/>
                    Most importantly, stay consistent in your posting schedule and your overall message. 
                    You don't have to post every single day, but stick with a rhythm that works for your 
                    business.
                    </Typography>
                </div>
 
            </div>
            <div className='buttonblog'>
            <Back/>
            </div>
        </Container>
    </div>
    )
}

export default FiveTips