import React from "react";
import { Typography } from "@material-ui/core";
import Container from '@material-ui/core/Container';
import './Article.css'
import { Button } from "@material-ui/core";
import { Link } from 'react-router-dom';
import Back from './Back';




const linkStyle = {
    margin: "1rem",
    textDecoration: "none",
    color: 'white'
  };  


const  Everyone = () => {
    return (
        <div className="blogCon">
        <Container>
            <div className="blogHeader">
                <Typography className='blogHeader' variant='h4'>Why Everyone on Your Team Needs To Be A Digital Whiz - (How to Get Customers on Social Media)</Typography>
            </div>
            <div className="blogContent">
                <div className="par1">
                <Typography>
                Recent statistics have shown that more than four billion out of approximately 7.4 
                billion people across the world use the internet. In comparison, over half of the 
                world’s population is said to be online. In 2020, an estimated 3.6 billion people 
                were using social media worldwide, a number projected to increase to almost 4.41 
                billion in 2025 (15 July 2020 - statista.com).
                </Typography>
                </div>
                <div className="par2">
                    <Typography>
                    Because of the growing trends of internet usage and social media engagement, 
                    entrepreneurs have begun to willingly embrace social media platforms to 
                    promote their products and services.
                    </Typography>
                </div>
                <div className="par3">
                    <Typography>
                    Presently, a lot of employees lack the suitable skills that are required in their industries. 
                    Digital leaders stress that new ways of working and active talent are needed for a business 
                    to grow and quickly adjust to change in the fast-moving digital landscape.
                    <br/>
                     Relevant digital skills have to be established to remain on the ball in our ever-changing fast-paced world. 
                     Here are five reasons why a digital-savvy workforce is important.
                    </Typography>
                </div>
                <div className="par4">
                    <Typography>
                     Your team will be more consumer-centric
                     Digital marketing is slowly replacing traditional marketing, 
                     with a digitally-savvy team, you will be able to increase consumer awareness about your 
                     you will be able to provide informative and attractive news about the product and services 
                     directly to your target audience. Being at the pulse of what they want and how they feel 
                     about your business.  That the brand is offering and use guarantees about the price and 
                     quality. In addition, you will be able to create community groups on social media platforms, use customer loyalty programmes and provide discounts for consumers who used social media for purchasing.

                    </Typography>
                </div>
                {/* <div className="par5">
                    <Typography variant='h6'>1. Create and Share Informative and Educational Content </Typography>
                    <Typography>
                    Your potential customers are audience on social media who are looking out for authentic 
                    content relating to their pain areas. The content that you publish and share should be 
                    able to achieve a kind of connect with the audience. 
                    <br/>
                    Businesses often create posts that talk directly about their product, such as 
                    discussing features and why someone should buy it. Instead, create posts that 
                    help customers see why they need your product and how they can get more use from it.
                    <br/>
                    Educational content helps to position your brand as an authority. They start to 
                    look at you as a source of free, reliable and useful knowledge. When you focus on 
                    teaching and not selling, you gain trust.
                    </Typography>
                </div>
                <div className="par6">
                <Typography variant='h6'>2. Start Conversations on Social Media </Typography>
                    <Typography>
                    Though you have great educational and informative content, you cannot just sit back 
                    and wait for your audience to come up to you to spark a conversation. You need to find 
                    everal ways in which you can proactively initiate a conversation with your audience on 
                    social media.
                    <br/> 
                    Find out where is your target audience spending time on the social media. Start 
                    involving yourself in those communities by leaving valuable comments and 
                    contributions. On platforms, such as Twitter, you can conduct hashtag and 
                    keyword searches to find relevant content. Ensure to spend some time answering 
                    the questions relating to your industry and to participate in chats relevant to 
                    your business.
                    <br/>
                    For example, Product Launch Formula author Jeff Walker starts his product launch by asking his audience one simple question such as
                    Asking questions is by far one of the best ways to attract more customers on social media. 
                    Asking questions will 
                    encourage your audience to go into varying levels of thoughtfulness, which will trigger 
                    thoughtful and dedicated comments for your content.
                    </Typography>

                </div>
                <div className="par7">
                <Typography variant='h6'>3. Practice Social Listening/Social media monitoring </Typography>
                    <Typography>
                    Social listening to your audience is just as important as conversing with 
                    them on social media.
                    <br/>
                    Study has found that about 30,000 online searches have started with questions such as 
                    Where can I buy.  But unfortunately 60% never got a response since the brands are not 
                    monitoring the social media audience.
                    <br/>
                    Make a comprehensive list of keywords, hashtags and phrases that are relevant to your 
                    brand and business. Ensure to add all aspects such as your brand mentions, brand name, 
                    and misspellings of your brand name, your product names, your industry and any other relevant 
                    keywords to your monitoring list.
                    <br/>
                    You can conduct social listening manually but can be very overwhelming considering that there 
                    are millions of posts every single day.
                    <br/>
                    There are excellent social media management tools such as Cloohawk that can help you to track 
                    social media conversations. Develop a schedule for regular observation and participation 
                    with your audience.
                    <br/>
                    Listening to your audience will help your social media campaign to turn reactive and interactive 
                    by converting communication into conversations.
                    <br/>
                    </Typography>
                </div>
                <div className="par8">
                <Typography variant='h6'>4. Be Visible and Available on Social Media </Typography>
                    <Typography>
                    The higher your online visibility, greater are the chances for your audience to look out for 
                    your products and services.
                    <br/>
                    In simple terms, online visibility refers to the easiness with which consumers can find your 
                    company and its products in online locations.
                    <br/>
                    An effective online visibility campaign enhances your chances of being well known to your audience. 
                    This awareness will happen when the customer comes in look out for you, rather than you looking 
                    out for customers. So ensure that your profile is easily visible to the potential customers.
                    <br/>
                    Just being visible but not being available when audience approaches you, is of no use. 
                    Audience is expecting you to be available on social media at the time when they need you. 
                    In addition, when you are not responding or not available for their queries, you are going 
                    to hurt your bottom line.
                    <br/>
                    Research has shown that customers who receive a response to their queries are willing to spend 
                    more with that brand for a later purchase, and the response has to be within the first 60 minutes. 
                    </Typography>
                </div>
                <div className="par9">
                <Typography variant='h6'>5. Encourage Social Recommendations / Social Proof </Typography>
                    <Typography>
                    Most of the people rely on social proof from people who have been there before us.
                    <br/>
                    Social media has converted social proof as a greater force for buying decisions. 
                    Social media marketers are using the social media increasingly to share reviews, 
                    comments, likes, tweets and pins of their happy customers. This generates brand trust 
                    and drives huge sales.
                    <br/>
                    Make sure to embed social recommendations on your website and social pages. 
                    By sharing content from other businesses and people who are interesting and relevant 
                    to your followers, you can build trust and increase your value. When you share another 
                    person’s blog post or infographic, they are more likely to share your content with 
                    their followers — which increases your exposure as well.
                    <br/>
                    Encourage your satisfied customers to write personal recommendations and referrals. 
                    You should set up review and rating screen on your website so that customers can rate 
                    your products.
                    <br/>
                    Publish testimonials on your social media pages. Add real pictures, videos, and 
                    facts from happy customers to build trust around your products or services.
                    <br/>
                    No matter which of these tips you try, it's important to measure your results 
                    and experiment with content types until you find what works best for your audience. 
                    Review your posts' analytics and engagement rates; and, when you discover what your 
                    followers respond best to; plan to produce more of it.
                    <br/>
                    Most importantly, stay consistent in your posting schedule and your overall message. 
                    You don't have to post every single day, but stick with a rhythm that works for your 
                    business.
                    </Typography>
                </div>
  */}
            </div>
            <div className='buttonblog'>
            <Back/>
            </div>
        </Container>
    </div>
    )
    
}
export default Everyone