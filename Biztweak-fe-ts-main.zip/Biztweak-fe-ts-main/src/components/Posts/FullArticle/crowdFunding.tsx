import React from "react";
import { Typography } from "@material-ui/core";
import Container from '@material-ui/core/Container';
import './Article.css';
import { Button } from "@material-ui/core";
import { Link } from 'react-router-dom';
import Back from './Back';



   const linkStyle = {
        margin: "1rem",
        textDecoration: "none",
        color: 'white'
      };  


const  CrowdFunding = () => {

    return (
        <div className="blogCon">
        <Container>
            <div className="blogHeader">
                <Typography className='blogHeader' variant='h4'>What you should know about crowdfunding and how to crowdfund for</Typography>
            </div>
            <div className="blogContent">
                <div className="par1">
                <Typography>
                Do you have a great business idea but no financial backing? Crowdfunding could
                 be the answer for you. A few years ago, South Africans came together to help 
                 raise money for a petrol attendant who assisted a lady who couldn’t find her 
                 bank card by giving her money to top off her tank. The story gained traction 
                 online and the lady started a crowdfunding campaign on BackABuddy for the petrol 
                 attendant to thank him for his act of kindness. They raised about R500 000.
                </Typography>
                </div>
                <div className="par2">
                    <Typography>
                    You may be now thinking “what exactly is this crowdfunding thing?”. 
                    Crowdfunding is a practice of raising money through the collective 
                    effort of friends, family, individual investors and everyone who just 
                    wants to pitch in. It gives you, the entrepreneur, a platform to build, 
                    showcase, pitch and be able to raise the capital that you need to grow 
                    your business.
                    </Typography>
                </div>
                <div className="par3">
                    <Typography>
                    The concept of raising money through crowdfunding is not new, but has 
                    gained popularity over the years. Many people have been using crowdfunding 
                    as a way to raise money for different causes. For personal needs such as 
                    medical, education or for charity causes and most of all for their businesses.
                    Crowdfunding has become a viable option to raise capital for many 
                    entrepreneurs because of the wide range of benefits it offers such as 
                    helping entrepreneurs to reach a wide spectrum of investors and providing 
                    market validation, as well as marketing benefits. 
                    </Typography>
                </div>
                <div className="par4">
                    <Typography>
                    It works by getting funders to chip into your business or venture. 
                    Crowd-funding projects are hosted by an online platform where your idea or 
                    business information is put online and the amount you need is the target 
                    you want to reach. The platform requires you to set a financial goal for your 
                    campaign, as well as a time frame in which to reach that goal, usually between 
                    30 and 90 days. For the funders, there are a range of rewards, from the proud 
                    feeling of making something happen to getting great financial returns on their 
                    contributions.
                    </Typography>
                </div>
                <div className="par5">
                    <Typography variant='h6'>It is important to note that there are different types of crowdfunding: </Typography>
                    <Typography>
                    • Donations- Individuals donate to a charity project without expecting 
                      anything in return.<br/>
                    • Rewards-  Here individuals give you money with the expectation of 
                      receiving a non financial reward at a later stage in exchange for their 
                      contribution. For the funders,there are a range of rewards, from the proud 
                      feeling of making something happen to getting great financial returns on 
                      their contributions. <br/>
                    • Equity- Entrepreneurs raise funds for their business by selling shares of 
                      their business to outside investors in exchange for capital. In doing so, 
                      the investor becomes a shareholder of the business.<br/>
                    <br/>
                     Equity based crowdfunding is a popular way for start-ups to raise funds. 
                     Crowdfunding platforms such as Angel Investment Network, The People’s Fund 
                     and Uprise.Africa are some of the local investment platforms linking 
                     investors and investees. These platforms bring everyone together, you, the 
                     person looking for the money, private individuals who are willing to invest 
                     in your idea or business.
                     <br/>
                     To run a successful crowdfunding campaign, you need to capture the attention 
                     of a large number of backers and convince them that your project is worthy of 
                     their investment. There's no one-size-fits-all approach to crowdfunding, 
                     but there are a few tips to start on your road to crowdfunding success.
                    </Typography>
                </div>
                <div className="par6">
                <Typography variant='h6'>Prepare for the campaign </Typography>
                    <Typography>
                    For the best crowdfunding results, take time to plan and prepare for the campaign 
                    before launching it. Spread the word to your family and friends that you're going 
                    to launch the campaign. Your campaign introduction should give backers a clear 
                    understanding of what your product is, what problem it solves, how it compares to 
                    other products on the market, and why it’s important to them. Be active on your 
                    personal and company social media accounts prior to the launch. You need to be 
                    available to investors and potential investors if they have questions.
                    </Typography>

                </div>
                <div className="par7">
                <Typography variant='h6'>Create buzz around the campaign</Typography>
                    <Typography>
                    Use your personal network to create buzz about your crowdfunding campaign. 
                    Ask people you know to share details of your campaign on their social media 
                    feeds, blogs, or newsletters. With new crowdfunding campaigns launching 
                    daily, it is crucial to make your campaign stand out from the others.
                    <br/>
                    Create proper marketing material for your campaign to gain recognition. 
                    It can be a video of you telling us about your idea/ business, your product or 
                    services and how much you need, why you need that amount and how you plan to 
                    grow your business if you reach your target. 
                    <br/>
                    Be transparent as possible and often give updates of how far you are now. 
                    Be active on your personal and company social media accounts prior to the 
                    launch. You need to be available to investors and potential investors if 
                    they have questions.
                    <br/>
                    Crowdfunding offers several valuable perks. It can be a great tool to conduct 
                    market research. When done properly, crowdfunding, especially when combined with 
                    social media and press coverage, can help you build a dedicated audience that will 
                    stay with you even after your campaign ends as your business grows.
                    </Typography>
                </div>
                <div className='buttonblog'>
                <Back/>
                            </div>
            </div>
        </Container>
    </div>
    )
}

export default CrowdFunding