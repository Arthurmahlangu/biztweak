
import React from "react";
import './Article.css';
import { Button } from "@material-ui/core";
import { Link } from 'react-router-dom';


   const linkStyle = {
    margin: "1rem",
    textDecoration: "none",
    color: 'white'
  };  

  const  Backbtn = () => {

    return (
<div className='buttonblog'>
                <Link to='/Post' style={linkStyle}>
                            <Button 
                                    variant='outlined' 
                                    className='btnblog'
                            >
                                    Back
                            </Button>
                            </Link>
                            </div>
                            )
}

export default Backbtn