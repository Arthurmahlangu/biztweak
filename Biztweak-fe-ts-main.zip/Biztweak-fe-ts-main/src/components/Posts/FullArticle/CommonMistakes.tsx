import React from "react";
import { Typography } from "@material-ui/core";
import Container from '@material-ui/core/Container';
import './Article.css';
import Back from './Back';



const  CommonMistakes = () => {
    return (
        <div className="blogCon">
        <Container>
            <div className="blogHeader">
                <Typography className='blogHeader' variant='h4'>3 common mistakes entrepreneurs make when finding customers.</Typography>
            </div>
            <div className="blogContent">
                <div className="par1">
                <Typography>
                    It can be really hard for young entrepreneurs to secure customers. 
                    Approximately 75% of small businesses fail within the first 2 years of 
                    existence. The primary reason for most business failure is the inability 
                    to attract and retain customers. This may be due to the fact that they are 
                    new in business, don't have a network list, not knowing enough and not 
                    knowing who they should be selling to.
                    <br/>
                    Many entrepreneurs understand their idea but not the market that will accept 
                    or reject the idea, they do not know where to go for funding, who the real competitors are. 
                    Young and new entrepreneurs sometimes fail because of these factors. They have no idea how 
                    to access the skills and expertise they need in their business.
                    <br/>
                    There are a variety of old techniques and newer tools you can use to find 
                    customers and increase sales. It is best to understand the range of choices 
                    you have in order to determine which one will be effective in helping you 
                    reach customers. There are few common mistakes entrepreneurs make when 
                    trying to reach customers.
                </Typography>
                </div>
                <div className="par2">
                <Typography variant='h6'>The product you are offering does not align with the needs of your target market. </Typography>
                    <Typography>
                       Product market-fit is one of the biggest reasons why small businesses fail.
                        If what you are offering is no solution or of any help to your potential 
                        customers, no matter how good your marketing or sales team is, you will 
                        not attract any customers to build a sustainable business.
                        <br/>
                        It is said that 87% of South African B2B buyers expect businesses to have a good 
                        understanding of their needs. Some research studies found that 62% of customers think 
                        businesses are failing to identify their needs and deliver, which then gives them an 
                        opportunity to jump ship and buy from the competition. Which business wants to lose 
                        customers to their competition? I think we can agree on None! Right?
                        <br/>
                        An effective way of testing market-product fit is by building an MVP 
                        (minimum viable product) that you then share with the target audience. By looking at 
                        feedback, you are able to find product- market fit. The idea of an MVP is mostly 
                        relevant in the tech sector. Instead of spending a huge amount of time trying to 
                        figure out the perfect product, you can use that time determining what the minimum 
                        requirements are to get the product into the marketplace by finding out what people 
                        like and are willing to pay for.
                        <br/>
                        Good example of this is how one of South Africa’s growing tech services, 
                        Yoco, developed a product that is market fit. They believe MVP’s should 
                        be desirable to customers. They measure the viability of a product 
                        together with its desirability by asking themselves questions like “what 
                        does it take to make people actively use this app?”. Yoco uses customer 
                        demand and feedback as one of the strongest indicators of a successful 
                        product.
                        <br/>
                        An MVP allows you to test the product and use customer feedback to 
                        continue improving. By doing this, you are already building a community 
                        for your product which will ultimately gain momentum.
                    </Typography>
                </div>
                <div className="par3">
                <Typography variant='h6'>Poor marketing strategies </Typography>
                    <Typography>
                    To ensure longevity of your business, marketing is essential. 
                    Especially for small businesses, which is often overlooked by new 
                    entrepreneurs. Depending on the business model and the product in question, 
                    your business will be a good fit for some channels and a bad fit for others. 
                    From online marketing, social media, word of mouth and paid advertising 
                    through direct marketing to exhibitions and PR. There are many ways to engage 
                    potential and existing customers. The key is to find out which best works for 
                    you.
                    <br/>
                    Where do businesses go wrong in choosing their marketing strategy? <br/>
                    • Poor marketing by promoting your business in the wrong could be why you 
                    are not attracting customers. If people don’t know about your product, they 
                    will not buy from you. Choose marketing tools that are compatible with your 
                    business type. Your marketing activities need to reach potential customers, 
                    and convince them to find out more about you. To avoid making this mistake, 
                    devise a marketing plan for your business.
                    • Your marketing strategies don’t align with your goals and marketing 
                    resources that are available. Without 	attention to customer’s needs  when 
                    promoting your business, there will be no impact on their buying decisions 
                    and behavior patterns. Your marketing needs a sense of direction.
                    • Poor customer service. Great customers service is extremely useful 
                    marketing tool and should be prioritized. Impressing customers by offering 
                    good service will return more customers which will lead to increased sales.
                    <br/>
                    An effective marketing strategy should give you results, know your customers 
                    and what influences their buying decisions. You will see the results in the 
                    numbers of sales.
                    </Typography>
                </div>
                <div className="par4">
                <Typography variant='h6'>Your messaging is not clear </Typography>
                    <Typography>
                    To get the first ten customers/clients for your business, you have to GRIND! What I mean 
                    by that is that you have to do the work, reach out to every single person. Even if 
                    it’s rolling up to a crowd and asking “hey, will you buy my stuff or I am selling 
                    this, would you like to buy?” I’m kidding, there is a better way of selling without 
                    sounding like you are harassing people. Marketing your product or service through 
                    proper channels and getting people to actually buy it by using the right messaging.
                    <br/>
                    In marketing, the term “messaging” refers to how business talks about itself and 
                    the value it provides. Messaging is the key point or messages you use to communicate 
                    about your product/service with a target audience. These are the statements you use 
                    to develop materials for marketing communications such as ad slogans, advertising 
                    copy, social media posts, press releases, presentation scripts, etc.
                     <br/>
                     A clear, consistent message can be the difference between successfully attracting 
                     buyers and an utter waste of time and money. If you, as a business owner, have not 
                     defined your message clearly, how likely is it that your target audiences will get 
                     the message you want them to hear and buy from you? A lot of entrepreneurs get 
                     marketing right to only get it wrong. What I mean is that they have an idea how 
                     to promote their business and the channels to use to find customers but their 
                     messaging is completely off.
                     <br/>
                     The impact of a consistent, effective message is increased when the 
                     messaging is clear. It reaches the people you’re targeting again and again 
                     through different channels.
                     <br/>
                     • Communicate the main idea you want people to understand and remember about your offering.
                     • Resonate with the audience you are targeting, such that they pay attention and feel
                      what you are saying matters.	
                     • Articulate clearly what you stand for, why you are different, what value you offer, 
                     what problems you solve.
                     <br/>
                     Take a FREE assessment and get recommendations on how to improve your business and
                      avoid making such mistakes
                    </Typography>
                </div>
                <div className='buttonblog'>
                <Back/>
                </div>
            </div>
        </Container>
    </div>
    )
}

export default CommonMistakes