import React from "react";
import { Container, Typography } from "@material-ui/core";
import CrowdFunding from "../FullArticle/crowdFunding";
import CommonMistakes from "../FullArticle/CommonMistakes";
import Everyone from "../FullArticle/Everyone";
import FiveTips from "../FullArticle/FiveTips";
import Footernew from "../../Footer/Footernew";
import BootstrapBlog from "../FullArticle/HowToBootstrap";
import bootstrap from '../img/Bootstrap.png';
import crowd from '../img/Crowdfunding.png';
import UserNavbar from "../../UserNav/UserNav";
import five from '../img/fivetips.png';
import three from '../img/threeCom.jpg'
import { Link } from 'react-router-dom';
import './Post.css'


const   Post = () => {
    return (
        <div className="Post-con">
            <UserNavbar/>
            <Container>
                <div className="post-header">
                    <Typography variant='h2'>Blogs</Typography>
                </div>
                <div className="blogs">
                    <div className="blog1">
                        <Typography variant="h4">What is Crowdfunding? Learn everything here</Typography>
                        <img
                            src={crowd}
                            alt='howToBootStrap'
                            className="blogIMG"
                        />
                        <Typography>
                            Do you have a great business idea but no financial backing? Crowdfunding
                            could be the answer for you. A few years ago, South Africans came together to
                            help raise money for a petrol attendant who assisted a lady who couldn’t find
                            her bank card by giving her money to top off her tank. The story <Link to='/crowdFunding'>Read More</Link>
                        </Typography>

                    </div>
                    <div className="blog2">
                    <Typography variant="h4">How To Bootstrap Your Business</Typography>
                        <img
                            src={bootstrap}
                            alt='howToBootStrap'
                            className="blogIMG"
                        />
                        <Typography>
                            A great entrepreneur is resourceful and money smart.
                            These traits are important to successfully learn how to bootstrap your business.
                            Bootstrapping is starting a company with only personal savings, including borrowed
                            or invested funds from family or friends, as well as income from initial sales
                            . Bootstrapping a business gives you the chance to stay in control. <Link to='/HowToBootstrap'>Read More</Link>
                        </Typography>
                        
                    </div>
                    <div className="blog3">
                    <Typography variant="h4">5 tips to attract and engage customers on social media</Typography>
                        <img
                            src={five}
                            alt='howToBootStrap'
                            className="blogIMG"
                        />
                        <Typography>
                            Here are five tips on how you can attract and engage customers on social media.
                            Social media gives your company the opportunity to connect and engage on a persona
                            level with both current and potential customers. This avenue is a direct driver for
                            business, as 74% of customers rely on social media to guide their purchasing
                            decisions <Link to='/FiveTips'>Read More</Link>
                        </Typography>
                        
                    </div>
                    <div className="blog4">
                    <Typography variant="h4">5 tips to attract and engage customers on social media</Typography>
                        <img
                            src={three}
                            alt='howToBootStrap'
                            className="blogIMG4"
                        />
                        <Typography>
                            There are 3 common mistakes entrepreneurs make when finding customers.
                            Approximately 75% of small businesses fail within the first 2 years of existence.
                            The primary reason for most business failures is the inability to attract and
                            retain customers. This may be due to the fact that they are new in business, 
                            don’t have a network <Link to='/CommonMistakes'>Read More</Link>
                        </Typography>
                    </div>
                    <div className="blog5">
                        
                    </div>
                </div>
            </Container> 
           
        </div>
    )
}

export default Post