import React from "react";
import "./Posts.css";
// import Post from "../Post/Post";
import { Link } from 'react-router-dom';
import fiveTips from './img/fivetips.png';
import { Button } from "@material-ui/core";
import threeCom from './img/threeCom.jpg';
import bootStrap from './img/Bootstrap.png';
import crowd from './img/Crowdfunding.png';
import savvy from './img/digitally.jpg';
import FiveTips from "./FullArticle/FiveTips";
import CommonMistakes from "./FullArticle/CommonMistakes";
import BootstrapBlog from "./FullArticle/HowToBootstrap";
import CrowdFunding from "./FullArticle/crowdFunding";





const Posts = () => {
	const cLink = <Link to="/3commonMistakes">Read More</Link>
const blogPosts = [
	{
	title: "What is Crowdfunding? Learn everything here.",
	body: `Do you have a great business idea but no financial backing? Crowdfunding
	 could be the answer for you. A few years ago, South Africans came together to
	  help raise money for a petrol attendant who assisted a lady who couldn’t find
	   her bank card by giving her money to top off her tank. The story […]<a href="http://google.com">Read More</a>`,
	   
	author: "Busisiwe Mboyisa",
	imgUrl:`${crowd}`,

	},
	{
	title: "How To Bootstrap Your Business ",
	body: `A great entrepreneur is resourceful and money smart.
	 These traits are important to successfully learn how to bootstrap your business.
	  Bootstrapping is starting a company with only personal savings, including borrowed
	   or invested funds from family or friends, as well as income from initial sales
	   . Bootstrapping a business gives you the chance to stay in control.`,
	   author: "Sibongiseni Sibewu",
	imgUrl:`${bootStrap}`,
	},
	{
	title: "5 tips to attract and engage customers on social media",
	body: `Here are five tips on how you can attract and engage customers on social media.
	 Social media gives your company the opportunity to connect and engage on a persona
	  level with both current and potential customers. This avenue is a direct driver for
	   business, as 74% of customers rely on social media to guide their purchasing
	    decisions. `,
	author: "Sibongiseni Sibewu",
	imgUrl: `${fiveTips}`,
	},
	{
	title: "3 common mistakes entrepreneurs make when finding customers",
	body: `There are 3 common mistakes entrepreneurs make when finding customers.
	 Approximately 75% of small businesses fail within the first 2 years of existence.
	  The primary reason for most business failures is the inability to attract and
	   retain customers. This may be due to the fact that they are new in business, 
	   don’t have a network `,
	author: "Busisiwe Mboyisa",
	imgUrl:`${threeCom}`,
	},
	{
		title: "Everyone on Your Team should be Digitally-Savvy, Heres Why?",
		body: `For businesses to grow and quickly adjust to change, everyone on your
		 team should be digitally-savvy. In order for entrepreneurs to remain on the ball
		  in this ever-changing fast-paced world, they need to establish relevant digital
		   skills. Recent statistics have shown that more than four billion people across
		    the world use the internet. In 2020, `,
		author: "Sibongiseni Sibewu",
		imgUrl:`${savvy}`,
		},
];

return (
	<div className="posts-container">
	{/* {blogPosts.map((post, index) => (
		<Post key={index} index={index} post={post} />
	))} */}
	</div>
);
};

export default Posts;
