import React, { useEffect, useState } from 'react';
import Typography from '@material-ui/core/Typography';
import Button from '@material-ui/core/Button';
import Accordion from '@material-ui/core/Accordion';
import AccordionSummary from '@material-ui/core/AccordionSummary';
import AccordionDetails from '@material-ui/core/AccordionDetails';
import ExpandMoreIcon from '@material-ui/icons/ExpandMore';
import { Link } from 'react-router-dom';
import { useDispatch } from "react-redux";
import { setAllUserRecomendations, setSelectedRecomendation } from "../../Slice/createSlice";
import { supabase } from '../../supabaseClient'
import './AssessmentAccordion.css';



function rand() {
  return Math.round(Math.random() * 20) - 10;
}



const AccessmentAccordion = ({setSelectedRecommedation} : any) => {
  const [recommendations, setRecommedations] = useState([] as any);
  const dispatch = useDispatch();
  useEffect(() => {
    getAssessments();
  }, []);

  const getAssessments = async () => {
    const user = supabase.auth.user()
    const { data: Recomendations, error } = await supabase
      .from('Recomendations')
      .select('*')
      .eq("userId", user?.id);

    if (!error) {

      Recomendations.forEach(recommendation => {
        for (const key in recommendation.segmentResponses) {
          recommendation.segmentResponses[key].forEach((response: any) => {
            if (response.answered === false) {
              recommendation.completed = false;
            }
          })
        }
      });
    
      setRecommedations(Recomendations);
      dispatch(setAllUserRecomendations(Recomendations))
      if (setSelectedRecommedation ){
        dispatch(setSelectedRecomendation(Recomendations[Recomendations.length - 1]))
      }
      
    } else {
      alert('We cound not fetch your assessments at the moment, please try again later.')
    }
  }


  return (
    <div className='list'>
      {recommendations.map(
        (reco: any, index: number) => {
          return (
            <div key={index} style={{ padding: "5px" }}>
              <Accordion>
                <AccordionSummary
                  expandIcon={<ExpandMoreIcon />}
                  aria-controls="panel1a-content"
                  id="panel1a-header"
                >
                  <Typography className="">View Report</Typography>
                </AccordionSummary>
                <AccordionDetails className='acc-h'>
                  <p>{reco.phase}</p>
                  <p>{reco.industry}</p>
                  <div>
                    {
                      reco.completed === false ?

                        <Button
                          size="small"
                          variant="outlined"
                          className="bizReport"
                          onClick={() => {
                            dispatch(setSelectedRecomendation(reco))
                          }}
                        >
                          <Link style={{ color: "white", textDecoration: "none", padding: "2px", cursor: "pointer" }} to={`/${reco.assessment}`}>Complete Assessment</Link>
                        </Button>
                        :

                        <Button
                          size="small"
                          variant="outlined"
                          className="bizReport"
                          onClick={() => {
                            dispatch(setSelectedRecomendation(reco))
                          }}
                        >
                          <Link to="/Report">View Report</Link>
                        </Button>

                    }
                  </div>
                </AccordionDetails>
              </Accordion>
            </div>
          )
        }
      )}
    </div>
  );
};

export default AccessmentAccordion;

//

