import React, { useRef, useState, useEffect } from "react";
import "./Subscribe.css";
// import AOS from 'aos';
// import "aos/dist/aos.css";
import emailjs from '@emailjs/browser';
import Box from '@mui/material/Box';
import Button from '@mui/material/Button';
import Typography from '@mui/material/Typography';
import Modal from '@mui/material/Modal';
import MarkEmailReadIcon from '@mui/icons-material/MarkEmailRead';


const Subscribe = () => {
  // useEffect(() => {
  //   AOS.init({
  //     duration: 1000,
  //   });
  // }, []);
  
  const [to_name, setTo_Name] = useState("");
  
  const submitInfo = (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    console.log("to_name", to_name);
    
    const emailContent = {
    to_name: to_name
    }
    
    emailjs.send('service_y6f3tfy','template_nhpfwsv', emailContent, 'EF2Wbs3gVnRSHu3tR')
	.then(function(response) {
        console.log('SUCCESS!', response.status, response.text);
     }, function(err) {
        console.log('FAILED...', err);
     });
};

const style = {
  position: 'absolute' as 'absolute',
  top: '50%',
  left: '50%',
  transform: 'translate(-50%, -50%)',
  width: 300,
  bgcolor: 'background.paper',
  border: '2px solid #000',
  boxShadow: 24,
  p: 4,
};

const [open, setOpen] = React.useState(false);
  const handleOpen = () => setOpen(true);
  const handleClose = () => setOpen(false);

  
  return (
    <section id="subscribe">
      <div className="container subscribe">
      <h6>Newsletter</h6>
        <h2>Let's Get in touch!</h2>
        <p>Enter your email and become part of our entrepreneurial community. We want to engage with you about your business and opportunities.</p>
        <form  onSubmit={submitInfo}>
          <div className="form-control">
            <input type="text" placeholder="Enter Your Email..."
            onChange={(event) => {setTo_Name(event.target.value)}}
            />
            <button onClick={handleOpen} >Subscribe</button>
            <Modal
        open={open}
        onClose={handleClose}
        aria-labelledby="modal-modal-title"
        aria-describedby="modal-modal-description"
      >
        <Box sx={style}>
          <MarkEmailReadIcon />
          <Typography id="modal-modal-title" variant="h6" component="h2">
            Email Sent!
          </Typography>
          <Typography id="modal-modal-description" sx={{ mt: 2 }}>
            Please check your email for more details.
          </Typography>
        </Box>
      </Modal>
          </div>
        </form>
      </div>
    </section>
  );
};

export default Subscribe;


// import React, { useEffect } from "react";
// import "./Subscribe.css";
// import AOS from 'aos';
// import "aos/dist/aos.css";

// const Subscribe = () => {
//   useEffect(() => {
//     AOS.init({
//       duration: 1000,
//     });
//   }, []);
//   return ( 
//     <section id="subscribe">
//       <div className="container subscribe" data-aos="fade-up">
//       <h6>Newsletter</h6>
//         <h2>Let's Get in touch!</h2>
//         <p>Enter your email and become part of our entrepreneurial community. We want to engage with you about your business and opportunities.</p>
//         <form>
//           <div className="form-control">
//             <input type="text" placeholder="Enter Your Email..." />
//             <button>Subscribe</button>
//           </div>
//         </form>
//       </div>
//     </section>
//   );
// };

// export default Subscribe;