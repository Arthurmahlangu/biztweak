import React, { useState } from 'react';
import { Container, Grid, Button } from '@material-ui/core';
import Accordion from '@material-ui/core/Accordion';
import AccordionSummary from '@material-ui/core/AccordionSummary';
import AccordionDetails from '@material-ui/core/AccordionDetails';
import Typography from '@material-ui/core/Typography';
import ExpandMoreIcon from '@material-ui/icons/ExpandMore';
import MuiAlert from '@material-ui/lab/Alert';
import UserNavbar from '../../UserNav/UserNav';
import company from '../../../Images/company.png'
import Radio from "@mui/material/Radio";
import RadioGroup from "@mui/material/RadioGroup";
import FormControlLabel from "@mui/material/FormControlLabel";
import FormControl from "@mui/material/FormControl";
import FormLabel from "@mui/material/FormLabel";
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { createSlice } from '@reduxjs/toolkit';
import { Api } from '../../../services/endpoints';
import { IRecomendation, IPoor, INoMoney } from '../../../Interfaces/IRecomendation'
import Footernew from '../../Footer/Footernew';
import { supabase } from '../../../supabaseClient';
import eCommerceSeg from '../../../json/eCommerce.json'
import customerSegment from '../../../json/customerSegment.json';
import businessCustomersSeg from '../../../json/businessCustomers.json';
import marketingSales from '../../../json/marketingSales.json';
import owner from '../../../json/ownershipMindset.json'
import customerRelations from '../../../json/customerRelations.json'
import channels from "../../../json/channels.json";
import functionalCapability from "../../../json/functionalCapability.json";
import revenue from "../../../json/revenueStreams.json";
import { useSelector } from 'react-redux';
import { selectRecomendationState } from "../../../Slice/createSlice";
import AccessmentAccordion from '../../AssessmentsAccordion/AccessmentsAccordion';
import '../Assessment.css'

type LocationState = {
  bizInd: Array<{
    value: number;
    label: string
  }>,
  bizPhase: Array<{
    value: number;
    label: string
  }>
}




const NoMoney = () => {
  const location = useLocation();
  const bizInd = (location.state as LocationState)?.bizInd;
  const bizPhase = (location.state as LocationState)?.bizPhase;
  const navigate = useNavigate();
  // const [value, setValue] = React.useState('');
  const [CustomerRelations, setCustomerRelations] = useState<{ question: string, field: string }[]>(customerRelations);
  const [Channel, setChannel] = useState<{ question: string, field: string }[]>(channels);
  const [eCommerce, setEcommerce] = useState<{ question: string, field: string }[]>(eCommerceSeg);
  const [FunctionalSegment, setFunctionalSegment] = useState<{ question: string, field: string }[]>(functionalCapability);
  const [BusinessCustomer, setBusinessCustomer] = useState<{ question: string, field: string }[]>(businessCustomersSeg);
  const [mkSales, setMkSales] = useState<{ question: string, field: string }[]>(marketingSales);
  const [OwnerSeg, setOwnerSeg] = useState<{ question: string, field: string }[]>(owner);
  const [RevenueStream, setRevenueStream] = useState<{ question: string, field: string }[]>(revenue);
  const [CustomerSegment, setCustomerSegment] = useState<{ question: string, field: string }[]>(customerSegment);



  const [values, setValues] = useState<any>([]);
  const [customerRelationsValue, setCustomerReltionsValues] = useState<any>([]);
  const [channelValues, setChannelValues] = useState<any>([]);
  const [ECommerceValues, setECommeceValues] = useState<any>([]);
  const [functionalSegmentValues, setFunctionalSegmentValues] = useState<any>([]);
  const [OwnerSegValues, setOwnerSegValues] = useState<any>([]);
  const [businessCustomerValues, setBusinessCustomerValues] = useState<any>([]);
  const [customerSegmentValues, setCustomerSegmentValues] = useState<any>([]);
  const [revenueStreamValues, setRevenueStreamValues] = useState<any>([]);


  const user = supabase.auth.user()
  function Alert(props: any) {
    return <MuiAlert elevation={6} variant="filled" {...props} />;
  }
  const createReport = async () => {
    //Customer Relations
    const customerRel = [
      {
        key: customerRelationsValue.cusSeg == "yes" ? "Customer relationship management not established." : "Customer relationship management has been established.",
        value: customerRelationsValue.cusSeg == "yes" ? "No Recommendation" : "CRM",
        type: 1,
        question: 1
      },
      {
        key: customerRelationsValue.cusBase == "yes" ? "Processes for acquiring customers are not established." : "Processes for acquiring customers are established.",
        value: customerRelationsValue.cusBase == "yes" ? "No Recommendation" : "Sales Funnel",
        type: 1,
        question: 2
      },
      {
        key: customerRelationsValue.growingBase == "yes" ? "No processes in place for retaining customers" : "Processes in place for retaining customers.",
        value: customerRelationsValue.growingBase == "yes" ? "No Recommendation" : "CRM",
        type: 1,
        question: 2
      },
      {
        key: customerRelationsValue.processBase == "yes" ? "No systems in place for growing customers" : "systems in place for  growing customers.",
        value: customerRelationsValue.processBase == "yes" ? "No Recommendation" : "Sales planning, Customer acquistion plan, ",
        type: 1,
        question: 3
      },
      {
        key: customerRelationsValue.designatedCus == "yes" ? "Deos not have designated customer researcher" : "has designated customer researcher",
        value: customerRelationsValue.designatedCus == "yes" ? "No Recommendation" : "CRM",
        type: 1,
        question: 4
      }
    ]

    //Channels
    const channels = [
      {
        key: channelValues.reachCustomer == "yes" ? "Customer profile has been determined." : "Customer profile not determined",
        value: channelValues.reachCustomer == "yes" ? "No Recommendation" : "Social media marketing, marketing plan, marketing startegy, sales funnel, customer acquisition plan.",
        type: 1,
        question: 1,
        answered: channelValues.reachCustomer == "yes" || channelValues.reachCustomer == "no" ? true : false
      },
      {
        key: channelValues.marketingPlan == "yes" ? "Strategies to reach customers has been determined." : "Strategies to reach customers has not been determined.",
        value: channelValues.marketingPlan == "yes" ? "No Recommendation" : "Marketing Plan.",
        type: 1,
        question: 2,
        answered: channelValues.marketingPlan == "yes" || channelValues.marketingPlan == "no" ? true : false
      },
      {
        key: channelValues.developedNetwork == "yes" ? "Network to reach target audience has been determined." : "Network to reach target audience has been determined.",
        value: channelValues.developedNetwork == "yes" ? "No Recommendation" : "Sales Funnel",
        type: 1,
        question: 3,
        answered: channelValues.developedNetwork == "yes" || channelValues.developedNetwork == "no" ? true : false
      },
      {
        key: channelValues.customerSupport == "yes" ? "Post sales support has been provided." : "Post sales support is not provided.",
        value: channelValues.customerSupport == "yes" ? "No Recommendation" : "Sales personnel.",
        type: 1,
        question: 4,
        answered: channelValues.customerSupport == "yes" || channelValues.customerSupport == "no" ? true : false
      }
    ]

    // E-Commerce
    const eCommerce = [
      {
        key: ECommerceValues.canSellOnline === "yes" ? "Can Sell Online" : "Cannot sell online",
        value: ECommerceValues.canSellOnline === "yes" ? "No recommendation" : "eCommerce",
        type: 1,
        question: 1,
        answered: ECommerceValues.canSellOnline == "yes" || ECommerceValues.canSellOnline == "no" ? true : false
      }, {
        key: ECommerceValues.doesSellOnline === "yes" ? "Does sell online" : "Does not sell online",
        value: ECommerceValues.doesSellOnline === "yes" ? "No recommendation" : "Competitor analysis",
        type: 1,
        question: 2,
        answered: ECommerceValues.doesSellOnline == "yes" || ECommerceValues.doesSellOnline == "no" ? true : false
      },
      {
        key: ECommerceValues.canSetUp === "yes" ? "Can set up online shop" : "Cannot set up online shop",
        value: ECommerceValues.canSetUp === "yes" ? "No recommendation" : "eCommerce",
        type: 1,
        question: 3,
        answered: ECommerceValues.canSetUp == "yes" || ECommerceValues.canSetUp == "no" ? true : false
      },
      {
        key: ECommerceValues.onlinePresence === "yes" ? "Can set up online presence for the business" : "Can not set up online presence for the business",
        value: ECommerceValues.onlinePresence === "yes" ? "No recommendation" : "eCommerce",
        type: 1,
        question: 4,
        answered: ECommerceValues.onlinePresence == "yes" || ECommerceValues.onlinePresence == "no" ? true : false

      },
      {
        key: ECommerceValues.eComExperience === "yes" ? "Has an eCommerce Knowlegeable person" : "No eCommerce Knowlegeable person",
        value: ECommerceValues.eComExperience === "yes" ? "No recommendation" : "Jop Opportunity : eCommerce officer/specialist",
        type: 1,
        question: 5,
        answered: ECommerceValues.eComExperience == "yes" || ECommerceValues.eComExperience == "no" ? true : false
      }
    ]
    //Functional Capability
    const functionalSegment = [
      {
        key: functionalSegmentValues.sufficientAdministration == "yes" ? "There is an administration system that's in use in the company." : "No administration systems in place.",
        value: functionalSegmentValues.sufficientAdministration == "yes" ? "No recommendation" : "Process development & documentation",
        type: 2,
        question: 1,
        answered: functionalSegmentValues.sufficientAdministration == "yes" || functionalSegmentValues.sufficientAdministration == "no" ? true : false
      },
      {
        key: functionalSegmentValues.companyOrg == "yes" ? "Organizational structure is sufficient to deliver on product/service" : "Organizational structure not sufficient.",
        value: functionalSegmentValues.companyOrg == "yes" ? "No recommendation" : "Process development & documentation",
        type: 2,
        question: 2,
        answered: functionalSegmentValues.companyOrg == "yes" || functionalSegmentValues.companyOrg == "no" ? true : false
      }
    ]
    //Business Customer
    const businessCustomers = [
      {
        key: businessCustomerValues.businessPlan === "yes" ? "There is a business plan that has been drafted." : "No defined business plan.",
        value: businessCustomerValues.businessPlan === "yes" ? "No recommendation" : "Business Plan",
        type: 2,
        question: 1,
        answered: businessCustomerValues.businessPlan == "yes" || businessCustomerValues.businessPlan == "no" ? true : false
      },
      {
        key: businessCustomerValues.executePlan === "yes" ? "The company is currently executing the business plan." : "No defined business plan.",
        value: businessCustomerValues.executePlan === "yes" ? "No recommendation" : "Business Plan",
        type: 2,
        question: 2,
        answered: businessCustomerValues.executePlan == "yes" || businessCustomerValues.executePlan == "no" ? true : false
      },
      {
        key: businessCustomerValues.clientSatisfaction === "yes" ? "Client satisfaction measured by the company" : "Client satisfaction not measured.",
        value: businessCustomerValues.clientSatisfaction === "yes" ? "No recommendation" : "CRM",
        type: 2,
        question: 3,
        answered: businessCustomerValues.clientSatisfaction == "yes" || businessCustomerValues.clientSatisfaction == "no" ? true : false
      },
      {
        key: businessCustomerValues.clientEngagement === "yes" ? "Customer engagement is measured" : "Effectiveness of customer engagement not measured.",
        value: businessCustomerValues.clientEngagement === "yes" ? "No recommendation" : "CRM, Monitoring and Evaluation",
        type: 2,
        question: 4,
        answered: businessCustomerValues.clientEngagement == "yes" || businessCustomerValues.clientEngagement == "no" ? true : false
      }
    ]
    // Customer Segment
    const customerSegment = [
      {
        key: customerSegmentValues.productOwner == "yes" ? "Customer profile has been determined." : "Customer profile not determined",
        value: customerSegmentValues.productOwner == "yes" ? "No recommendation" : "Market Research",
        type: 1,
        question: 1,
        answered: customerSegmentValues.productOwner == "yes" || customerSegmentValues.productOwner == "no" ? true : false
      },
      {
        key: customerSegmentValues.tagetAudiance == "yes" ? "Target audience has been determined." : "Target audience has not been selected",
        value: customerSegmentValues.tagetAudiance == "yes" ? "No recommendation" : "Market Intelligence",
        type: 1,
        question: 2,
        answered: customerSegmentValues.tagetAudiance == "yes" || customerSegmentValues.tagetAudiance == "no" ? true : false
      },
      {
        key: customerSegmentValues.tagetAudianceLocation == "yes" ? "Target audience has been located geographically." : "Target audience has not been located geographically",
        value: customerSegmentValues.tagetAudianceLocation == "yes" ? "No recommendation" : "Market Research",
        type: 1,
        question: 3,
        answered: customerSegmentValues.tagetAudianceLocation == "yes" || customerSegmentValues.tagetAudianceLocation == "no" ? true : false
      },
      {
        key: customerSegmentValues.tagetMarketSize == "yes" ? "Target audience has been segmented." : "Target audience has not been segmented.",
        value: customerSegmentValues.tagetMarketSize == "yes" ? "No recommendation" : "SAM SOM TAM",
        type: 1,
        question: 4,
        answered: customerSegmentValues.tagetMarketSize == "yes" || customerSegmentValues.tagetMarketSize == "no" ? true : false
      },
      {
        key: customerSegmentValues.cusReach == "yes" ? "Total accessible market has been determined." : "Total accessible market has not been determined",
        value: customerSegmentValues.cusReach == "yes" ? "No recommendation" : "Market Strategy",
        type: 1,
        question: 5,
        answered: customerSegmentValues.cusReach == "yes" || customerSegmentValues.cusReach == "no" ? true : false
      },
      {
        key: customerSegmentValues.competitor == "yes" ? "Competitors have been identified" : "competitors have not been identified",
        value: customerSegmentValues.competitor == "yes" ? "No recommendation" : "Competitor Analysis",
        type: 1,
        question: 6,
        answered: customerSegmentValues.competitor == "yes" || customerSegmentValues.competitor == "no" ? true : false
      },
      {
        key: customerSegmentValues.marketAccess == "yes" ? "Total accessible market has been determined." : "Total accessible market has not been determined",
        value: customerSegmentValues.marketAccess == "yes" ? "No recommendation" : "Total Addressable market",
        type: 1,
        question: 7,
        answered: customerSegmentValues.marketAccess == "yes" || customerSegmentValues.marketAccess == "no" ? true : false
      },
      {
        key: customerSegmentValues.marketLocation == "yes" ? "Total observable market has been determined." : "Total observable market has not been determined.",
        value: customerSegmentValues.marketLocation == "yes" ? "No recommendation" : "Market Reasearch",
        type: 1,
        question: 8,
        answered: customerSegmentValues.marketLocation == "yes" || customerSegmentValues.marketLocation == "no" ? true : false
      },
      {
        key: customerSegmentValues.idealCustomer == "yes" ? "Ideal customer profile has been determined." : "Ideal customer profile has not been determined.",
        value: customerSegmentValues.idealCustomer == "yes" ? "No recommendation" : "Ideal Customer profile",
        type: 1,
        question: 9,
        answered: customerSegmentValues.idealCustomer == "yes" || customerSegmentValues.idealCustomer == "no" ? true : false
      },
      {
        key: customerSegmentValues.importantCustomer == "yes" ? "Most important not determined." : "Most important customers not determined",
        value: customerSegmentValues.importantCustomer == "yes" ? "No recommendation" : "Market Research",
        type: 1,
        question: 10,
        answered: customerSegmentValues.importantCustomer == "yes" || customerSegmentValues.importantCustomer == "no" ? true : false
      },
      {
        key: customerSegmentValues.customerReaserch == "yes" ? "Customer research has been done" : "Customer research has not been done",
        value: customerSegmentValues.customerReaserch == "yes" ? "No recommendation" : "Business Research Officer",
        type: 1,
        question: 11,
        answered: customerSegmentValues.customerReaserch == "yes" || customerSegmentValues.customerReaserch == "no" ? true : false
      }
    ]
    //Market and sales
    const Market = [
      {
        key: values.effectiveAd === "yes" ? "The advertising is effective" : "The advertising is not effective",
        value: values.effectiveAd === "yes" ? "No recommendation" : "marketing plan",
        type: 2,
        question: 1,
        amswered: values.effectiveAd == "yes" || values.effectiveAd == "no" ? true : false
      }, {
        key: values.companyAd === "yes" ? "The company does advertise" : "The company does not advertise",
        value: values.companyAd === "yes" ? "No recommendation" : "marketing plan",
        type: 2,
        question: 2,
        answered: values.companyAd == "yes" || values.companyAd == "no" ? true : false
      },
      {
        key: values.planning === "yes" ? "Sales Planning is conducted" : "Sales Planning is not conducted",
        value: values.planning === "yes" ? "No recommendation" : "Sales planning, Customer acquistion plan.",
        type: 2,
        question: 3,
        answered: values.planning == "yes" || values.planning == "no" ? true : false
      }, {
        key: values.priceStrategy === "yes" ? "Price strategy planning is done" : "Price strategy planning is not done",
        value: values.priceStrategy === "yes" ? "No recommendation" : "Revenue models",
        type: 2,
        question: 4,
        answered: values.priceStrategy == "yes" || values.priceStrategy == "no" ? true : false
      }, {
        key: values.priceReview === "yes" ? "Prive reviews are done" : "Prive reviews are not done",
        value: values.priceReview === "yes" ? "No recommendation" : "Costing, product & service pricing",
        type: 2,
        question: 5,
        answered: values.priceReview == "yes" || values.priceReview == "no" ? true : false
      }
    ]
    //Ownership and mindset
    const ownerM = [
      {
        key: OwnerSegValues.ownerExperience == "yes" ? "Owners have the required experience." : "Owners don't have required experience.",
        value: OwnerSegValues.ownerExperience == "yes" ? "No Recommendation" : "Founder skills and expertise",
        type: 2,
        question: 1,
        answered: OwnerSegValues.ownerExperience == "yes" || OwnerSegValues.ownerExperience == "no" ? true : false
      },
      {
        key: OwnerSegValues.ownerTime == "yes" ? "Owners work fulltime in the business." : "Owners work part-time in the business.",
        value: OwnerSegValues.ownerTime == "yes" ? "No Recommendation" : "Owner & management commitment",
        type: 2,
        question: 2,
        answered: OwnerSegValues.ownerTime == "yes" || OwnerSegValues.ownerTime == "no" ? true : false
      },
      {
        key: OwnerSegValues.ownerQualification == "yes" ? "Expertise are enough to deliver on the product/service." : "Not enough expertise to deliver on products/service.",
        value: OwnerSegValues.ownerQualification == "yes" ? "No Recommendation" : "Founder skills and expertise",
        type: 2,
        question: 3,
        answered: OwnerSegValues.ownerQualification == "yes" || OwnerSegValues.ownerQualification == "no" ? true : false
      }
    ]
    //Revenue Streams
    const revenue = [
      {
        key: revenueStreamValues.generatingRevenue == "yes" ? "Has Knowledge of how revenue is generated." : "Does not have Knowledge of how revenue is generated.",
        value: revenueStreamValues.generatingRevenue == "yes" ? "No Recommendation" : "Revenue models",
        type: 1,
        question: 1,
        answered: revenueStreamValues.generatingRevenue == "yes" || revenueStreamValues.generatingRevenue == "no" ? true : false
      },
      {
        key: revenueStreamValues.willingPay == "yes" ? "Value customers are willing to pay for has been determined." : "Value customers are willing to pay fpr not determined.",
        value: revenueStreamValues.willingPay == "yes" ? "No Recommendation" : "Proof of concept",
        type: 1,
        question: 2,
        answered: revenueStreamValues.willingPay == "yes" || revenueStreamValues.willingPay == "no" ? true : false
      },
      {
        key: revenueStreamValues.cusPaymentMethod == "yes" ? "Current payment trends of customers are known." : "Current payment trends of customers are not known.",
        value: revenueStreamValues.cusPaymentMethod == "yes" ? "No Recommendation" : "Competitor analysis",
        type: 1,
        question: 3,
        answered: revenueStreamValues.cusPaymentMethod == "yes" || revenueStreamValues.cusPaymentMethod == "no" ? true : false
      },
      {
        key: revenueStreamValues.preferedPayment == "yes" ? "Preferred paymet method of customers has been determined." : "Preferred paymet method of customers not determined.",
        value: revenueStreamValues.preferedPayment == "yes" ? "No Recommendation" : "Market research, competitor analysis",
        type: 1,
        question: 4,
        answered: revenueStreamValues.preferedPayment == "yes" || revenueStreamValues.preferedPayment == "no" ? true : false
      }
    ]
    //Ownership and mindset
    const owner = [
      {
        key: OwnerSegValues.ownerExperience == "yes" ? "Owners have the required experience." : "Owners don't have required experience.",
        value: OwnerSegValues.ownerExperience == "yes" ? "No Recommendation" : "Founder skills and expertise",
        type: 2,
        question: 1,
        answered: OwnerSegValues.ownerExperience == "yes" || OwnerSegValues.ownerExperience == "no" ? true : false
      },
      {
        key: OwnerSegValues.ownerTime == "yes" ? "Owners work fulltime in the business." : "Owners work part-time in the business.",
        value: OwnerSegValues.ownerTime == "yes" ? "No Recommendation" : "Owner & management commitment",
        type: 2,
        question: 2,
        answered: OwnerSegValues.ownerTime == "yes" || OwnerSegValues.ownerTime == "no" ? true : false
      },
      {
        key: OwnerSegValues.ownerQualification == "yes" ? "Expertise are enough to deliver on the product/service." : "Not enough expertise to deliver on products/service.",
        value: OwnerSegValues.ownerQualification == "yes" ? "No Recommendation" : "Founder skills and expertise",
        type: 2,
        question: 3,
        answered: OwnerSegValues.ownerQualification == "yes" || OwnerSegValues.ownerQualification == "no" ? true : false
      }
    ]




    const payload = {
      "segment": "No Money",
      "userId": user?.id,
      "segmentResponses": {
        "CustomerRelation": customerRel,
        "Channels": channels,
        "eCommerce": eCommerce,
        "Functional": functionalSegment,
        "BusinessCustomers": businessCustomers,
        "Customer": customerSegment,
        "Market": Market,
        "Revenue": revenue,
        "OwnershipMindset": owner,

      },
      "segmentValues": {
        "customerRelationsValue": customerRelationsValue,
        "channelValues": channelValues,
        "ECommerceValues": ECommerceValues,
        "functionalSegmentValues": functionalSegmentValues,
        "businessCustomerValues": businessCustomerValues,
        "customerSegmentValues": customerSegmentValues,
        "values": values,
        "revenueStreamValues": revenueStreamValues,
        "OwnerSegValues": OwnerSegValues,
      }

    } as INoMoney
    console.log("array of answers", payload)
    const isUpdate = recommendation.segmentResponses ? true : false;
    if (isUpdate) {
      await supabase
        .from('Recomendations')
        .update({
          segmentResponses: {
            "CustomerRelation": customerRel,
            "Channels": channels,
            "eCommerce": eCommerce,
            "Functional": functionalSegment,
            "BusinessCustomers": businessCustomers,
            "Customer": customerSegment,
            "Market": Market,
            "Revenue": revenue,
            "OwnershipMindset": owner
          }
        })
        .eq('id', recommendation.id);

      await supabase
        .from('Recomendations')
        .update({
          segmentValues: {
            "customerRelationsValue": customerRelationsValue,
            "channelValues": channelValues,
            "ECommerceValues": ECommerceValues,
            "functionalSegmentValues": functionalSegmentValues,
            "businessCustomerValues": businessCustomerValues,
            "customerSegmentValues": customerSegmentValues,
            "values": values,
            "revenueStreamValues": revenueStreamValues,
            "OwnerSegValues": OwnerSegValues,
          }
        })
        .eq('id', recommendation.id)

    } else {
      const result = await Api.POST_CreateMoneyRecommendation(payload)
      navigate('/HealthReport', { state: { bizInd: bizInd, bizPhase: bizPhase } });
      console.log('Result is', result)
    }

  }



  const handleChangeCustomrRelSegment = (question: string, field: string, event: React.ChangeEvent<HTMLInputElement>, index: number) => {
    const indexOfObject = CustomerRelations.findIndex(object => {
      return object.question === question;
    });
    setCustomerReltionsValues({ ...customerRelationsValue, [field]: (event.target as HTMLInputElement).value });

    CustomerRelations.splice(indexOfObject, 1);
  };


  const handleChangeChannelsSegment = (question: string, field: string, event: React.ChangeEvent<HTMLInputElement>, index: number) => {
    const indexOfObject = Channel.findIndex(object => {
      return object.question === question;
    });
    setChannelValues({ ...channelValues, [field]: (event.target as HTMLInputElement).value });

    Channel.splice(indexOfObject, 1);
  };
  const handleChangeeCommerceSegment = (question: string, field: string, event: React.ChangeEvent<HTMLInputElement>, index: number) => {
    const indexOfObject = eCommerce.findIndex(object => {
      return object.question === question;
    });
    setECommeceValues({ ...ECommerceValues, [field]: (event.target as HTMLInputElement).value });

    eCommerce.splice(indexOfObject, 1);
  };
  const handleChangeFunctional = (question: string, field: string, event: React.ChangeEvent<HTMLInputElement>, index: number) => {
    const indexOfObject = FunctionalSegment.findIndex(object => {
      return object.question === question;
    });
    setFunctionalSegmentValues({ ...functionalSegmentValues, [field]: (event.target as HTMLInputElement).value });

    FunctionalSegment.splice(indexOfObject, 1);
  };

  const handleChangeCustomerSegment = (question: string, field: string, event: React.ChangeEvent<HTMLInputElement>, index: number) => {
    const indexOfObject = CustomerSegment.findIndex(object => {
      return object.question === question;
    });
    setCustomerSegmentValues({ ...customerSegmentValues, [field]: (event.target as HTMLInputElement).value });

    CustomerSegment.splice(indexOfObject, 1);
  };
  const handleChangeBusinessCusSegment = (question: string, field: string, event: React.ChangeEvent<HTMLInputElement>, index: number) => {
    const indexOfObject = BusinessCustomer.findIndex(object => {
      return object.question === question;
    });
    setBusinessCustomerValues({ ...businessCustomerValues, [field]: (event.target as HTMLInputElement).value });

    BusinessCustomer.splice(indexOfObject, 1);
  };

  const handleChangeMarketingAndSales = (question: string, field: string, event: React.ChangeEvent<HTMLInputElement>, index: number) => {
    // console.log(index, question, field)
    const indexOfObject = mkSales.findIndex(object => {
      return object.question === question;
    });
    setValues({ ...values, [field]: (event.target as HTMLInputElement).value });

    mkSales.splice(indexOfObject, 1);
  };
  const handleChangeRevenueSegment = (question: string, field: string, event: React.ChangeEvent<HTMLInputElement>, index: number) => {
    const indexOfObject = RevenueStream.findIndex(object => {
      return object.question === question;
    });
    setRevenueStreamValues({ ...revenueStreamValues, [field]: (event.target as HTMLInputElement).value });

    RevenueStream.splice(indexOfObject, 1);
  };
  const handleChangeOwnerSegment = (question: string, field: string, event: React.ChangeEvent<HTMLInputElement>, index: number) => {
    const indexOfObject = OwnerSeg.findIndex(object => {
      return object.question === question;
    });
    setOwnerSegValues({ ...OwnerSegValues, [field]: (event.target as HTMLInputElement).value });

    OwnerSeg.splice(indexOfObject, 1);
  };
  const state = useSelector(selectRecomendationState);
  const recommendation: any = state.persistedReducer.RecomendationReducer.selectedRecomendation;
  console.log(recommendation)
  console.log(customerSegment);
  //Customer Relations
  let customerRelationsQuestions: { question: string, field: string }[] = []

  if (recommendation.segmentResponses) {
    customerRelations.forEach(question => {
      if (recommendation.segmentResponses?.CustomerRelation.some((res: any) => res.question == question.number && !res.answered)) {
        customerRelationsQuestions.push(question);
      }
    });
  } else {
    customerRelationsQuestions = [...customerRelations]
  }
  //e-Commerce
  let commerceQuestions: { question: string, field: string }[] = []


  if (recommendation.segmentResponses) {
    eCommerceSeg.forEach(question => {
      if (recommendation.segmentResponses?.eCommerce.some((res: any) => res.question == question.number && !res.answered)) {
        commerceQuestions.push(question);
      }
    });
  } else {
    commerceQuestions = [...eCommerceSeg]
  }
  //Channel
  let channelQuestions: { question: string, field: string }[] = [...channels]

  if (recommendation.segmentResponses) {
    channels.forEach(question => {
      if (recommendation.segmentResponses?.Channels.some((res: any) => res.question == question.number && !res.answered)) {
        customerSegmentQuestions.push(question);
      }
    });
  } else {
    channelQuestions = [...channels]
  }
  //Functional
  let functionalQuestions: { question: string, field: string }[] = []

  if (recommendation.segmentResponses) {
    functionalCapability.forEach(question => {
      if (recommendation.segmentResponses?.Functional.some((res: any) => res.question == question.number && !res.answered)) {
        functionalQuestions.push(question);
      }
    });
  } else {
    functionalQuestions = [...functionalCapability]
  }
  // Customer
  let customerSegmentQuestions: { question: string, field: string }[] = []

  if (recommendation.segmentResponses) {
    customerSegment.forEach(question => {
      if (recommendation.segmentResponses?.Customer.some((res: any) => res.question == question.number && !res.answered)) {
        customerSegmentQuestions.push(question);
      }
    });
  } else {
    customerSegmentQuestions = [...customerSegment]
  }
  //Business And Customers
  let businessCustomerQuestions: { question: string, field: string }[] = [...businessCustomersSeg]

  if (recommendation.segmentResponses) {
    businessCustomersSeg.forEach(question => {
      if (recommendation.segmentResponses?.BusinessCustomers.some((res: any) => res.question == question.number && !res.answered)) {
        businessCustomerQuestions.push(question);
      }
    });
  } else {
    businessCustomerQuestions = [...businessCustomersSeg]
  }
  //MArket
  let marketSalesQuestions: { question: string, field: string }[] = []

  if (recommendation.segmentResponses) {
    marketingSales.forEach(question => {
      if (recommendation.segmentResponses?.Market.some((res: any) => res.question == question.number && !res.answered)) {
        marketSalesQuestions.push(question);
      }
    });
  } else {
    marketSalesQuestions = [...marketingSales]
  }

  //Revenue
  let revenueQuestions: { question: string, field: string }[] = []

  if (recommendation.segmentResponses) {
    revenue.forEach(question => {
      if (recommendation.segmentResponses?.Revenue.some((res: any) => res.question == question.number && !res.answered)) {
        revenueQuestions.push(question);
      }
    });
  } else {
    revenueQuestions = [...revenue]
  }
  //Ownership Mindset
  let ownerQuestions: { question: string, field: string }[] = []

  if (recommendation.segmentResponses) {
    owner.forEach(question => {
      if (recommendation.segmentResponses?.OwnershipMindset.some((res: any) => res.question == question.number && !res.answered)) {
        ownerQuestions.push(question);
      }
    });
  } else {
    ownerQuestions = [...owner]
  }
  if (recommendation?.segmentValues && recommendation.segmentValues.customerRelationsValue) {
    setCustomerReltionsValues(recommendation.segmentValues.customerRelationsValue);
  }
  if (recommendation?.segmentValues && recommendation.segmentValues.channelValues) {
    setChannelValues(recommendation.segmentValues.channelValues);
  }
  if (recommendation?.segmentValues && recommendation.segmentValues.ECommeceValues) {
    setECommeceValues(recommendation.segmentValues.ECommeceValues);
  }
  if (recommendation?.segmentValues && recommendation.segmentValues.customerSegmentValues) {
    setCustomerSegmentValues(recommendation.segmentValues.customerSegmentValues);
  }
  if (recommendation?.segmentValues && recommendation.segmentValues.revenueStreamValues) {
    debugger
    setRevenueStreamValues(recommendation.segmentValues.revenueStreamValues);
  }
  if (recommendation?.segmentValues && recommendation.segmentValues.businessCustomerValues) {
    setBusinessCustomerValues(recommendation.segmentValues.businessCustomerValues);
  }
  if (recommendation?.segmentValues && recommendation.segmentValues.marketSaleValues) {
    setValues(recommendation.segmentValues.marketSaleValues);
  }
  if (recommendation?.segmentValues && recommendation.segmentValues.functionalSegmentValues) {
    setFunctionalSegmentValues(recommendation.segmentValues.functionalSegmentValues);
  }
  if (recommendation?.segmentValues && recommendation.segmentValues.OwnerSegValues) {
    setOwnerSegValues(recommendation.segmentValues.OwnerSegValues);
  }

  return (
    <div className='Basic'>
      <UserNavbar />
      <Container>
        <Grid container spacing={2}>
          <Grid item xs={12} sm={12} md={4} lg={4}>
            <Typography>Company</Typography>
            <Button
              className='profAdd'
              variant='outlined'
            >
              Add Company
            </Button>
            <div className='Accords'>
              <div className='sideAccord'>
                <AccessmentAccordion setSelectedRecommedation ={false}/>
              </div>
            </div>
          </Grid>
          <Grid item xs={12} sm={12} md={8} lg={8}>
            <Alert style={{ backgroundColor: "#00d3dd" }} severity="info">Next Step! Complete your Company Assessment.</Alert>
            <Typography className='biz' variant='h5'>Biz Assessment</Typography>
            <div className='companyBox'>
              <img
                src={company}
                alt='comLogo'
                className='company'
              />
              <div className='companyInf'>
                <div className='Location'>
                  <Typography>Location: N/A</Typography>
                </div>
                <div className='indust'>
                  <Typography>Industry: {bizInd[0].label}</Typography>
                </div>
                <div className='phase'>
                  <Typography>Business Phase: {bizPhase[0].label}</Typography>
                </div>
              </div>
            </div>
            <div className='bassicAccords'>
              <Accordion>
                <AccordionSummary
                  expandIcon={<ExpandMoreIcon />}
                  aria-controls="panel2a-content"
                  id="panel2a-header"
                >
                  <Typography className="">Customer Relations</Typography>
                </AccordionSummary>
                <AccordionDetails>
                  <div className='rev'>
                    {
                      customerRelationsQuestions.map((val, index) => {
                        return (
                          <div key={index}>
                            <FormControl>
                              <FormLabel id="demo-controlled-radio-buttons-group">
                                {val.question}
                              </FormLabel>
                              <RadioGroup
                                aria-labelledby="demo-controlled-radio-buttons-group"
                                //name="controlled-radio-buttons-group"
                                value={values[index]}
                                onChange={(e) => handleChangeCustomrRelSegment(val.question, val.field, e, index)}
                              >
                                <FormControlLabel value="yes" checked={false} control={<Radio />} label="Yes" />
                                <FormControlLabel value="no" checked={false} control={<Radio />} label="No" />

                              </RadioGroup>
                            </FormControl>
                          </div>
                        )

                      })
                    }
                  </div>
                </AccordionDetails>
              </Accordion>
              <Accordion>
                <AccordionSummary
                  expandIcon={<ExpandMoreIcon />}
                  aria-controls="panel2a-content"
                  id="panel2a-header"
                >
                  <Typography className="">Channels</Typography>
                </AccordionSummary>
                <AccordionDetails>
                  <div className='rev'>
                    {
                      channelQuestions.map((val, index) => {
                        return (
                          <div key={index}>
                            <FormControl>
                              <FormLabel id="demo-controlled-radio-buttons-group">
                                {val.question}
                              </FormLabel>
                              <RadioGroup
                                aria-labelledby="demo-controlled-radio-buttons-group"
                                //name="controlled-radio-buttons-group"
                                value={values[index]}
                                onChange={(e) => handleChangeChannelsSegment(val.question, val.field, e, index)}
                              >
                                <FormControlLabel value="yes" checked={false} control={<Radio />} label="Yes" />
                                <FormControlLabel value="no" checked={false} control={<Radio />} label="No" />

                              </RadioGroup>
                            </FormControl>
                          </div>
                        )

                      })
                    }
                  </div>
                </AccordionDetails>
              </Accordion>
              <Accordion>
                <AccordionSummary
                  expandIcon={<ExpandMoreIcon />}
                  aria-controls="panel2a-content"
                  id="panel2a-header"
                >
                  <Typography className=''>e-Commerce</Typography>
                </AccordionSummary>
                <AccordionDetails>
                  <div className='rev'>
                    {
                      commerceQuestions.map((val, index) => {
                        return (
                          <div key={index}>
                            <FormControl>
                              <FormLabel id="demo-controlled-radio-buttons-group">
                                {val.question}
                              </FormLabel>
                              <RadioGroup
                                aria-labelledby="demo-controlled-radio-buttons-group"
                                //name="controlled-radio-buttons-group"
                                value={values[index]}
                                onChange={(e) => handleChangeeCommerceSegment(val.question, val.field, e, index)}
                              >
                                <FormControlLabel value="yes" checked={false} control={<Radio />} label="Yes" />
                                <FormControlLabel value="no" checked={false} control={<Radio />} label="No" />

                              </RadioGroup>
                            </FormControl>
                          </div>
                        )

                      })
                    }
                  </div>
                </AccordionDetails>
              </Accordion>
              <Accordion>
                <AccordionSummary
                  expandIcon={<ExpandMoreIcon />}
                  aria-controls="panel2a-content"
                  id="panel2a-header"
                >
                  <Typography className=''>Functional Capability</Typography>
                </AccordionSummary>
                <AccordionDetails>
                  <div className='rev'>
                    {
                      functionalQuestions.map((val, index) => {
                        return (
                          <div key={index}>
                            <FormControl>
                              <FormLabel id="demo-controlled-radio-buttons-group">
                                {val.question}
                              </FormLabel>
                              <RadioGroup
                                aria-labelledby="demo-controlled-radio-buttons-group"
                                //name="controlled-radio-buttons-group"
                                value={values[index]}
                                onChange={(e) => handleChangeFunctional(val.question, val.field, e, index)}
                              >
                                <FormControlLabel value="yes" checked={false} control={<Radio />} label="Yes" />
                                <FormControlLabel value="no" checked={false} control={<Radio />} label="No" />

                              </RadioGroup>
                            </FormControl>
                          </div>
                        )

                      })
                    }
                  </div>
                </AccordionDetails>
              </Accordion>
              <Accordion>
                <AccordionSummary
                  expandIcon={<ExpandMoreIcon />}
                  aria-controls="panel2a-content"
                  id="panel2a-header"
                >
                  <Typography className=''>Customer segment</Typography>
                </AccordionSummary>
                <AccordionDetails>
                  <div className='rev'>
                    {
                      customerSegmentQuestions.map((val, index) => {
                        return (
                          <div key={index}>
                            <FormControl>
                              <FormLabel id="demo-controlled-radio-buttons-group">
                                {val.question}
                              </FormLabel>
                              <RadioGroup
                                aria-labelledby="demo-controlled-radio-buttons-group"
                                //name="controlled-radio-buttons-group"
                                value={values[index]}
                                onChange={(e) => handleChangeCustomerSegment(val.question, val.field, e, index)}
                              >
                                <FormControlLabel value="yes" checked={false} control={<Radio />} label="Yes" />
                                <FormControlLabel value="no" checked={false} control={<Radio />} label="No" />

                              </RadioGroup>
                            </FormControl>
                          </div>
                        )

                      })
                    }
                  </div>
                </AccordionDetails>
              </Accordion>
              <Accordion>
                <AccordionSummary
                  expandIcon={<ExpandMoreIcon />}
                  aria-controls="panel2a-content"
                  id="panel2a-header"
                >
                  <Typography className=''>Business and Customers</Typography>
                </AccordionSummary>
                <AccordionDetails>
                  <div className='rev'>
                    {
                      businessCustomerQuestions.map((val, index) => {
                        return (
                          <div key={index}>
                            <FormControl>
                              <FormLabel id="demo-controlled-radio-buttons-group">
                                {val.question}
                              </FormLabel>
                              <RadioGroup
                                aria-labelledby="demo-controlled-radio-buttons-group"
                                //name="controlled-radio-buttons-group"
                                value={values[index]}
                                onChange={(e) => handleChangeBusinessCusSegment(val.question, val.field, e, index)}
                              >
                                <FormControlLabel value="yes" checked={false} control={<Radio />} label="Yes" />
                                <FormControlLabel value="no" checked={false} control={<Radio />} label="No" />

                              </RadioGroup>
                            </FormControl>
                          </div>
                        )

                      })
                    }
                  </div>
                </AccordionDetails>
              </Accordion>
              <Accordion>
                <AccordionSummary
                  expandIcon={<ExpandMoreIcon />}
                  aria-controls="panel2a-content"
                  id="panel2a-header"
                >
                  <Typography className=''>Marketing and Sales</Typography>
                </AccordionSummary>
                <AccordionDetails>
                  <div className='rev'>
                    {
                      marketSalesQuestions.map((val, index) => {
                        return (
                          <div key={index}>
                            <FormControl>
                              <FormLabel id="demo-controlled-radio-buttons-group">
                                {val.question}
                              </FormLabel>
                              <RadioGroup
                                aria-labelledby="demo-controlled-radio-buttons-group"
                                //name="controlled-radio-buttons-group"
                                value={values[index]}
                                onChange={(e) => handleChangeMarketingAndSales(val.question, val.field, e, index)}
                              >
                                <FormControlLabel value="yes" checked={false} control={<Radio />} label="Yes" />
                                <FormControlLabel value="no" checked={false} control={<Radio />} label="No" />

                              </RadioGroup>
                            </FormControl>
                          </div>
                        )

                      })
                    }
                  </div>
                </AccordionDetails>
              </Accordion>
              <Accordion>
                <AccordionSummary
                  expandIcon={<ExpandMoreIcon />}
                  aria-controls="panel2a-content"
                  id="panel2a-header"
                >
                  <Typography className=''>Revenue Streams</Typography>
                </AccordionSummary>
                <AccordionDetails>
                  <div className='rev'>
                    {
                      revenueQuestions.map((val, index) => {
                        return (
                          <div key={index}>
                            <FormControl>
                              <FormLabel id="demo-controlled-radio-buttons-group">
                                {val.question}
                              </FormLabel>
                              <RadioGroup
                                aria-labelledby="demo-controlled-radio-buttons-group"
                                //name="controlled-radio-buttons-group"
                                value={values[index]}
                                onChange={(e) => handleChangeRevenueSegment(val.question, val.field, e, index)}
                              >
                                <FormControlLabel value="yes" checked={false} control={<Radio />} label="Yes" />
                                <FormControlLabel value="no" checked={false} control={<Radio />} label="No" />

                              </RadioGroup>
                            </FormControl>
                          </div>
                        )

                      })
                    }
                  </div>

                </AccordionDetails>
              </Accordion>
              <Accordion>
                <AccordionSummary
                  expandIcon={<ExpandMoreIcon />}
                  aria-controls="panel2a-content"
                  id="panel2a-header"
                >
                  <Typography className=''>Ownership and Mindset</Typography>
                </AccordionSummary>
                <AccordionDetails>
                  <div className='rev'>
                    {
                      ownerQuestions.map((val, index) => {
                        return (
                          <div key={index}>
                            <FormControl>
                              <FormLabel id="demo-controlled-radio-buttons-group">
                                {val.question}
                              </FormLabel>
                              <RadioGroup
                                aria-labelledby="demo-controlled-radio-buttons-group"
                                //name="controlled-radio-buttons-group"
                                value={values[index]}
                                onChange={(e) => handleChangeOwnerSegment(val.question, val.field, e, index)}
                              >
                                <FormControlLabel value="yes" checked={false} control={<Radio />} label="Yes" />
                                <FormControlLabel value="no" checked={false} control={<Radio />} label="No" />

                              </RadioGroup>
                            </FormControl>
                          </div>
                        )

                      })
                    }
                  </div>
                </AccordionDetails>
              </Accordion>
            </div>

            <div className='AssesButtonsA'>
              <Button
                variant='outlined'
                className='AssesBack'
              >
                Back
              </Button>
              <Button
                variant='outlined'
                className='AssesSave'
                onClick={() => createReport()}

              >
                Save

              </Button>
            </div>
          </Grid>
        </Grid>
      </Container>
      <div className='footD'>
        <Footernew />
      </div>
    </div>
  )
}

export default NoMoney;
// export const { save } = actions;
// export default reducer;

//try Export at the top