import React, { useEffect, useState } from 'react';
import { Container, Grid, Button } from '@material-ui/core';
import Accordion from '@material-ui/core/Accordion';
import AccordionSummary from '@material-ui/core/AccordionSummary';
import AccordionDetails from '@material-ui/core/AccordionDetails';
import Typography from '@material-ui/core/Typography';
import ExpandMoreIcon from '@material-ui/icons/ExpandMore';
import MuiAlert from '@material-ui/lab/Alert';
import UserNavbar from '../../UserNav/UserNav';
import company from '../../../Images/company.png'
import Radio from "@mui/material/Radio";
import RadioGroup from "@mui/material/RadioGroup";
import FormControlLabel from "@mui/material/FormControlLabel";
import FormControl from "@mui/material/FormControl";
import FormLabel from "@mui/material/FormLabel";
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { createSlice } from '@reduxjs/toolkit';
import { Api } from '../../../services/endpoints';
import { IRecomendation, IPoor } from '../../../Interfaces/IRecomendation'
import Footernew from '../../Footer/Footernew';
import { supabase } from '../../../supabaseClient';
import eCommerceSeg from '../../../json/eCommerce.json'
import customerSegment from '../../../json/customerSegment.json';
import businessCustomersSeg from '../../../json/businessCustomers.json';
import marketingSales from '../../../json/marketingSales.json';
import owner from '../../../json/ownershipMindset.json'
import marketIntSeg from "../../../json/marketInteligence.json"
import delivery from '../../../json/deliveryExpertise.json';
import valuePropositionSegment from '../../../json/valueProposition.json';
import keyActivitiesSegment from '../../../json/keyActivities.json';
import current from '../../../json/currentAlternatives.json'
import partners from '../../../json/keyPartners.json'
import keyResourcesSegment from '../../../json/keyResources.json';
import { useSelector } from 'react-redux';
import { selectRecomendationState } from "../../../Slice/createSlice";
import AccessmentAccordion from '../../AssessmentsAccordion/AccessmentsAccordion';
import '../Assessment.css'

type LocationState = {
  bizInd: Array<{
    value: number;
    label: string
  }>,
  bizPhase: Array<{
    value: number;
    label: string
  }>
}




const PoorSales = () => {
  const location = useLocation();
  const bizInd = (location.state as LocationState)?.bizInd;
  const bizPhase = (location.state as LocationState)?.bizPhase;
  const navigate = useNavigate();
  // const [value, setValue] = React.useState('');
  const [eCommerce, setEcommerce] = useState<{ question: string, field: string }[]>(eCommerceSeg);
  const [BusinessCustomer, setBusinessCustomer] = useState<{ question: string, field: string }[]>(businessCustomersSeg);
  const [mkSales, setMkSales] = useState<{ question: string, field: string }[]>(marketingSales);
  const [DeliverySeg, setDeliverySeg] = useState<{ question: string, field: string }[]>(delivery);
  const [MarketInt, setMarketInt] = useState<{ question: string, field: string }[]>(marketIntSeg);
  const [OwnerSeg, setOwnerSeg] = useState<{ question: string, field: string }[]>(owner);
  const [CustomerSegment, setCustomerSegment] = useState<{ question: string, field: string }[]>(customerSegment);
  const [PropositionSegment, setPropositionSegment] = useState<{ question: string, field: string }[]>(valuePropositionSegment);
  const [KeyResourcesSegment, setKeyResourcesSegment] = useState<{ question: string, field: string }[]>(keyResourcesSegment);
  const [CurrentAlternativeSegment, setCurrentAlternativeSegment] = useState<{ question: string, field: string }[]>(current);
  const [KeyActivitiesSegment, setKeyActivitiesSegment] = useState<{ question: string, field: string }[]>(keyActivitiesSegment);
  const [KeyPartnersSegment, setKeyPartnersSegment] = useState<{ question: string, field: string }[]>(partners);


  const [values, setValues] = useState<any>([]);
  const [ECommerceValues, setECommeceValues] = useState<any>([]);
  const [OwnerSegValues, setOwnerSegValues] = useState<any>([]);
  const [deliverySegValues, setDeliverySegValues] = useState<any>([]);
  const [businessCustomerValues, setBusinessCustomerValues] = useState<any>([]);
  const [marketIntValues, setmarketIntValues] = useState<any>([]);
  const [customerSegmentValues, setCustomerSegmentValues] = useState<any>([]);
  const [propositionSegmentValues, setPropositionSegmentValues] = useState<any>([]);
  const [keyActivitiesSegmentValues, setKeyActivitiesSegmentValues] = useState<any>([]);
  const [currentAlternativeSegmentValues, setcurrentAlternativeSegmentValues] = useState<any>([]);
  const [keyResourcesSegmentValues, setKeyResourcesSegmentValues] = useState<any>([]);
  const [keyPartnersSegmentValues, setKeyPartnersSegmentValues] = useState<any>([]);



  const user = supabase.auth.user()
  function Alert(props: any) {
    return <MuiAlert elevation={6} variant="filled" {...props} />;
  }
  const createReport = async () => {
    // E-Commerce
    const eCommerce = [
      {
        key: ECommerceValues.canSellOnline === "yes" ? "Can Sell Online" : "Cannot sell online",
        value: ECommerceValues.canSellOnline === "yes" ? "No recommendation" : "eCommerce",
        type: 1,
        question: 1,
        answered: ECommerceValues.canSellOnline == "yes" || ECommerceValues.canSellOnline == "no" ? true : false
      }, {
        key: ECommerceValues.doesSellOnline === "yes" ? "Does sell online" : "Does not sell online",
        value: ECommerceValues.doesSellOnline === "yes" ? "No recommendation" : "Competitor analysis",
        type: 1,
        question: 2,
        answered: ECommerceValues.doesSellOnline == "yes" || ECommerceValues.doesSellOnline == "no" ? true : false
      },
      {
        key: ECommerceValues.canSetUp === "yes" ? "Can set up online shop" : "Cannot set up online shop",
        value: ECommerceValues.canSetUp === "yes" ? "No recommendation" : "eCommerce",
        type: 1,
        question: 3,
        answered: ECommerceValues.canSetUp == "yes" || ECommerceValues.canSetUp == "no" ? true : false
      },
      {
        key: ECommerceValues.onlinePresence === "yes" ? "Can set up online presence for the business" : "Can not set up online presence for the business",
        value: ECommerceValues.onlinePresence === "yes" ? "No recommendation" : "eCommerce",
        type: 1,
        question: 4,
        answered: ECommerceValues.onlinePresence == "yes" || ECommerceValues.onlinePresence == "no" ? true : false

      },
      {
        key: ECommerceValues.eComExperience === "yes" ? "Has an eCommerce Knowlegeable person" : "No eCommerce Knowlegeable person",
        value: ECommerceValues.eComExperience === "yes" ? "No recommendation" : "Jop Opportunity : eCommerce officer/specialist",
        type: 1,
        question: 5,
        answered: ECommerceValues.eComExperience == "yes" || ECommerceValues.eComExperience == "no" ? true : false
      }
    ]
    //Business Customer
    const businessCustomers = [
      {
        key: businessCustomerValues.businessPlan === "yes" ? "There is a business plan that has been drafted." : "No defined business plan.",
        value: businessCustomerValues.businessPlan === "yes" ? "No recommendation" : "Business Plan",
        type: 2,
        question: 1,
        answered: businessCustomerValues.businessPlan == "yes" || businessCustomerValues.businessPlan == "no" ? true : false
      },
      {
        key: businessCustomerValues.executePlan === "yes" ? "The company is currently executing the business plan." : "No defined business plan.",
        value: businessCustomerValues.executePlan === "yes" ? "No recommendation" : "Business Plan",
        type: 2,
        question: 2,
        answered: businessCustomerValues.executePlan == "yes" || businessCustomerValues.executePlan == "no" ? true : false
      },
      {
        key: businessCustomerValues.clientSatisfaction === "yes" ? "Client satisfaction measured by the company" : "Client satisfaction not measured.",
        value: businessCustomerValues.clientSatisfaction === "yes" ? "No recommendation" : "CRM",
        type: 2,
        question: 3,
        answered: businessCustomerValues.clientSatisfaction == "yes" || businessCustomerValues.clientSatisfaction == "no" ? true : false
      },
      {
        key: businessCustomerValues.clientEngagement === "yes" ? "Customer engagement is measured" : "Effectiveness of customer engagement not measured.",
        value: businessCustomerValues.clientEngagement === "yes" ? "No recommendation" : "CRM, Monitoring and Evaluation",
        type: 2,
        question: 4,
        answered: businessCustomerValues.clientEngagement == "yes" || businessCustomerValues.clientEngagement == "no" ? true : false
      }
    ]
    // Customer Segment
    const customerSegment = [
      {
        key: customerSegmentValues.productOwner == "yes" ? "Customer profile has been determined." : "Customer profile not determined",
        value: customerSegmentValues.productOwner == "yes" ? "No recommendation" : "Market Research",
        type: 1,
        question: 1,
        answered: customerSegmentValues.productOwner == "yes" || customerSegmentValues.productOwner == "no" ? true : false
      },
      {
        key: customerSegmentValues.tagetAudiance == "yes" ? "Target audience has been determined." : "Target audience has not been selected",
        value: customerSegmentValues.tagetAudiance == "yes" ? "No recommendation" : "Market Intelligence",
        type: 1,
        question: 2,
        answered: customerSegmentValues.tagetAudiance == "yes" || customerSegmentValues.tagetAudiance == "no" ? true : false
      },
      {
        key: customerSegmentValues.tagetAudianceLocation == "yes" ? "Target audience has been located geographically." : "Target audience has not been located geographically",
        value: customerSegmentValues.tagetAudianceLocation == "yes" ? "No recommendation" : "Market Research",
        type: 1,
        question: 3,
        answered: customerSegmentValues.tagetAudianceLocation == "yes" || customerSegmentValues.tagetAudianceLocation == "no" ? true : false
      },
      {
        key: customerSegmentValues.tagetMarketSize == "yes" ? "Target audience has been segmented." : "Target audience has not been segmented.",
        value: customerSegmentValues.tagetMarketSize == "yes" ? "No recommendation" : "SAM SOM TAM",
        type: 1,
        question: 4,
        answered: customerSegmentValues.tagetMarketSize == "yes" || customerSegmentValues.tagetMarketSize == "no" ? true : false
      },
      {
        key: customerSegmentValues.cusReach == "yes" ? "Total accessible market has been determined." : "Total accessible market has not been determined",
        value: customerSegmentValues.cusReach == "yes" ? "No recommendation" : "Market Strategy",
        type: 1,
        question: 5,
        answered: customerSegmentValues.cusReach == "yes" || customerSegmentValues.cusReach == "no" ? true : false
      },
      {
        key: customerSegmentValues.competitor == "yes" ? "Competitors have been identified" : "competitors have not been identified",
        value: customerSegmentValues.competitor == "yes" ? "No recommendation" : "Competitor Analysis",
        type: 1,
        question: 6,
        answered: customerSegmentValues.competitor == "yes" || customerSegmentValues.competitor == "no" ? true : false
      },
      {
        key: customerSegmentValues.marketAccess == "yes" ? "Total accessible market has been determined." : "Total accessible market has not been determined",
        value: customerSegmentValues.marketAccess == "yes" ? "No recommendation" : "Total Addressable market",
        type: 1,
        question: 7,
        answered: customerSegmentValues.marketAccess == "yes" || customerSegmentValues.marketAccess == "no" ? true : false
      },
      {
        key: customerSegmentValues.marketLocation == "yes" ? "Total observable market has been determined." : "Total observable market has not been determined.",
        value: customerSegmentValues.marketLocation == "yes" ? "No recommendation" : "Market Reasearch",
        type: 1,
        question: 8,
        answered: customerSegmentValues.marketLocation == "yes" || customerSegmentValues.marketLocation == "no" ? true : false
      },
      {
        key: customerSegmentValues.idealCustomer == "yes" ? "Ideal customer profile has been determined." : "Ideal customer profile has not been determined.",
        value: customerSegmentValues.idealCustomer == "yes" ? "No recommendation" : "Ideal Customer profile",
        type: 1,
        question: 9,
        answered: customerSegmentValues.idealCustomer == "yes" || customerSegmentValues.idealCustomer == "no" ? true : false
      },
      {
        key: customerSegmentValues.importantCustomer == "yes" ? "Most important not determined." : "Most important customers not determined",
        value: customerSegmentValues.importantCustomer == "yes" ? "No recommendation" : "Market Research",
        type: 1,
        question: 10,
        answered: customerSegmentValues.importantCustomer == "yes" || customerSegmentValues.importantCustomer == "no" ? true : false
      },
      {
        key: customerSegmentValues.customerReaserch == "yes" ? "Customer research has been done" : "Customer research has not been done",
        value: customerSegmentValues.customerReaserch == "yes" ? "No recommendation" : "Business Research Officer",
        type: 1,
        question: 11,
        answered: customerSegmentValues.customerReaserch == "yes" || customerSegmentValues.customerReaserch == "no" ? true : false
      }
    ]
    //Market and sales
    const Market = [
      {
        key: values.effectiveAd === "yes" ? "The advertising is effective" : "The advertising is not effective",
        value: values.effectiveAd === "yes" ? "No recommendation" : "marketing plan",
        type: 2,
        question: 1,
        amswered: values.effectiveAd == "yes" || values.effectiveAd == "no" ? true : false
      }, {
        key: values.companyAd === "yes" ? "The company does advertise" : "The company does not advertise",
        value: values.companyAd === "yes" ? "No recommendation" : "marketing plan",
        type: 2,
        question: 2,
        answered: values.companyAd == "yes" || values.companyAd == "no" ? true : false
      },
      {
        key: values.planning === "yes" ? "Sales Planning is conducted" : "Sales Planning is not conducted",
        value: values.planning === "yes" ? "No recommendation" : "Sales planning, Customer acquistion plan.",
        type: 2,
        question: 3,
        answered: values.planning == "yes" || values.planning == "no" ? true : false
      }, {
        key: values.priceStrategy === "yes" ? "Price strategy planning is done" : "Price strategy planning is not done",
        value: values.priceStrategy === "yes" ? "No recommendation" : "Revenue models",
        type: 2,
        question: 4,
        answered: values.priceStrategy == "yes" || values.priceStrategy == "no" ? true : false
      }, {
        key: values.priceReview === "yes" ? "Prive reviews are done" : "Prive reviews are not done",
        value: values.priceReview === "yes" ? "No recommendation" : "Costing, product & service pricing",
        type: 2,
        question: 5,
        answered: values.priceReview == "yes" || values.priceReview == "no" ? true : false
      }
    ]
    //Ownership and mindset
    const owner = [
      {
        key: OwnerSegValues.ownerExperience == "yes" ? "Owners have the required experience." : "Owners don't have required experience.",
        value: OwnerSegValues.ownerExperience == "yes" ? "No Recommendation" : "Founder skills and expertise",
        type: 2,
        question: 1,
        answered: OwnerSegValues.ownerExperience == "yes" || OwnerSegValues.ownerExperience == "no" ? true : false
      },
      {
        key: OwnerSegValues.ownerTime == "yes" ? "Owners work fulltime in the business." : "Owners work part-time in the business.",
        value: OwnerSegValues.ownerTime == "yes" ? "No Recommendation" : "Owner & management commitment",
        type: 2,
        question: 2,
        answered: OwnerSegValues.ownerTime == "yes" || OwnerSegValues.ownerTime == "no" ? true : false
      },
      {
        key: OwnerSegValues.ownerQualification == "yes" ? "Expertise are enough to deliver on the product/service." : "Not enough expertise to deliver on products/service.",
        value: OwnerSegValues.ownerQualification == "yes" ? "No Recommendation" : "Founder skills and expertise",
        type: 2,
        question: 3,
        answered: OwnerSegValues.ownerQualification == "yes" || OwnerSegValues.ownerQualification == "no" ? true : false
      }
    ]

    //Market Intelligence
    const marketSegment = [
      {
        key: marketIntValues.marketResearch == "yes" ? "Customer research has been done." : "Customer research has not been done",
        value: marketIntValues.marketResearch == "yes" ? "No Recommendation" : "Job Opportunity : Business Research Officer.",
        type: 1,
        question: 1,
        answered: marketIntValues.marketResearch == "yes" || marketIntValues.marketResearch == "no" ? true : false
      },
      {
        key: marketIntValues.marketPlaninPlace == "yes" ? "There is a marketing plan in Place." : "There is no marketing plan in Place.",
        value: marketIntValues.marketPlaninPlace == "yes" ? "No Recommendation" : "Marketing Plan.",
        type: 1,
        question: 2,
        answered: marketIntValues.marketPlaninPlace == "yes" || marketIntValues.marketPlaninPlace == "no" ? true : false
      },
      {
        key: marketIntValues.targetNetwork == "yes" ? "There is a target network." : "There is no target network.",
        value: marketIntValues.targetNetwork == "yes" ? "No Recommendation" : "Networking.",
        type: 1,
        question: 3,
        answered: marketIntValues.targetNetwork == "yes" || marketIntValues.targetNetwork == "no" ? true : false
      },
      {
        key: marketIntValues.postSales == "yes" ? "Post sales support has been provided." : "Post sales support is not provided.",
        value: marketIntValues.postSales == "yes" ? "No Recommendation" : "Job Opportunity : Sales personel.",
        type: 1,
        question: 4,
        answered: marketIntValues.postSales == "yes" || marketIntValues.postSales == "no" ? true : false
      },
    ]
    //Delivery
    const delivery = [
      {
        key: deliverySegValues.pursuePotential == "yes" ? "There's a defined process to acquire clients." : "No defined processes",
        value: deliverySegValues.pursuePotential == "yes" ? "No Recommendation" : "Customer Acquisition Plan.",
        type: 2,
        question: 1,
        answered: deliverySegValues.pursuePotential == "yes" || deliverySegValues.pursuePotential == "no" ? true : false
      },
      {
        key: deliverySegValues.techInfrastructure == "yes" ? "There is a marketing plan in Place." : "There is no marketing plan in Place.",
        value: deliverySegValues.techInfrastructure == "yes" ? "No Recommendation" : "Equipment & Materials",
        type: 2,
        question: 2,
        answered: deliverySegValues.techInfrastructure == "yes" || deliverySegValues.techInfrastructure == "no" ? true : false
      },
      {
        key: deliverySegValues.deliveringExperience == "yes" ? "There is a target network." : "There is no target network.",
        value: deliverySegValues.deliveringExperience == "yes" ? "No Recommendation" : "CRM",
        type: 2,
        question: 3,
        answered: deliverySegValues.deliveringExperience == "yes" || deliverySegValues.deliveringExperience == "no" ? true : false
      },
      {
        key: deliverySegValues.productTraining == "yes" ? "Post sales support has been provided." : "Post sales support is not provided.",
        value: deliverySegValues.productTraining == "yes" ? "No Recommendation" : "Training and Content Development",
        type: 2,
        question: 4,
        answered: deliverySegValues.productTraining == "yes" || deliverySegValues.productTraining == "no" ? true : false
      },
      {
        key: deliverySegValues.rankEmployees == "yes" ? "There is a target network." : "Employee skills and Performance",
        value: deliverySegValues.rankEmployees == "yes" ? "No Recommendation" : "Networking.",
        type: 2,
        question: 5,
        answered: deliverySegValues.rankEmployees == "yes" || deliverySegValues.rankEmployees == "no" ? true : false
      },
      {
        key: deliverySegValues.dedicatedQualified == "yes" ? "Post sales support has been provided." : "Post sales support is not provided.",
        value: deliverySegValues.dedicatedQualified == "yes" ? "No Recommendation" : "No Recommendation",
        type: 2,
        question: 6,
        answered: deliverySegValues.dedicatedQualified == "yes" || deliverySegValues.dedicatedQualified == "no" ? true : false
      },
    ]

    // Value Proposition
    const valuePropositionSegment = [
      {
        key: propositionSegmentValues.problem === "yes" ? "Problem being solved has been determined." : "Problem being solved not determined",
        value: propositionSegmentValues.problem === "yes" ? "No recommendation" : "Value proposition canvas",
        type: 1,
        question: 1,
        ansered: propositionSegmentValues.problem == "yes" || propositionSegmentValues.problem == "no" ? true : false
      },
      {
        key: propositionSegmentValues.cusValue === "yes" ? "Value being delivered has been determined." : "Value being delivered not determined.",
        value: propositionSegmentValues.cusValue === "yes" ? "No recommendation" : "Business model canvas",
        type: 1,
        question: 2,
        answered: propositionSegmentValues.cusValue == "yes" || propositionSegmentValues.cusValue == "no" ? true : false
      },
      {
        key: propositionSegmentValues.needsSatisfied === "yes" ? "Customer needs have been determined." : "Customer needs have not been determined.",
        value: propositionSegmentValues.needsSatisfied === "yes" ? "No recommendation" : "Value proposition canvas",
        type: 1,
        question: 3,
        answered: propositionSegmentValues.needsSatisfied == "yes" || propositionSegmentValues.needsSatisfied == "no" ? true : false
      },
      {
        key: propositionSegmentValues.productUniqueness === "yes" ? "uniques selling point has been determined." : "Uniques selling point not determined.",
        value: propositionSegmentValues.productUniqueness === "yes" ? "No recommendation" : "Value proposition canvas",
        type: 1,
        question: 4,
        answered: propositionSegmentValues.productUniqueness == "yes" || propositionSegmentValues.productUniqueness == "no" ? true : false
      },
      {
        key: propositionSegmentValues.elevatorPitch === "yes" ? "An elevator pitch has been prepared." : "elevator pitch template",
        value: propositionSegmentValues.elevatorPitch === "yes" ? "No recommendation" : "No elevator pitch",
        type: 1,
        question: 5,
        answered: propositionSegmentValues.elevatorPitch == "yes" || propositionSegmentValues.elevatorPitch == "no" ? true : false
      }
    ]
    //Key Activities
    const keyActivities = [
      {
        key: keyActivitiesSegmentValues.bizModel === "yes" ? "Key activities in the business have been determined" : "Key activities in the business not determined",
        value: keyActivitiesSegmentValues.bizModel === "yes" ? "No recommendation" : "Process development",
        type: 1,
        question: 1,
        answered: keyActivitiesSegmentValues.bizModel == "yes" || keyActivitiesSegmentValues.bizModel == "no" ? true : false

      }
    ]
    //Current Activities
    const currentAlternatives = [

      {
        key: currentAlternativeSegmentValues.addressedHow === "yes" ? "The business is aware of current solutions from competitors." : "The business is not aware of current solutions",
        value: currentAlternativeSegmentValues.addressedHow === "yes" ? "No recommendation" : "Competitor analysis",
        type: 1,
        question: 1,
        answered: currentAlternativeSegmentValues.addressedHow == "yes" || currentAlternativeSegmentValues.addressedHow == "no" ? true : false
      },
      {
        key: currentAlternativeSegmentValues.currentCompetition === "yes" ? "The business is aware of its competitors" : "The business is not aware of its competitors",
        value: currentAlternativeSegmentValues.currentCompetition === "yes" ? "No recommendation" : "Competitor analysis",
        type: 1,
        question: 2,
        answered: currentAlternativeSegmentValues.currentCompetition == "yes" || currentAlternativeSegmentValues.currentCompetition == "no" ? true : false
      },
    ]
    // key partners
    const keyPartners = [

      {
        key: keyPartnersSegmentValues.strategicPartnership === "yes" ? "Strategic partners have been determined." : "Strategic partners have not been determined.",
        value: keyPartnersSegmentValues.strategicPartnership === "yes" ? "No recommendation" : "Boot Strapping Stratgey",
        type: 1,
        question: 1,
        answered: keyPartnersSegmentValues.strategicPartnership == "yes" || keyPartnersSegmentValues.strategicPartnership == "no" ? true : false
      },
      {
        key: keyPartnersSegmentValues.partnerAssist === "yes" ? "The value of strategic partnerships has been determined" : "Value of strategic partnerships not determined",
        value: keyPartnersSegmentValues.partnerAssist === "yes" ? "No recommendation" : "Boot Strapping Stratgey",
        type: 1,
        question: 2,
        answered: keyPartnersSegmentValues.partnerAssist == "yes" || keyPartnersSegmentValues.partnerAssist == "no" ? true : false
      },
      {
        key: keyPartnersSegmentValues.partnerDevelopment === "yes" ? "Has a person appointed for partner development" : "does not have a person appointed for partner development",
        value: keyPartnersSegmentValues.partnerDevelopment === "yes" ? "No recommendation" : "Job Opportunity : Business Developer",
        type: 1,
        question: 3,
        answered: keyPartnersSegmentValues.partnerDevelopment == "yes" || keyPartnersSegmentValues.partnerDevelopment == "no" ? true : false
      },
    ]

    //Key Resources
    const keyResources = [{
      key: keyResourcesSegmentValues.resources === "yes" ? "Key resources needed have been determined." : "Key resources needed have not been determined",
      value: keyResourcesSegmentValues.resources === "yes" ? "No recommendation" : "organizational design and development",
      type: 1,
      question: 1,
      answered: keyResourcesSegmentValues.resources == "yes" || keyResourcesSegmentValues.resources == "no" ? true : false
    }]





    const payload = {
      "segment": "Poor Sales",
      "userId": user?.id,
      "segmentResponses": {
        "eCommerce": eCommerce,
        "Customer": customerSegment,
        "BusinessCustomers": businessCustomers,
        "Market": Market,
        "OwnershipMindset": owner,
        "MarketInt": marketSegment,
        "DeliveryExpertise": delivery,
        "Value": valuePropositionSegment,
        "Activities": keyActivities,
        "CurrentAlternatives": currentAlternatives,
        "Partners": keyPartners,
        "Resources": keyResources
      },
      "segmentValues": {
        "ECommerceValues": ECommerceValues,
        "businessCustomerValues": businessCustomerValues,
        "customerSegmentValues": customerSegmentValues,
        "values": values,
        "OwnerSegValues": OwnerSegValues,
        "marketIntValues": marketIntValues,
        "deliverySegValues": deliverySegValues,
        "propositionSegmentValues": propositionSegmentValues,
        "keyActivitiesSegmentValues": keyActivitiesSegmentValues,
        "currentAlternativeSegmentValues": currentAlternativeSegmentValues,
        "keyPartnersSegmentValues": keyPartnersSegmentValues,
        "keyResourcesSegmentValues": keyResourcesSegmentValues
      }

    } as IPoor
    console.log("array of answers", payload)
    navigate('/HealthReport', { state: { bizInd: bizInd, bizPhase: bizPhase } });
    const isUpdate = recommendation.segmentResponses ? true : false;
    if (isUpdate) {
      await supabase
        .from('Recomendations')
        .update({
          segmentResponses: {
            "eCommerce": eCommerce,
            "Customer": customerSegment,
            "BusinessCustomers": businessCustomers,
            "Market": Market,
            "OwnershipMindset": owner,
            "MarketInt": marketSegment,
            "DeliveryExpertise": delivery,
            "Value": valuePropositionSegment,
            "Activities": keyActivities,
            "CurrentAlternatives": currentAlternatives,
            "Partners": keyPartners,
            "Resources": keyResources
          }
        })
        .eq('id', recommendation.id);

      await supabase
        .from('Recomendations')
        .update({
          segmentValues: {
            "ECommerceValues": ECommerceValues,
            "businessCustomerValues": businessCustomerValues,
            "customerSegmentValues": customerSegmentValues,
            "values": values,
            "OwnerSegValues": OwnerSegValues,
            "marketIntValues": marketIntValues,
            "deliverySegValues": deliverySegValues,
            "propositionSegmentValues": propositionSegmentValues,
            "keyActivitiesSegmentValues": keyActivitiesSegmentValues,
            "currentAlternativeSegmentValues": currentAlternativeSegmentValues,
            "keyPartnersSegmentValues": keyPartnersSegmentValues,
            "keyResourcesSegmentValues": keyResourcesSegmentValues
          }
        })
        .eq('id', recommendation.id)


    } else {
      const result = await Api.POST_CreatePoorRecommendation(payload)
      navigate('/HealthReport', { state: { bizInd: bizInd, bizPhase: bizPhase } });
      console.log('Result is', result)
    }
  }
  const handleChangeeCommerceSegment = (question: string, field: string, event: React.ChangeEvent<HTMLInputElement>, index: number) => {
    const indexOfObject = eCommerce.findIndex(object => {
      return object.question === question;
    });
    setECommeceValues({ ...ECommerceValues, [field]: (event.target as HTMLInputElement).value });

    eCommerce.splice(indexOfObject, 1);
  };

  const handleChangeCustomerSegment = (question: string, field: string, event: React.ChangeEvent<HTMLInputElement>, index: number) => {
    const indexOfObject = CustomerSegment.findIndex(object => {
      return object.question === question;
    });
    setCustomerSegmentValues({ ...customerSegmentValues, [field]: (event.target as HTMLInputElement).value });

    CustomerSegment.splice(indexOfObject, 1);
  };
  const handleChangeBusinessCusSegment = (question: string, field: string, event: React.ChangeEvent<HTMLInputElement>, index: number) => {
    const indexOfObject = BusinessCustomer.findIndex(object => {
      return object.question === question;
    });
    setBusinessCustomerValues({ ...businessCustomerValues, [field]: (event.target as HTMLInputElement).value });

    BusinessCustomer.splice(indexOfObject, 1);
  };

  const handleChangeMarketingAndSales = (question: string, field: string, event: React.ChangeEvent<HTMLInputElement>, index: number) => {
    // console.log(index, question, field)
    const indexOfObject = mkSales.findIndex(object => {
      return object.question === question;
    });
    setValues({ ...values, [field]: (event.target as HTMLInputElement).value });

    mkSales.splice(indexOfObject, 1);
  };
  const handleChangeOwnerSegment = (question: string, field: string, event: React.ChangeEvent<HTMLInputElement>, index: number) => {
    const indexOfObject = OwnerSeg.findIndex(object => {
      return object.question === question;
    });
    setOwnerSegValues({ ...OwnerSegValues, [field]: (event.target as HTMLInputElement).value });

    OwnerSeg.splice(indexOfObject, 1);
  };

  const handleChangeMarketSegment = (question: string, field: string, event: React.ChangeEvent<HTMLInputElement>, index: number) => {
    const indexOfObject = MarketInt.findIndex(object => {
      return object.question === question;
    });
    setmarketIntValues({ ...marketIntValues, [field]: (event.target as HTMLInputElement).value });

    MarketInt.splice(indexOfObject, 1);
  };
  const handleChangeDeliverySegment = (question: string, field: string, event: React.ChangeEvent<HTMLInputElement>, index: number) => {
    const indexOfObject = DeliverySeg.findIndex(object => {
      return object.question === question;
    });
    setDeliverySegValues({ ...deliverySegValues, [field]: (event.target as HTMLInputElement).value });

    DeliverySeg.splice(indexOfObject, 1);
  };

  const handleChangePropositionSegment = (question: string, field: string, event: React.ChangeEvent<HTMLInputElement>, index: number) => {
    const indexOfObject = PropositionSegment.findIndex(object => {
      return object.question === question;
    });
    setPropositionSegmentValues({ ...customerSegmentValues, [field]: (event.target as HTMLInputElement).value });

    PropositionSegment.splice(indexOfObject, 1);
  };
  const handleChangeKeyActivitiesSegment = (question: string, field: string, event: React.ChangeEvent<HTMLInputElement>, index: number) => {
    const indexOfObject = KeyActivitiesSegment.findIndex(object => {
      return object.question === question;
    });
    setKeyActivitiesSegmentValues({ ...keyActivitiesSegmentValues, [field]: (event.target as HTMLInputElement).value });

    KeyActivitiesSegment.splice(indexOfObject, 1);
  };
  const handleChangeKeyCurrentSegment = (question: string, field: string, event: React.ChangeEvent<HTMLInputElement>, index: number) => {
    const indexOfObject = CurrentAlternativeSegment.findIndex(object => {
      return object.question === question;
    });
    setcurrentAlternativeSegmentValues({ ...currentAlternativeSegmentValues, [field]: (event.target as HTMLInputElement).value });

    CurrentAlternativeSegment.splice(indexOfObject, 1);
  };
  const handleChangeKeyPartnerSegment = (question: string, field: string, event: React.ChangeEvent<HTMLInputElement>, index: number) => {
    const indexOfObject = KeyPartnersSegment.findIndex(object => {
      return object.question === question;
    });
    setKeyPartnersSegmentValues({ ...keyPartnersSegmentValues, [field]: (event.target as HTMLInputElement).value });

    KeyPartnersSegment.splice(indexOfObject, 1);
  };


  const handleChangeKeyResourcesSegment = (question: string, field: string, event: React.ChangeEvent<HTMLInputElement>, index: number) => {
    const indexOfObject = KeyResourcesSegment.findIndex(object => {
      return object.question === question;
    });
    setKeyResourcesSegmentValues({ ...keyResourcesSegmentValues, [field]: (event.target as HTMLInputElement).value });

    KeyResourcesSegment.splice(indexOfObject, 1);
  };
  const state = useSelector(selectRecomendationState);
  const recommendation: any = state.persistedReducer.RecomendationReducer.selectedRecomendation;
  console.log(recommendation)
  console.log(customerSegment);
  //e-Commerce
  let commerceQuestions: { question: string, field: string }[] = []


  if (recommendation.segmentResponses) {
    eCommerceSeg.forEach(question => {
      if (recommendation.segmentResponses?.eCommerce.some((res: any) => res.question == question.number && !res.answered)) {
        commerceQuestions.push(question);
      }
    });
  } else {
    commerceQuestions = [...eCommerceSeg]
  }
  //Customer
  let customerSegmentQuestions: { question: string, field: string }[] = []

  if (recommendation.segmentResponses) {
    customerSegment.forEach(question => {
      if (recommendation.segmentResponses?.Customer.some((res: any) => res.question == question.number && !res.answered)) {
        customerSegmentQuestions.push(question);
      }
    });
  } else {
    customerSegmentQuestions = [...customerSegment]
  }

  //Business And Customers
  let businessCustomerQuestions: { question: string, field: string }[] = [...businessCustomersSeg]

  if (recommendation.segmentResponses) {
    businessCustomersSeg.forEach(question => {
      if (recommendation.segmentResponses?.BusinessCustomers.some((res: any) => res.question == question.number && !res.answered)) {
        businessCustomerQuestions.push(question);
      }
    });
  } else {
    businessCustomerQuestions = [...businessCustomersSeg]
  }


  //MArket
  let marketSalesQuestions: { question: string, field: string }[] = []

  if (recommendation.segmentResponses) {
    marketingSales.forEach(question => {
      if (recommendation.segmentResponses?.Market.some((res: any) => res.question == question.number && !res.answered)) {
        marketSalesQuestions.push(question);
      }
    });
  } else {
    marketSalesQuestions = [...marketingSales]
  }

  //Ownership Mindset
  let ownerQuestions: { question: string, field: string }[] = []

  if (recommendation.segmentResponses) {
    owner.forEach(question => {
      if (recommendation.segmentResponses?.OwnershipMindset.some((res: any) => res.question == question.number && !res.answered)) {
        ownerQuestions.push(question);
      }
    });
  } else {
    ownerQuestions = [...owner]
  }
  // Market Intelligence
  let marketIntelligenceQuestions: { question: string, field: string }[] = []

  if (recommendation.segmentResponses) {
    marketIntSeg.forEach(question => {
      if (recommendation.segmentResponses?.MarketInt.some((res: any) => res.question == question.number && !res.answered)) {
        marketIntelligenceQuestions.push(question);
      }
    });
  } else {
    marketIntelligenceQuestions = [...marketIntSeg]
  }
  //Delivery
  let deliveryQuestions: { question: string, field: string }[] = [...delivery]

  recommendation.segmentResponses?.DeliveryExpertise.forEach((element: any) => {
    deliveryQuestions = deliveryQuestions.filter((q: any, index: number) => q.number !== element.question)
  });
  //Value Proposition
  let propositionQuestions: { question: string, field: string }[] = []

  if (recommendation.segmentResponses) {
    valuePropositionSegment.forEach(question => {
      if (recommendation.segmentResponses?.Value.some((res: any) => res.question == question.number && !res.answered)) {
        propositionQuestions.push(question);
      }
    });
  } else {
    propositionQuestions = [...valuePropositionSegment]
  }
  // Key Activities
  let activitiesQuestions: { question: string, field: string }[] = []

  if (recommendation.segmentResponses) {
    keyActivitiesSegment.forEach(question => {
      if (recommendation.segmentResponses?.Value.some((res: any) => res.question == question.number && !res.answered)) {
        activitiesQuestions.push(question);
      }
    });
  } else {
    activitiesQuestions = [...keyActivitiesSegment]
  }
  //Current Alternatives
  let currentAltQuestions: { question: string, field: string }[] = []

  if (recommendation.segmentResponses) {
    current.forEach(question => {
      if (recommendation.segmentResponses?.CurrentAlternatives.some((res: any) => res.question == question.number && !res.answered)) {
        currentAltQuestions.push(question);
      }
    });
  } else {
    currentAltQuestions = [...current]
  }

  //Key Partners
  let keyPartnersQuestions: { question: string, field: string }[] = []

  if (recommendation.segmentResponses) {
    partners.forEach(question => {
      if (recommendation.segmentResponses?.Partners.some((res: any) => res.question == question.number && !res.answered)) {
        keyPartnersQuestions.push(question);
      }
    });
  } else {
    keyPartnersQuestions = [...partners]
  }
  // Key Resources
  let resourcesQuestions: { question: string, field: string }[] = []

  if (recommendation.segmentResponses) {
    keyResourcesSegment.forEach(question => {
      if (recommendation.segmentResponses?.Value.some((res: any) => res.question == question.number && !res.answered)) {
        resourcesQuestions.push(question);
      }
    });
  } else {
    resourcesQuestions = [...keyResourcesSegment]
  }

  useEffect(() => {
    if (recommendation?.segmentValues && recommendation.segmentValues.ECommeceValues) {
      setECommeceValues(recommendation.segmentValues.ECommeceValues);
    }
    if (recommendation?.segmentValues && recommendation.segmentValues.customerSegmentValues) {
      setCustomerSegmentValues(recommendation.segmentValues.customerSegmentValues);
    }
    if (recommendation?.segmentValues && recommendation.segmentValues.businessCustomerValues) {
      setBusinessCustomerValues(recommendation.segmentValues.businessCustomerValues);
    }
    if (recommendation?.segmentValues && recommendation.segmentValues.marketSaleValues) {
      setValues(recommendation.segmentValues.marketSaleValues);
    }
    if (recommendation?.segmentValues && recommendation.segmentValues.OwnerSegValues) {
      setOwnerSegValues(recommendation.segmentValues.OwnerSegValues);
    }
    if (recommendation?.segmentValues && recommendation.segmentValues.marketIntValues) {
      setmarketIntValues(recommendation.segmentValues.marketIntValues);
    }
    if (recommendation?.segmentValues && recommendation.segmentValues.deliverySegValues) {
      setDeliverySegValues(recommendation.segmentValues.deliverySegValues);
    }
    if (recommendation?.segmentValues && recommendation.segmentValues.propositionSegmentValues) {
      setPropositionSegmentValues(recommendation.segmentValues.propositionSegmentValues);
    }
    if (recommendation?.segmentValues && recommendation.segmentValues.keyActivitiesSegmentValues) {
      setKeyActivitiesSegmentValues(recommendation.segmentValues.keyActivitiesSegmentValues);
    }
    if (recommendation?.segmentValues && recommendation.segmentValues.currentAlternativeSegmentValues) {
      setcurrentAlternativeSegmentValues(recommendation.segmentValues.currentAlternativeSegmentValues);
    }
    if (recommendation?.segmentValues && recommendation.segmentValues.keyPartnersSegmentValues) {
      setKeyPartnersSegmentValues(recommendation.segmentValues.keyPartnersSegmentValues);
    }
    if (recommendation?.segmentValues && recommendation.segmentValues.keyResourcesSegmentValues) {
      setKeyResourcesSegmentValues(recommendation.segmentValues.keyResourcesSegmentValues);
    }
  }, [])
  return (
    <div className='Basic'>
      <UserNavbar />
      <Container>
        <Grid container spacing={2}>
          <Grid item xs={12} sm={12} md={4} lg={4}>
            <Typography>Company</Typography>
            <Button
              className='profAdd'
              variant='outlined'
            >
              Add Company
            </Button>
            <div className='Accords'>
              <div className='sideAccord'>
                <AccessmentAccordion setSelectedRecommedation ={false}/>
              </div>
            </div>
          </Grid>
          <Grid item xs={12} sm={12} md={8} lg={8}>
            <Alert style={{ backgroundColor: "#00d3dd" }} severity="info">Next Step! Complete your Company Assessment.</Alert>
            <Typography className='biz' variant='h5'>Biz Assessment</Typography>
            <div className='companyBox'>
              <img
                src={company}
                alt='comLogo'
                className='company'
              />
              <div className='companyInf'>
                <div className='Location'>
                  <Typography>Location: N/A</Typography>
                </div>
                <div className='indust'>
                  <Typography>Industry: {bizInd[0].label}</Typography>
                </div>
                <div className='phase'>
                  <Typography>Business Phase: {bizPhase[0].label}</Typography>
                </div>
              </div>
            </div>
            <div className='bassicAccords'>
              <Accordion>
                <AccordionSummary
                  expandIcon={<ExpandMoreIcon />}
                  aria-controls="panel2a-content"
                  id="panel2a-header"
                >
                  <Typography className=''>e-Commerce</Typography>
                </AccordionSummary>
                <AccordionDetails>
                  <div className='rev'>
                    {
                      commerceQuestions.map((val, index) => {
                        return (
                          <div key={index}>
                            <FormControl>
                              <FormLabel id="demo-controlled-radio-buttons-group">
                                {val.question}
                              </FormLabel>
                              <RadioGroup
                                aria-labelledby="demo-controlled-radio-buttons-group"
                                //name="controlled-radio-buttons-group"
                                value={values[index]}
                                onChange={(e) => handleChangeeCommerceSegment(val.question, val.field, e, index)}
                              >
                                <FormControlLabel value="yes" checked={false} control={<Radio />} label="Yes" />
                                <FormControlLabel value="no" checked={false} control={<Radio />} label="No" />

                              </RadioGroup>
                            </FormControl>
                          </div>
                        )

                      })
                    }
                  </div>
                </AccordionDetails>
              </Accordion>
              <Accordion>
                <AccordionSummary
                  expandIcon={<ExpandMoreIcon />}
                  aria-controls="panel2a-content"
                  id="panel2a-header"
                >
                  <Typography className=''>Customer segment</Typography>
                </AccordionSummary>
                <AccordionDetails>
                  <div className='rev'>
                    {
                      customerSegmentQuestions.map((val, index) => {
                        return (
                          <div key={index}>
                            <FormControl>
                              <FormLabel id="demo-controlled-radio-buttons-group">
                                {val.question}
                              </FormLabel>
                              <RadioGroup
                                aria-labelledby="demo-controlled-radio-buttons-group"
                                //name="controlled-radio-buttons-group"
                                value={values[index]}
                                onChange={(e) => handleChangeCustomerSegment(val.question, val.field, e, index)}
                              >
                                <FormControlLabel value="yes" checked={false} control={<Radio />} label="Yes" />
                                <FormControlLabel value="no" checked={false} control={<Radio />} label="No" />

                              </RadioGroup>
                            </FormControl>
                          </div>
                        )

                      })
                    }
                  </div>
                </AccordionDetails>
              </Accordion>
              <Accordion>
                <AccordionSummary
                  expandIcon={<ExpandMoreIcon />}
                  aria-controls="panel2a-content"
                  id="panel2a-header"
                >
                  <Typography className=''>Business and Customers</Typography>
                </AccordionSummary>
                <AccordionDetails>
                  <div className='rev'>
                    {
                      businessCustomerQuestions.map((val, index) => {
                        return (
                          <div key={index}>
                            <FormControl>
                              <FormLabel id="demo-controlled-radio-buttons-group">
                                {val.question}
                              </FormLabel>
                              <RadioGroup
                                aria-labelledby="demo-controlled-radio-buttons-group"
                                //name="controlled-radio-buttons-group"
                                value={values[index]}
                                onChange={(e) => handleChangeBusinessCusSegment(val.question, val.field, e, index)}
                              >
                                <FormControlLabel value="yes" checked={false} control={<Radio />} label="Yes" />
                                <FormControlLabel value="no" checked={false} control={<Radio />} label="No" />

                              </RadioGroup>
                            </FormControl>
                          </div>
                        )

                      })
                    }
                  </div>
                </AccordionDetails>
              </Accordion>
              <Accordion>
                <AccordionSummary
                  expandIcon={<ExpandMoreIcon />}
                  aria-controls="panel2a-content"
                  id="panel2a-header"
                >
                  <Typography className=''>Marketing and Sales</Typography>
                </AccordionSummary>
                <AccordionDetails>
                  <div className='rev'>
                    {
                      marketSalesQuestions.map((val, index) => {
                        return (
                          <div key={index}>
                            <FormControl>
                              <FormLabel id="demo-controlled-radio-buttons-group">
                                {val.question}
                              </FormLabel>
                              <RadioGroup
                                aria-labelledby="demo-controlled-radio-buttons-group"
                                //name="controlled-radio-buttons-group"
                                value={values[index]}
                                onChange={(e) => handleChangeMarketingAndSales(val.question, val.field, e, index)}
                              >
                                <FormControlLabel value="yes" checked={false} control={<Radio />} label="Yes" />
                                <FormControlLabel value="no" checked={false} control={<Radio />} label="No" />

                              </RadioGroup>
                            </FormControl>
                          </div>
                        )

                      })
                    }
                  </div>
                </AccordionDetails>
              </Accordion>
              <Accordion>
                <AccordionSummary
                  expandIcon={<ExpandMoreIcon />}
                  aria-controls="panel2a-content"
                  id="panel2a-header"
                >
                  <Typography className=''>Ownership and Mindset</Typography>
                </AccordionSummary>
                <AccordionDetails>
                  <div className='rev'>
                    {
                      ownerQuestions.map((val, index) => {
                        return (
                          <div key={index}>
                            <FormControl>
                              <FormLabel id="demo-controlled-radio-buttons-group">
                                {val.question}
                              </FormLabel>
                              <RadioGroup
                                aria-labelledby="demo-controlled-radio-buttons-group"
                                //name="controlled-radio-buttons-group"
                                value={values[index]}
                                onChange={(e) => handleChangeOwnerSegment(val.question, val.field, e, index)}
                              >
                                <FormControlLabel value="yes" checked={false} control={<Radio />} label="Yes" />
                                <FormControlLabel value="no" checked={false} control={<Radio />} label="No" />

                              </RadioGroup>
                            </FormControl>
                          </div>
                        )

                      })
                    }
                  </div>
                </AccordionDetails>
              </Accordion>
              <Accordion>
                <AccordionSummary
                  expandIcon={<ExpandMoreIcon />}
                  aria-controls="panel2a-content"
                  id="panel2a-header"
                >
                  <Typography className="">Market Intelligence</Typography>
                </AccordionSummary>
                <AccordionDetails>
                  <div className='rev'>
                    {
                      marketIntelligenceQuestions.map((val, index) => {
                        return (
                          <div key={index}>
                            <FormControl>
                              <FormLabel id="demo-controlled-radio-buttons-group">
                                {val.question}
                              </FormLabel>
                              <RadioGroup
                                aria-labelledby="demo-controlled-radio-buttons-group"
                                //name="controlled-radio-buttons-group"
                                value={values[index]}
                                onChange={(e) => handleChangeMarketSegment(val.question, val.field, e, index)}
                              >
                                <FormControlLabel value="yes" checked={false} control={<Radio />} label="Yes" />
                                <FormControlLabel value="no" checked={false} control={<Radio />} label="No" />

                              </RadioGroup>
                            </FormControl>
                          </div>
                        )

                      })
                    }
                  </div>

                </AccordionDetails>
              </Accordion>
              <Accordion>
                <AccordionSummary
                  expandIcon={<ExpandMoreIcon />}
                  aria-controls="panel2a-content"
                  id="panel2a-header"
                >
                  <Typography className="">Delivery expertise</Typography>
                </AccordionSummary>
                <AccordionDetails>
                  <div className='rev'>
                    {
                      deliveryQuestions.map((val, index) => {
                        return (
                          <div key={index}>
                            <FormControl>
                              <FormLabel id="demo-controlled-radio-buttons-group">
                                {val.question}
                              </FormLabel>
                              <RadioGroup
                                aria-labelledby="demo-controlled-radio-buttons-group"
                                //name="controlled-radio-buttons-group"
                                value={values[index]}
                                onChange={(e) => handleChangeDeliverySegment(val.question, val.field, e, index)}
                              >
                                <FormControlLabel value="yes" checked={false} control={<Radio />} label="Yes" />
                                <FormControlLabel value="no" checked={false} control={<Radio />} label="No" />

                              </RadioGroup>
                            </FormControl>
                          </div>
                        )

                      })
                    }
                  </div>

                </AccordionDetails>
              </Accordion>
              <Accordion>
                <AccordionSummary
                  expandIcon={<ExpandMoreIcon />}
                  aria-controls="panel2a-content"
                  id="panel2a-header"
                >
                  <Typography className=''>Value Proposition</Typography>
                </AccordionSummary>
                <AccordionDetails>
                  <div className='rev'>
                    {
                      propositionQuestions.map((val, index) => {
                        return (
                          <div key={index}>
                            <FormControl>
                              <FormLabel id="demo-controlled-radio-buttons-group">
                                {val.question}
                              </FormLabel>
                              <RadioGroup
                                aria-labelledby="demo-controlled-radio-buttons-group"
                                //name="controlled-radio-buttons-group"
                                value={values[index]}
                                onChange={(e) => handleChangePropositionSegment(val.question, val.field, e, index)}
                              >
                                <FormControlLabel value="yes" checked={false} control={<Radio />} label="Yes" />
                                <FormControlLabel value="no" checked={false} control={<Radio />} label="No" />

                              </RadioGroup>
                            </FormControl>
                          </div>
                        )

                      })
                    }
                  </div>
                </AccordionDetails>
              </Accordion>
              <Accordion>
                <AccordionSummary
                  expandIcon={<ExpandMoreIcon />}
                  aria-controls="panel2a-content"
                  id="panel2a-header"
                >
                  <Typography className=''>Key Activities</Typography>
                </AccordionSummary>
                <AccordionDetails>
                  <div className='rev'>
                    {
                      activitiesQuestions.map((val, index) => {
                        return (
                          <div key={index}>
                            <FormControl>
                              <FormLabel id="demo-controlled-radio-buttons-group">
                                {val.question}
                              </FormLabel>
                              <RadioGroup
                                aria-labelledby="demo-controlled-radio-buttons-group"
                                //name="controlled-radio-buttons-group"
                                value={values[index]}
                                onChange={(e) => handleChangeKeyActivitiesSegment(val.question, val.field, e, index)}
                              >
                                <FormControlLabel value="yes" checked={false} control={<Radio />} label="Yes" />
                                <FormControlLabel value="no" checked={false} control={<Radio />} label="No" />

                              </RadioGroup>
                            </FormControl>
                          </div>
                        )

                      })
                    }
                  </div>
                </AccordionDetails>
              </Accordion>
              <Accordion>
                <AccordionSummary
                  expandIcon={<ExpandMoreIcon />}
                  aria-controls="panel2a-content"
                  id="panel2a-header"
                >
                  <Typography className=''>Current Alternatives</Typography>
                </AccordionSummary>
                <AccordionDetails>
                  <div className='rev'>
                    {
                      currentAltQuestions.map((val, index) => {
                        return (
                          <div key={index}>
                            <FormControl>
                              <FormLabel id="demo-controlled-radio-buttons-group">
                                {val.question}
                              </FormLabel>
                              <RadioGroup
                                aria-labelledby="demo-controlled-radio-buttons-group"
                                //name="controlled-radio-buttons-group"
                                value={values[index]}
                                onChange={(e) => handleChangeKeyCurrentSegment(val.question, val.field, e, index)}
                              >
                                <FormControlLabel value="yes" checked={false} control={<Radio />} label="Yes" />
                                <FormControlLabel value="no" checked={false} control={<Radio />} label="No" />

                              </RadioGroup>
                            </FormControl>
                          </div>
                        )

                      })
                    }
                  </div>
                </AccordionDetails>
              </Accordion>
              <Accordion>
                <AccordionSummary
                  expandIcon={<ExpandMoreIcon />}
                  aria-controls="panel2a-content"
                  id="panel2a-header"
                >
                  <Typography className=''>Key Partners</Typography>
                </AccordionSummary>
                <AccordionDetails>
                  <div className='rev'>
                    {
                      keyPartnersQuestions.map((val, index) => {
                        return (
                          <div key={index}>
                            <FormControl>
                              <FormLabel id="demo-controlled-radio-buttons-group">
                                {val.question}
                              </FormLabel>
                              <RadioGroup
                                aria-labelledby="demo-controlled-radio-buttons-group"
                                //name="controlled-radio-buttons-group"
                                value={values[index]}
                                onChange={(e) => handleChangeKeyPartnerSegment(val.question, val.field, e, index)}
                              >
                                <FormControlLabel value="yes" checked={false} control={<Radio />} label="Yes" />
                                <FormControlLabel value="no" checked={false} control={<Radio />} label="No" />

                              </RadioGroup>
                            </FormControl>
                          </div>
                        )

                      })
                    }
                  </div>
                </AccordionDetails>
              </Accordion>
              <Accordion>
                <AccordionSummary
                  expandIcon={<ExpandMoreIcon />}
                  aria-controls="panel2a-content"
                  id="panel2a-header"
                >
                  <Typography className=''>Key Resources</Typography>
                </AccordionSummary>
                <AccordionDetails>
                  <div className='rev'>
                    {
                      resourcesQuestions.map((val, index) => {
                        return (
                          <div key={index}>
                            <FormControl>
                              <FormLabel id="demo-controlled-radio-buttons-group">
                                {val.question}
                              </FormLabel>
                              <RadioGroup
                                aria-labelledby="demo-controlled-radio-buttons-group"
                                //name="controlled-radio-buttons-group"
                                value={values[index]}
                                onChange={(e) => handleChangeKeyResourcesSegment(val.question, val.field, e, index)}
                              >
                                <FormControlLabel value="yes" checked={false} control={<Radio />} label="Yes" />
                                <FormControlLabel value="no" checked={false} control={<Radio />} label="No" />

                              </RadioGroup>
                            </FormControl>
                          </div>
                        )

                      })
                    }
                  </div>
                </AccordionDetails>
              </Accordion>
            </div>

            <div className='AssesButtonsA'>
              <Button
                variant='outlined'
                className='AssesBack'
              >
                Back
              </Button>
              <Button
                variant='outlined'
                className='AssesSave'
                onClick={() => createReport()}

              >
                Save

              </Button>
            </div>
          </Grid>
        </Grid>
      </Container>
      <div className='footD'>
        <Footernew />
      </div>
    </div>
  )
}

export default PoorSales;
// export const { save } = actions;
// export default reducer;

//try Export at the top