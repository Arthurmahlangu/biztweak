import React, { useEffect, useState } from 'react';
import { Container, Grid, Button } from '@material-ui/core';
import Accordion from '@material-ui/core/Accordion';
import AccordionSummary from '@material-ui/core/AccordionSummary';
import AccordionDetails from '@material-ui/core/AccordionDetails';
import Typography from '@material-ui/core/Typography';
import ExpandMoreIcon from '@material-ui/icons/ExpandMore';
import MuiAlert from '@material-ui/lab/Alert';
import UserNavbar from '../../UserNav/UserNav';
import company from '../../../Images/company.png'
import Radio from "@mui/material/Radio";
import RadioGroup from "@mui/material/RadioGroup";
import FormControlLabel from "@mui/material/FormControlLabel";
import FormControl from "@mui/material/FormControl";
import FormLabel from "@mui/material/FormLabel";
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { createSlice } from '@reduxjs/toolkit';
import { Api } from '../../../services/endpoints';
import { IConcept, IRecomendation } from '../../../Interfaces/IRecomendation'
import Footernew from '../../Footer/Footernew';
import { supabase } from '../../../supabaseClient';
import prototype from '../../../json/Prototype.json';
import functionalCapability from "../../../json/functionalCapability.json";
import customerSegment from '../../../json/customerSegment.json';
import revenue from '../../../json/revenueStreams.json';
import valuePropositionSegment from '../../../json/valueProposition.json';
import costStructureSeg from '../../../json/costStructure.json';
import proof from '../../../json/proofOfConcept.json'
import keyResourcesSegment from '../../../json/keyResources.json';
import { useSelector } from 'react-redux';
import { selectRecomendationState } from "../../../Slice/createSlice";
import '../Assessment.css'
import AccessmentAccordion from '../../AssessmentsAccordion/AccessmentsAccordion';
import { isMobile } from "../../../lib/screenQuery";

type LocationState = {
  bizInd: Array<{
    value: number;
    label: string
  }>,
  bizPhase: Array<{
    value: number;
    label: string
  }>
}




const Concept = () => {
  const location = useLocation();
  const bizInd = (location.state as LocationState)?.bizInd;
  const bizPhase = (location.state as LocationState)?.bizPhase;
  const navigate = useNavigate();
  // const [value, setValue] = React.useState('');

  const [PrototypeSegment, setPrototypeSegment] = useState<{ question: string, field: string }[]>(prototype);
  const [FunctionalSegment, setFunctionalSegment] = useState<{ question: string, field: string }[]>(functionalCapability);
  const [CustomerSegment, setCustomerSegment] = useState<{ question: string, field: string }[]>(customerSegment);
  const [RevenueStream, setRevenueStream] = useState<{ question: string, field: string }[]>(revenue);
  const [PropositionSegment, setPropositionSegment] = useState<{ question: string, field: string }[]>(valuePropositionSegment);
  const [CostStructure, setCostStructure] = useState<{ question: string, field: string }[]>(costStructureSeg);
  const [ProofConcept, setProofConcept] = useState<{ question: string, field: string }[]>(proof);
  const [KeyResourcesSegment, setKeyResourcesSegment] = useState<{ question: string, field: string }[]>(keyResourcesSegment);


  const [values, setValues] = useState<any>([]);
  const [prototypeSegmentValues, setPrototypeSegmentValues] = useState<any>([]);
  const [functionalSegmentValues, setFunctionalSegmentValues] = useState<any>([]);
  const [customerSegmentValues, setCustomerSegmentValues] = useState<any>([]);
  const [revenueStreamValues, setRevenueStreamValues] = useState<any>([]);
  const [propositionSegmentValues, setPropositionSegmentValues] = useState<any>([]);
  const [costStructureValues, setCostStructureValues] = useState<any>([]);
  const [proofConceptValues, setProofConceptValues] = useState<any>([]);
  const [keyResourcesSegmentValues, setKeyResourcesSegmentValues] = useState<any>([]);


  const _isMobile = isMobile();


  const user = supabase.auth.user()
  function Alert(props: any) {
    return <MuiAlert elevation={6} variant="filled" {...props} />;
  }
  const createReport = async () => {
    //Prototype
    const prototypeSegment = [
      {
        key: prototypeSegmentValues.prototypeSuggest == "yes" ? "Prototype already exists." : "Does not have prototype",
        value: prototypeSegmentValues.prototypeSuggest == "yes" ? "No recommendation" : "Prototype",
        type: 1,
        question: 1,
        answered: prototypeSegmentValues.prototypeSuggest == "yes" || prototypeSegmentValues.prototypeSuggest == "no" ? true : false
      },
      {
        key: prototypeSegmentValues.skillsRequired == "yes" ? "Does have required skills to build prototype." : "Does not have required skills to build prototype",
        value: prototypeSegmentValues.skillsRequired == "yes" ? "No recommendation" : "Prototype",
        type: 1,
        question: 2,
        answered: prototypeSegmentValues.skillsRequired == "yes" || prototypeSegmentValues.skillsRequired == "no" ? true : false
      }
    ]
    //Functional Capability
    const functionalSegment = [
      {
        key: functionalSegmentValues.sufficientAdministration == "yes" ? "There is an administration system that's in use in the company." : "No administration systems in place.",
        value: functionalSegmentValues.sufficientAdministration == "yes" ? "No recommendation" : "Process development & documentation",
        type: 2,
        question: 1,
        answered: functionalSegmentValues.sufficientAdministration == "yes" || functionalSegmentValues.sufficientAdministration == "no" ? true : false
      },
      {
        key: functionalSegmentValues.companyOrg == "yes" ? "Organizational structure is sufficient to deliver on product/service" : "Organizational structure not sufficient.",
        value: functionalSegmentValues.companyOrg == "yes" ? "No recommendation" : "Process development & documentation",
        type: 2,
        question: 2,
        answered: functionalSegmentValues.companyOrg == "yes" || functionalSegmentValues.companyOrg == "no" ? true : false
      }
    ]
    // Customer Segment
    const customerSegment = [
      {
        key: customerSegmentValues.productOwner == "yes" ? "Customer profile has been determined." : "Customer profile not determined",
        value: customerSegmentValues.productOwner == "yes" ? "No recommendation" : "Market Research",
        type: 1,
        question: 1,
        answered: customerSegmentValues.productOwner == "yes" || customerSegmentValues.productOwner == "no" ? true : false
      },
      {
        key: customerSegmentValues.tagetAudiance == "yes" ? "Target audience has been determined." : "Target audience has not been selected",
        value: customerSegmentValues.tagetAudiance == "yes" ? "No recommendation" : "Market Intelligence",
        type: 1,
        question: 2,
        answered: customerSegmentValues.tagetAudiance == "yes" || customerSegmentValues.tagetAudiance == "no" ? true : false
      },
      {
        key: customerSegmentValues.tagetAudianceLocation == "yes" ? "Target audience has been located geographically." : "Target audience has not been located geographically",
        value: customerSegmentValues.tagetAudianceLocation == "yes" ? "No recommendation" : "Market Research",
        type: 1,
        question: 3,
        answered: customerSegmentValues.tagetAudianceLocation == "yes" || customerSegmentValues.tagetAudianceLocation == "no" ? true : false
      },
      {
        key: customerSegmentValues.tagetMarketSize == "yes" ? "Target audience has been segmented." : "Target audience has not been segmented.",
        value: customerSegmentValues.tagetMarketSize == "yes" ? "No recommendation" : "SAM SOM TAM",
        type: 1,
        question: 4,
        answered: customerSegmentValues.tagetMarketSize == "yes" || customerSegmentValues.tagetMarketSize == "no" ? true : false
      },
      {
        key: customerSegmentValues.cusReach == "yes" ? "Total accessible market has been determined." : "Total accessible market has not been determined",
        value: customerSegmentValues.cusReach == "yes" ? "No recommendation" : "Market Strategy",
        type: 1,
        question: 5,
        answered: customerSegmentValues.cusReach == "yes" || customerSegmentValues.cusReach == "no" ? true : false
      },
      {
        key: customerSegmentValues.competitor == "yes" ? "Competitors have been identified" : "competitors have not been identified",
        value: customerSegmentValues.competitor == "yes" ? "No recommendation" : "Competitor Analysis",
        type: 1,
        question: 6,
        answered: customerSegmentValues.competitor == "yes" || customerSegmentValues.competitor == "no" ? true : false
      },
      {
        key: customerSegmentValues.marketAccess == "yes" ? "Total accessible market has been determined." : "Total accessible market has not been determined",
        value: customerSegmentValues.marketAccess == "yes" ? "No recommendation" : "Total Addressable market",
        type: 1,
        question: 7,
        answered: customerSegmentValues.marketAccess == "yes" || customerSegmentValues.marketAccess == "no" ? true : false
      },
      {
        key: customerSegmentValues.marketLocation == "yes" ? "Total observable market has been determined." : "Total observable market has not been determined.",
        value: customerSegmentValues.marketLocation == "yes" ? "No recommendation" : "Market Reasearch",
        type: 1,
        question: 8,
        answered: customerSegmentValues.marketLocation == "yes" || customerSegmentValues.marketLocation == "no" ? true : false
      },
      {
        key: customerSegmentValues.idealCustomer == "yes" ? "Ideal customer profile has been determined." : "Ideal customer profile has not been determined.",
        value: customerSegmentValues.idealCustomer == "yes" ? "No recommendation" : "Ideal Customer profile",
        type: 1,
        question: 9,
        answered: customerSegmentValues.idealCustomer == "yes" || customerSegmentValues.idealCustomer == "no" ? true : false
      },
      {
        key: customerSegmentValues.importantCustomer == "yes" ? "Most important not determined." : "Most important customers not determined",
        value: customerSegmentValues.importantCustomer == "yes" ? "No recommendation" : "Market Research",
        type: 1,
        question: 10,
        answered: customerSegmentValues.importantCustomer == "yes" || customerSegmentValues.importantCustomer == "no" ? true : false
      },
      {
        key: customerSegmentValues.customerReaserch == "yes" ? "Customer research has been done" : "Customer research has not been done",
        value: customerSegmentValues.customerReaserch == "yes" ? "No recommendation" : "Business Research Officer",
        type: 1,
        question: 11,
        answered: customerSegmentValues.customerReaserch == "yes" || customerSegmentValues.customerReaserch == "no" ? true : false
      }
    ]
    //Revenue Streams
    const revenue = [
      {
        key: revenueStreamValues.generatingRevenue == "yes" ? "Has Knowledge of how revenue is generated." : "Does not have Knowledge of how revenue is generated.",
        value: revenueStreamValues.generatingRevenue == "yes" ? "No Recommendation" : "Revenue models",
        type: 1,
        question: 1,
        answered: revenueStreamValues.generatingRevenue == "yes" || revenueStreamValues.generatingRevenue == "no" ? true : false
      },
      {
        key: revenueStreamValues.willingPay == "yes" ? "Value customers are willing to pay for has been determined." : "Value customers are willing to pay fpr not determined.",
        value: revenueStreamValues.willingPay == "yes" ? "No Recommendation" : "Proof of concept",
        type: 1,
        question: 2,
        answered: revenueStreamValues.willingPay == "yes" || revenueStreamValues.willingPay == "no" ? true : false
      },
      {
        key: revenueStreamValues.cusPaymentMethod == "yes" ? "Current payment trends of customers are known." : "Current payment trends of customers are not known.",
        value: revenueStreamValues.cusPaymentMethod == "yes" ? "No Recommendation" : "Competitor analysis",
        type: 1,
        question: 3,
        answered: revenueStreamValues.cusPaymentMethod == "yes" || revenueStreamValues.cusPaymentMethod == "no" ? true : false
      },
      {
        key: revenueStreamValues.preferedPayment == "yes" ? "Preferred paymet method of customers has been determined." : "Preferred paymet method of customers not determined.",
        value: revenueStreamValues.preferedPayment == "yes" ? "No Recommendation" : "Market research, competitor analysis",
        type: 1,
        question: 4,
        answered: revenueStreamValues.preferedPayment == "yes" || revenueStreamValues.preferedPayment == "no" ? true : false
      }
    ]
    // Key Proposition
    const valuePropositionSegment = [
      {
        key: propositionSegmentValues.problem === "yes" ? "Problem being solved has been determined." : "Problem being solved not determined",
        value: propositionSegmentValues.problem === "yes" ? "No recommendation" : "Value proposition canvas",
        type: 1,
        question: 1,
        ansered: propositionSegmentValues.problem == "yes" || propositionSegmentValues.problem == "no" ? true : false
      },
      {
        key: propositionSegmentValues.cusValue === "yes" ? "Value being delivered has been determined." : "Value being delivered not determined.",
        value: propositionSegmentValues.cusValue === "yes" ? "No recommendation" : "Business model canvas",
        type: 1,
        question: 2,
        answered: propositionSegmentValues.cusValue == "yes" || propositionSegmentValues.cusValue == "no" ? true : false
      },
      {
        key: propositionSegmentValues.needsSatisfied === "yes" ? "Customer needs have been determined." : "Customer needs have not been determined.",
        value: propositionSegmentValues.needsSatisfied === "yes" ? "No recommendation" : "Value proposition canvas",
        type: 1,
        question: 3,
        answered: propositionSegmentValues.needsSatisfied == "yes" || propositionSegmentValues.needsSatisfied == "no" ? true : false
      },
      {
        key: propositionSegmentValues.productUniqueness === "yes" ? "uniques selling point has been determined." : "Uniques selling point not determined.",
        value: propositionSegmentValues.productUniqueness === "yes" ? "No recommendation" : "Value proposition canvas",
        type: 1,
        question: 4,
        answered: propositionSegmentValues.productUniqueness == "yes" || propositionSegmentValues.productUniqueness == "no" ? true : false
      },
      {
        key: propositionSegmentValues.elevatorPitch === "yes" ? "An elevator pitch has been prepared." : "elevator pitch template",
        value: propositionSegmentValues.elevatorPitch === "yes" ? "No recommendation" : "No elevator pitch",
        type: 1,
        question: 5,
        answered: propositionSegmentValues.elevatorPitch == "yes" || propositionSegmentValues.elevatorPitch == "no" ? true : false
      }
    ]
    //Cost Structure
    const costSegment = [
      {
        key: costStructureValues.deliveryCost == "yes" ? "Cost of sales has been determined." : "Cost of sales not determined.",
        value: costStructureValues.deliveryCost == "yes" ? "No Recommendation" : "Costing, product & service pricing",
        type: 1,
        question: 1,
        answered: costStructureValues.deliveryCost == "yes" || costStructureValues.deliveryCost == "no" ? true : false
      },
      {
        key: costStructureValues.acquiringCost == "yes" ? "Cos of sales has been determined." : "Cost of sales not determined.",
        value: costStructureValues.acquiringCost == "yes" ? "No Recommendation" : "Costing, product & service pricing",
        type: 1,
        question: 2,
        answered: costStructureValues.acquiringCost == "yes" || costStructureValues.acquiringCost == "no" ? true : false
      },
      {
        key: costStructureValues.customerRelationship == "yes" ? "Cost of customer retention  determined." : "Cost of customer retention not determined.",
        value: costStructureValues.customerRelationship == "yes" ? "No Recommendation" : "Costing, product & service pricing",
        type: 1,
        question: 3,
        answered: costStructureValues.customerRelationship == "yes" || costStructureValues.customerRelationship == "no" ? true : false
      },
      {
        key: costStructureValues.marketSegments == "yes" ? "cost of market penetration has been determined." : "Cost of market penetration not determined.",
        value: costStructureValues.marketSegments == "yes" ? "No Recommendation" : "Costing, product & service pricing",
        type: 1,
        question: 4,
        answered: costStructureValues.marketSegments == "yes" || costStructureValues.marketSegments == "no" ? true : false
      }
    ]
    //Proof of Concept
    const proofSegment = [
      {
        key: proofConceptValues.proofOfConcept === "yes" ? "Ideal customer experience has been determined." : "Ideal customer experience has not been determined.",
        value: proofConceptValues.proofOfConcept === "yes" ? "No recommendation" : "Proof of Concept",
        type: 1,
        question: 1,
        answered: proofConceptValues.proofOfConcept == "yes" || proofConceptValues.proofOfConcept == "no" ? true : false
      }
    ]
    //Key Resources

    const keyResources = [{
      key: keyResourcesSegmentValues.resources === "yes" ? "Key resources needed have been determined." : "Key resources needed have not been determined",
      value: keyResourcesSegmentValues.resources === "yes" ? "No recommendation" : "organizational design and development",
      type: 1,
      question: 1,
      answered: keyResourcesSegmentValues.resources == "yes" || keyResourcesSegmentValues.resources == "no" ? true : false
    }]



    const payload = {
      "segment": "Concept",
      "userId": user?.id,
      "segmentResponses": {
        "Prototype": prototypeSegment,
        "Functional": functionalSegment,
        "Customer": customerSegment,
        "Revenue": revenue,
        "Value": valuePropositionSegment,
        "Cost": costSegment,
        "Proof": proofSegment,
        "Resources": keyResources
      },
      "segmentValues": {
        "prototypeSegmentValues": prototypeSegmentValues,
        "functionalSegmentValues": functionalSegmentValues,
        "customerSegmentValues": customerSegmentValues,
        "revenueStreamValues": revenueStreamValues,
        "propositionSegmentValues": propositionSegmentValues,
        "costStructureValues": costStructureValues,
        "proofConceptValues": proofConceptValues,
        "keyResourcesSegmentValues": keyResourcesSegmentValues
      }

    } as IConcept
    console.log("array of answers", payload)
    const isUpdate = recommendation.segmentResponses ? true : false;
    if (isUpdate) {
      await supabase
        .from('Recomendations')
        .update({
          segmentResponses: {
            "Prototype": prototypeSegment,
            "Functional": functionalSegment,
            "Customer": customerSegment,
            "Revenue": revenue,
            "Value": valuePropositionSegment,
            "Cost": costSegment,
            "Proof": proofSegment,
            "Resources": keyResources
          }
        })
        .eq('id', recommendation.id);

      await supabase
        .from('Recomendations')
        .update({
          segmentValues: {
            "prototypeSegmentValues": prototypeSegmentValues,
            "functionalSegmentValues": functionalSegmentValues,
            "customerSegmentValues": customerSegmentValues,
            "revenueStreamValues": revenueStreamValues,
            "propositionSegmentValues": propositionSegmentValues,
            "costStructureValues": costStructureValues,
            "proofConceptValues": proofConceptValues,
            "keyResourcesSegmentValues": keyResourcesSegmentValues
          }
        })
        .eq('id', recommendation.id)

    } else {
      const result = await Api.POST_CreateConceptRecommendation(payload)
      navigate('/HealthReport', { state: { bizInd: bizInd, bizPhase: bizPhase } });
      console.log('Result is', result)
    }


  }
  const handleChangePrototype = (question: string, field: string, event: React.ChangeEvent<HTMLInputElement>, index: number) => {
    const indexOfObject = PrototypeSegment.findIndex(object => {
      return object.question === question;
    });
    setPrototypeSegmentValues({ ...prototypeSegmentValues, [field]: (event.target as HTMLInputElement).value });

    PrototypeSegment.splice(indexOfObject, 1);
  };
  const handleChangeFunctional = (question: string, field: string, event: React.ChangeEvent<HTMLInputElement>, index: number) => {
    const indexOfObject = FunctionalSegment.findIndex(object => {
      return object.question === question;
    });
    setFunctionalSegmentValues({ ...functionalSegmentValues, [field]: (event.target as HTMLInputElement).value });

    FunctionalSegment.splice(indexOfObject, 1);
  };

  const handleChangeCustomerSegment = (question: string, field: string, event: React.ChangeEvent<HTMLInputElement>, index: number) => {
    const indexOfObject = CustomerSegment.findIndex(object => {
      return object.question === question;
    });
    setCustomerSegmentValues({ ...customerSegmentValues, [field]: (event.target as HTMLInputElement).value });

    CustomerSegment.splice(indexOfObject, 1);
  };
  const handleChangeRevenueSegment = (question: string, field: string, event: React.ChangeEvent<HTMLInputElement>, index: number) => {
    const indexOfObject = RevenueStream.findIndex(object => {
      return object.question === question;
    });
    setRevenueStreamValues({ ...revenueStreamValues, [field]: (event.target as HTMLInputElement).value });

    RevenueStream.splice(indexOfObject, 1);
  };

  const handleChangePropositionSegment = (question: string, field: string, event: React.ChangeEvent<HTMLInputElement>, index: number) => {
    const indexOfObject = PropositionSegment.findIndex(object => {
      return object.question === question;
    });
    setPropositionSegmentValues({ ...customerSegmentValues, [field]: (event.target as HTMLInputElement).value });

    PropositionSegment.splice(indexOfObject, 1);
  };
  const handleChangeCostSegment = (question: string, field: string, event: React.ChangeEvent<HTMLInputElement>, index: number) => {
    const indexOfObject = CostStructure.findIndex(object => {
      return object.question === question;
    });
    setCostStructureValues({ ...costStructureValues, [field]: (event.target as HTMLInputElement).value });

    CostStructure.splice(indexOfObject, 1);
  };
  const handleChangeProofSegment = (question: string, field: string, event: React.ChangeEvent<HTMLInputElement>, index: number) => {
    const indexOfObject = ProofConcept.findIndex(object => {
      return object.question === question;
    });
    setProofConceptValues({ ...propositionSegmentValues, [field]: (event.target as HTMLInputElement).value });

    ProofConcept.splice(indexOfObject, 1);
  };

  const handleChangeKeyResourcesSegment = (question: string, field: string, event: React.ChangeEvent<HTMLInputElement>, index: number) => {
    const indexOfObject = KeyResourcesSegment.findIndex(object => {
      return object.question === question;
    });
    setKeyResourcesSegmentValues({ ...keyResourcesSegmentValues, [field]: (event.target as HTMLInputElement).value });

    KeyResourcesSegment.splice(indexOfObject, 1);
  };
  const state = useSelector(selectRecomendationState);
  const recommendation: any = state.persistedReducer.RecomendationReducer.selectedRecomendation;
  console.log(recommendation)
  console.log(customerSegment);
  //Prototype
  let prototypeQuestions: { question: string, field: string }[] = []

  if (recommendation.segmentResponses) {
    prototype.forEach(question => {
      if (recommendation.segmentResponses?.Prototype.some((res: any) => res.question == question.number && !res.answered)) {
        prototypeQuestions.push(question);
      }
    });
  } else {
    prototypeQuestions = [...prototype]
  }

  //Functional
  let functionalQuestions: { question: string, field: string }[] = []

  if (recommendation.segmentResponses) {
    functionalCapability.forEach(question => {
      if (recommendation.segmentResponses?.Functional.some((res: any) => res.question == question.number && !res.answered)) {
        functionalQuestions.push(question);
      }
    });
  } else {
    functionalQuestions = [...functionalCapability]
  }
  //Customer
  let customerSegmentQuestions: { question: string, field: string }[] = []

  if (recommendation.segmentResponses) {
    customerSegment.forEach(question => {
      if (recommendation.segmentResponses?.Customer.some((res: any) => res.question == question.number && !res.answered)) {
        customerSegmentQuestions.push(question);
      }
    });
  } else {
    customerSegmentQuestions = [...customerSegment]
  }
  //Revenue
  let revenueQuestions: { question: string, field: string }[] = []

  if (recommendation.segmentResponses) {
    revenue.forEach(question => {
      if (recommendation.segmentResponses?.Revenue.some((res: any) => res.question == question.number && !res.answered)) {
        revenueQuestions.push(question);
      }
    });
  } else {
    revenueQuestions = [...revenue]
  }

  //Value Prop
  let valueQuestions: { question: string, field: string }[] = []

  if (recommendation.segmentResponses) {
    valuePropositionSegment.forEach(question => {
      if (recommendation.segmentResponses?.Value.some((res: any) => res.question == question.number && !res.answered)) {
        valueQuestions.push(question);
      }
    });
  } else {
    valueQuestions = [...valuePropositionSegment]
  }

  //Cost Structure

  let costQuestions: { question: string, field: string }[] = []

  if (recommendation.segmentResponses) {
    costStructureSeg.forEach(question => {
      if (recommendation.segmentResponses?.Cost.some((res: any) => res.question == question.number && !res.answered)) {
        costQuestions.push(question);
      }
    });
  } else {
    costQuestions = [...costStructureSeg]
  }
  //Proof of Concept
  let proofQuestions: { question: string, field: string }[] = []


  if (recommendation.segmentResponses) {
    proof.forEach(question => {
      if (recommendation.segmentResponses?.Proof.some((res: any) => res.question == question.number && !res.answered)) {
        proofQuestions.push(question);
      }
    });
  } else {
    proofQuestions = [...proof]
  }

  //Resources
  let resourcesQuestions: { question: string, field: string }[] = []

  if (recommendation.segmentResponses) {
    keyResourcesSegment.forEach(question => {
      if (recommendation.segmentResponses?.Value.some((res: any) => res.question == question.number && !res.answered)) {
        resourcesQuestions.push(question);
      }
    });
  } else {
    resourcesQuestions = [...keyResourcesSegment]
  }
  useEffect(() => {
    if (recommendation?.segmentValues && recommendation.segmentValues.prototypeSegmentValues) {
      setPrototypeSegmentValues(recommendation.segmentValues.prototypeSegmentValues);
    }
    if (recommendation?.segmentValues && recommendation.segmentValues.functionalSegmentValues) {
      setFunctionalSegmentValues(recommendation.segmentValues.functionalSegmentValues);
    }
    if (recommendation?.segmentValues && recommendation.segmentValues.customerSegmentValues) {
      setCustomerSegmentValues(recommendation.segmentValues.customerSegmentValues);
    }
    if (recommendation?.segmentValues && recommendation.segmentValues.revenueStreamValues) {
      setRevenueStreamValues(recommendation.segmentValues.revenueStreamValues);
    }
    if (recommendation?.segmentValues && recommendation.segmentValues.propositionSegmentValues) {
      setPropositionSegmentValues(recommendation.segmentValues.propositionSegmentValues);
    }
    if (recommendation?.segmentValues && recommendation.segmentValues.costStructureValues) {
      setCostStructureValues(recommendation.segmentValues.costStructureValues);
    }
    if (recommendation?.segmentValues && recommendation.segmentValues.propositionSegmentValues) {
      setProofConceptValues(recommendation.segmentValues.propositionSegmentValues);
    }

    if (recommendation?.segmentValues && recommendation.segmentValues.keyResourcesSegmentValues) {
      setKeyResourcesSegmentValues(recommendation.segmentValues.keyResourcesSegmentValues);
    }
  }, [])

  return (
    <div className='Basic'>
      <UserNavbar />
      <Container>
        <Grid container spacing={4}>
          <Grid item xs={12} sm={12} md={4} lg={4}>
            <Typography style={{ fontWeight: "bolder", marginTop: "10px" }}>COMPANY</Typography>
            <Button
              className='profAdd'
              variant='outlined'
              style={{ marginBottom: "20px", marginTop: "10px", padding: "5px !important" }}
            >
              +  Add Company
            </Button>
            <div className='Accords'>
              <div className='sideAccord'>
                <AccessmentAccordion setSelectedRecommedation={false} />
              </div>
            </div>
          </Grid>
          <Grid item xs={12} sm={12} md={8} lg={8}>
            <Alert style={{ backgroundColor: "#00d3dd" }} severity="info">Next Step! Complete your Company Assessment.</Alert>
            <Typography className='biz' variant='h5'>Biz Assessment</Typography>
            <div className='companyBox'>
              <img
                src={company}
                alt='comLogo'
                className='company'
              />
              <div className='companyInf' style={{ marginTop: _isMobile ? "25px" : "" }}>
                <div className='Location'>
                  <Typography style={{ fontSize: "smaller", maxWidth: "90%" }}><strong>Location:</strong> N/A</Typography>
                </div>
                <div className='indust'>
                  <Typography style={{ fontSize: "smaller", maxWidth: "90%" }}><strong>Industry:</strong> {bizInd && bizInd[0]?.label}</Typography>
                </div>
                <div className='phase'>
                  <Typography style={{ fontSize: "smaller", maxWidth: "90%" }}><strong>Business Phase:</strong> {bizPhase && bizPhase[0]?.label}</Typography>
                </div>
              </div>
            </div>
            <div className='bassicAccords'>
              <Accordion>
                <AccordionSummary
                  expandIcon={<ExpandMoreIcon />}
                  aria-controls="panel2a-content"
                  id="panel2a-header"
                >
                  <Typography className=''>Prototype</Typography>
                </AccordionSummary>
                <AccordionDetails>
                  <div className='rev'>
                    {
                      prototypeQuestions.map((val, index) => {
                        return (
                          <div key={index}>
                            <FormControl>
                              <FormLabel id="demo-controlled-radio-buttons-group">
                                {val.question}
                              </FormLabel>
                              <RadioGroup
                                aria-labelledby="demo-controlled-radio-buttons-group"
                                //name="controlled-radio-buttons-group"
                                value={values[index]}
                                onChange={(e) => handleChangePrototype(val.question, val.field, e, index)}
                              >
                                <FormControlLabel value="yes" checked={false} control={<Radio />} label="Yes" />
                                <FormControlLabel value="no" checked={false} control={<Radio />} label="No" />

                              </RadioGroup>
                            </FormControl>
                          </div>
                        )

                      })
                    }
                  </div>
                </AccordionDetails>
              </Accordion>
              <Accordion>
                <AccordionSummary
                  expandIcon={<ExpandMoreIcon />}
                  aria-controls="panel2a-content"
                  id="panel2a-header"
                >
                  <Typography className=''>Functional Capability</Typography>
                </AccordionSummary>
                <AccordionDetails>
                  <div className='rev'>
                    {
                      functionalQuestions.map((val, index) => {
                        return (
                          <div key={index}>
                            <FormControl>
                              <FormLabel id="demo-controlled-radio-buttons-group">
                                {val.question}
                              </FormLabel>
                              <RadioGroup
                                aria-labelledby="demo-controlled-radio-buttons-group"
                                //name="controlled-radio-buttons-group"
                                value={values[index]}
                                onChange={(e) => handleChangeFunctional(val.question, val.field, e, index)}
                              >
                                <FormControlLabel value="yes" checked={false} control={<Radio />} label="Yes" />
                                <FormControlLabel value="no" checked={false} control={<Radio />} label="No" />

                              </RadioGroup>
                            </FormControl>
                          </div>
                        )

                      })
                    }
                  </div>
                </AccordionDetails>
              </Accordion>
              <Accordion>
                <AccordionSummary
                  expandIcon={<ExpandMoreIcon />}
                  aria-controls="panel2a-content"
                  id="panel2a-header"
                >
                  <Typography className=''>Customer segment</Typography>
                </AccordionSummary>
                <AccordionDetails>
                  <div className='rev'>
                    {
                      customerSegmentQuestions.map((val, index) => {
                        return (
                          <div key={index}>
                            <FormControl>
                              <FormLabel id="demo-controlled-radio-buttons-group">
                                {val.question}
                              </FormLabel>
                              <RadioGroup
                                aria-labelledby="demo-controlled-radio-buttons-group"
                                //name="controlled-radio-buttons-group"
                                value={values[index]}
                                onChange={(e) => handleChangeCustomerSegment(val.question, val.field, e, index)}
                              >
                                <FormControlLabel value="yes" checked={false} control={<Radio />} label="Yes" />
                                <FormControlLabel value="no" checked={false} control={<Radio />} label="No" />

                              </RadioGroup>
                            </FormControl>
                          </div>
                        )

                      })
                    }
                  </div>
                </AccordionDetails>
              </Accordion>
              <Accordion>
                <AccordionSummary
                  expandIcon={<ExpandMoreIcon />}
                  aria-controls="panel2a-content"
                  id="panel2a-header"
                >
                  <Typography className=''>Revenue Streams</Typography>
                </AccordionSummary>
                <AccordionDetails>
                  <div className='rev'>
                    {
                      revenueQuestions.map((val, index) => {
                        return (
                          <div key={index}>
                            <FormControl>
                              <FormLabel id="demo-controlled-radio-buttons-group">
                                {val.question}
                              </FormLabel>
                              <RadioGroup
                                aria-labelledby="demo-controlled-radio-buttons-group"
                                //name="controlled-radio-buttons-group"
                                value={values[index]}
                                onChange={(e) => handleChangeRevenueSegment(val.question, val.field, e, index)}
                              >
                                <FormControlLabel value="yes" checked={false} control={<Radio />} label="Yes" />
                                <FormControlLabel value="no" checked={false} control={<Radio />} label="No" />

                              </RadioGroup>
                            </FormControl>
                          </div>
                        )

                      })
                    }
                  </div>

                </AccordionDetails>
              </Accordion>
              <Accordion>
                <AccordionSummary
                  expandIcon={<ExpandMoreIcon />}
                  aria-controls="panel2a-content"
                  id="panel2a-header"
                >
                  <Typography className=''>Value Proposition</Typography>
                </AccordionSummary>
                <AccordionDetails>
                  <div className='rev'>
                    {
                      valueQuestions.map((val, index) => {
                        return (
                          <div key={index}>
                            <FormControl>
                              <FormLabel id="demo-controlled-radio-buttons-group">
                                {val.question}
                              </FormLabel>
                              <RadioGroup
                                aria-labelledby="demo-controlled-radio-buttons-group"
                                //name="controlled-radio-buttons-group"
                                value={values[index]}
                                onChange={(e) => handleChangePropositionSegment(val.question, val.field, e, index)}
                              >
                                <FormControlLabel value="yes" checked={false} control={<Radio />} label="Yes" />
                                <FormControlLabel value="no" checked={false} control={<Radio />} label="No" />

                              </RadioGroup>
                            </FormControl>
                          </div>
                        )

                      })
                    }
                  </div>
                </AccordionDetails>
              </Accordion>
              <Accordion>
                <AccordionSummary
                  expandIcon={<ExpandMoreIcon />}
                  aria-controls="panel2a-content"
                  id="panel2a-header"
                >
                  <Typography className="">Cost Structure</Typography>
                </AccordionSummary>
                <AccordionDetails>
                  <div className='rev'>
                    {
                      costQuestions.map((val, index) => {
                        return (
                          <div key={index}>
                            <FormControl>
                              <FormLabel id="demo-controlled-radio-buttons-group">
                                {val.question}
                              </FormLabel>
                              <RadioGroup
                                aria-labelledby="demo-controlled-radio-buttons-group"
                                //name="controlled-radio-buttons-group"
                                value={values[index]}
                                onChange={(e) => handleChangeCostSegment(val.question, val.field, e, index)}
                              >
                                <FormControlLabel value="yes" checked={false} control={<Radio />} label="Yes" />
                                <FormControlLabel value="no" checked={false} control={<Radio />} label="No" />

                              </RadioGroup>
                            </FormControl>
                          </div>
                        )

                      })
                    }
                  </div>

                </AccordionDetails>
              </Accordion>
              <Accordion>
                <AccordionSummary
                  expandIcon={<ExpandMoreIcon />}
                  aria-controls="panel2a-content"
                  id="panel2a-header"
                >
                  <Typography className=''>Proof of concept</Typography>
                </AccordionSummary>
                <AccordionDetails>
                  <div className='rev'>
                    {
                      proofQuestions.map((val, index) => {
                        return (
                          <div key={index}>
                            <FormControl>
                              <FormLabel id="demo-controlled-radio-buttons-group">
                                {val.question}
                              </FormLabel>
                              <RadioGroup
                                aria-labelledby="demo-controlled-radio-buttons-group"
                                //name="controlled-radio-buttons-group"
                                value={values[index]}
                                onChange={(e) => handleChangeProofSegment(val.question, val.field, e, index)}
                              >
                                <FormControlLabel value="yes" checked={false} control={<Radio />} label="Yes" />
                                <FormControlLabel value="no" checked={false} control={<Radio />} label="No" />

                              </RadioGroup>
                            </FormControl>
                          </div>
                        )

                      })
                    }
                  </div>

                </AccordionDetails>
              </Accordion>
              <Accordion>
                <AccordionSummary
                  expandIcon={<ExpandMoreIcon />}
                  aria-controls="panel2a-content"
                  id="panel2a-header"
                >
                  <Typography className=''>Key Resources</Typography>
                </AccordionSummary>
                <AccordionDetails>
                  <div className='rev'>
                    {
                      resourcesQuestions.map((val, index) => {
                        return (
                          <div key={index}>
                            <FormControl>
                              <FormLabel id="demo-controlled-radio-buttons-group">
                                {val.question}
                              </FormLabel>
                              <RadioGroup
                                aria-labelledby="demo-controlled-radio-buttons-group"
                                //name="controlled-radio-buttons-group"
                                value={values[index]}
                                onChange={(e) => handleChangeKeyResourcesSegment(val.question, val.field, e, index)}
                              >
                                <FormControlLabel value="yes" checked={false} control={<Radio />} label="Yes" />
                                <FormControlLabel value="no" checked={false} control={<Radio />} label="No" />

                              </RadioGroup>
                            </FormControl>
                          </div>
                        )

                      })
                    }
                  </div>
                </AccordionDetails>
              </Accordion>
            </div>

            <div className='AssesButtonsA'>
              <Button
                variant='outlined'
                className='AssesBack'
              >
                Back
              </Button>
              <Button
                variant='outlined'
                className='AssesSave'
                onClick={() => createReport()}

              >
                Save

              </Button>
            </div>
          </Grid>
        </Grid>
      </Container>
      <div className='footD'>
        <Footernew />
      </div>
    </div>
  )
}

export default Concept;
// export const { save } = actions;
// export default reducer;

//try Export at the top