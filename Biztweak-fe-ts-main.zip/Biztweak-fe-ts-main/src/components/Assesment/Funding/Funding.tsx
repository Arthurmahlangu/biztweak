import React, { useEffect, useState } from "react";
import { Container, Grid, Button } from '@material-ui/core';
import Accordion from '@material-ui/core/Accordion';
import AccordionSummary from '@material-ui/core/AccordionSummary';
import AccordionDetails from '@material-ui/core/AccordionDetails';
import Typography from '@material-ui/core/Typography';
import ExpandMoreIcon from '@material-ui/icons/ExpandMore';
import MuiAlert from '@material-ui/lab/Alert';
import UserNavbar from '../../UserNav/UserNav';
import company from '../../../Images/company.png'
import Radio from "@mui/material/Radio";
import RadioGroup from "@mui/material/RadioGroup";
import FormControlLabel from "@mui/material/FormControlLabel";
import FormControl from "@mui/material/FormControl";
import FormLabel from "@mui/material/FormLabel";
import { Link, useLocation } from 'react-router-dom';
import { createSlice } from '@reduxjs/toolkit';
import { Api } from '../../../services/endpoints';
import { IFunding, IRecomendation } from '../../../Interfaces/IRecomendation'
import { supabase } from '../../../supabaseClient';
import Footernew from "../../Footer/Footernew";
import customerSegment from '../../../json/customerSegment.json';
import channels from "../../../json/channels.json";
import revenue from "../../../json/revenueStreams.json";
import valueProposition from "../../../json/valueProposition.json";
import financial from "../../../json/financialManagement.json"
import proof from "../../../json/proofOfConcept.json"
import { useSelector } from 'react-redux';
import { selectRecomendationState } from "../../../Slice/createSlice";
import '../Assessment.css'

type LocationState = {
  bizInd: Array<{
    value: number;
    label: string
  }>,
  bizPhase: Array<{
    value: number;
    label: string
  }>
}


const Funding = () => {
  const location = useLocation();
  const bizInd = (location.state as LocationState)?.bizInd;
  const bizPhase = (location.state as LocationState)?.bizPhase;
  const [CustomerSegment, setCustomerSegment] = useState<{ question: string, field: string }[]>(customerSegment);
  const [RevenueStream, setRevenueStream] = useState<{ question: string, field: string }[]>(revenue);
  const [Channel, setChannel] = useState<{ question: string, field: string }[]>(channels);
  const [PropositionSegment, setPropositionSegment] = useState<{ question: string, field: string }[]>(valueProposition);
  const [FinancialManagement, setFinancialManagement] = useState<{ question: string, field: string }[]>(financial);
  const [ProofConcept, setProofConcept] = useState<{ question: string, field: string }[]>(proof);

  const [values, setValues] = useState<any>({});
  const [customerSegmentValues, setCustomerSegmentValues] = useState<any>({});
  const [revenueStreamValues, setRevenueStreamValues] = useState<any>({});
  const [channelValues, setChannelValues] = useState<any>({});
  const [propositionSegmentValues, setPropositionSegmentValues] = useState<any>({});
  const [financialManagementValues, setFinancialManagementValues] = useState<any>({});
  const [proofConceptValues, setProofConceptValues] = useState<any>({});


  const user = supabase.auth.user()
  function Alert(props: any) {
    return <MuiAlert elevation={6} variant="filled" {...props} />;
  }
  const createReport = async () => {
    //Channels
    const channels = [
      {
        key: channelValues.reachCustomer == "yes" ? "Customer profile has been determined." : "Customer profile not determined",
        value: channelValues.reachCustomer == "yes" ? "No Recommendation" : "Social media marketing, marketing plan, marketing startegy, sales funnel, customer acquisition plan.",
        type: 1,
        question: 1,
        answered: channelValues.reachCustomer == "yes" || channelValues.reachCustomer == "no" ? true : false
      },
      {
        key: channelValues.marketingPlan == "yes" ? "Strategies to reach customers has been determined." : "Strategies to reach customers has not been determined.",
        value: channelValues.marketingPlan == "yes" ? "No Recommendation" : "Marketing Plan.",
        type: 1,
        question: 2,
        answered: channelValues.marketingPlan == "yes" || channelValues.marketingPlan == "no" ? true : false
      },
      {
        key: channelValues.developedNetwork == "yes" ? "Network to reach target audience has been determined." : "Network to reach target audience has been determined.",
        value: channelValues.developedNetwork == "yes" ? "No Recommendation" : "Sales Funnel",
        type: 1,
        question: 3,
        answered: channelValues.developedNetwork == "yes" || channelValues.developedNetwork == "no" ? true : false
      },
      {
        key: channelValues.customerSupport == "yes" ? "Post sales support has been provided." : "Post sales support is not provided.",
        value: channelValues.customerSupport == "yes" ? "No Recommendation" : "Sales personnel.",
        type: 1,
        question: 4,
        answered: channelValues.customerSupport == "yes" || channelValues.customerSupport == "no" ? true : false
      }
    ]

    // Customer Segment
    const customerSegment = [
      {
        key: customerSegmentValues.productOwner == "yes" ? "Customer profile has been determined." : "Customer profile not determined",
        value: customerSegmentValues.productOwner == "yes" ? "No recommendation" : "Market Research",
        type: 1,
        question: 1,
        answered: customerSegmentValues.productOwner == "yes" || customerSegmentValues.productOwner == "no" ? true : false
      },
      {
        key: customerSegmentValues.tagetAudiance == "yes" ? "Target audience has been determined." : "Target audience has not been selected",
        value: customerSegmentValues.tagetAudiance == "yes" ? "No recommendation" : "Market Intelligence",
        type: 1,
        question: 2,
        answered: customerSegmentValues.tagetAudiance == "yes" || customerSegmentValues.tagetAudiance == "no" ? true : false
      },
      {
        key: customerSegmentValues.tagetAudianceLocation == "yes" ? "Target audience has been located geographically." : "Target audience has not been located geographically",
        value: customerSegmentValues.tagetAudianceLocation == "yes" ? "No recommendation" : "Market Research",
        type: 1,
        question: 3,
        answered: customerSegmentValues.tagetAudianceLocation == "yes" || customerSegmentValues.tagetAudianceLocation == "no" ? true : false
      },
      {
        key: customerSegmentValues.tagetMarketSize == "yes" ? "Target audience has been segmented." : "Target audience has not been segmented.",
        value: customerSegmentValues.tagetMarketSize == "yes" ? "No recommendation" : "SAM SOM TAM",
        type: 1,
        question: 4,
        answered: customerSegmentValues.tagetMarketSize == "yes" || customerSegmentValues.tagetMarketSize == "no" ? true : false
      },
      {
        key: customerSegmentValues.cusReach == "yes" ? "Total accessible market has been determined." : "Total accessible market has not been determined",
        value: customerSegmentValues.cusReach == "yes" ? "No recommendation" : "Market Strategy",
        type: 1,
        question: 5,
        answered: customerSegmentValues.cusReach == "yes" || customerSegmentValues.cusReach == "no" ? true : false
      },
      {
        key: customerSegmentValues.competitor == "yes" ? "Competitors have been identified" : "competitors have not been identified",
        value: customerSegmentValues.competitor == "yes" ? "No recommendation" : "Competitor Analysis",
        type: 1,
        question: 6,
        answered: customerSegmentValues.competitor == "yes" || customerSegmentValues.competitor == "no" ? true : false
      },
      {
        key: customerSegmentValues.marketAccess == "yes" ? "Total accessible market has been determined." : "Total accessible market has not been determined",
        value: customerSegmentValues.marketAccess == "yes" ? "No recommendation" : "Total Addressable market",
        type: 1,
        question: 7,
        answered: customerSegmentValues.marketAccess == "yes" || customerSegmentValues.marketAccess == "no" ? true : false
      },
      {
        key: customerSegmentValues.marketLocation == "yes" ? "Total observable market has been determined." : "Total observable market has not been determined.",
        value: customerSegmentValues.marketLocation == "yes" ? "No recommendation" : "Market Reasearch",
        type: 1,
        question: 8,
        answered: customerSegmentValues.marketLocation == "yes" || customerSegmentValues.marketLocation == "no" ? true : false
      },
      {
        key: customerSegmentValues.idealCustomer == "yes" ? "Ideal customer profile has been determined." : "Ideal customer profile has not been determined.",
        value: customerSegmentValues.idealCustomer == "yes" ? "No recommendation" : "Ideal Customer profile",
        type: 1,
        question: 9,
        answered: customerSegmentValues.idealCustomer == "yes" || customerSegmentValues.idealCustomer == "no" ? true : false
      },
      {
        key: customerSegmentValues.importantCustomer == "yes" ? "Most important not determined." : "Most important customers not determined",
        value: customerSegmentValues.importantCustomer == "yes" ? "No recommendation" : "Market Research",
        type: 1,
        question: 10,
        answered: customerSegmentValues.importantCustomer == "yes" || customerSegmentValues.importantCustomer == "no" ? true : false
      },
      {
        key: customerSegmentValues.customerReaserch == "yes" ? "Customer research has been done" : "Customer research has not been done",
        value: customerSegmentValues.customerReaserch == "yes" ? "No recommendation" : "Job Opportunity Business Research Officer",
        type: 1,
        question: 11,
        answered: customerSegmentValues.customerReaserch == "yes" || customerSegmentValues.customerReaserch == "no" ? true : false
      }
    ]
    //Revenue Streams
    const revenue = [
      {
        key: revenueStreamValues.generatingRevenue == "yes" ? "Has Knowledge of how revenue is generated." : "Does not have Knowledge of how revenue is generated.",
        value: revenueStreamValues.generatingRevenue == "yes" ? "No Recommendation" : "Revenue models",
        type: 1,
        question: 1,
        answered: revenueStreamValues.generatingRevenue == "yes" || revenueStreamValues.generatingRevenue == "no" ? true : false
      },
      {
        key: revenueStreamValues.willingPay == "yes" ? "Value customers are willing to pay for has been determined." : "Value customers are willing to pay fpr not determined.",
        value: revenueStreamValues.willingPay == "yes" ? "No Recommendation" : "Proof of concept",
        type: 1,
        question: 2,
        answered: revenueStreamValues.willingPay == "yes" || revenueStreamValues.willingPay == "no" ? true : false
      },
      {
        key: revenueStreamValues.cusPaymentMethod == "yes" ? "Current payment trends of customers are known." : "Current payment trends of customers are not known.",
        value: revenueStreamValues.cusPaymentMethod == "yes" ? "No Recommendation" : "Competitor analysis",
        type: 1,
        question: 3,
        answered: revenueStreamValues.cusPaymentMethod == "yes" || revenueStreamValues.cusPaymentMethod == "no" ? true : false
      },
      {
        key: revenueStreamValues.preferedPayment == "yes" ? "Preferred paymet method of customers has been determined." : "Preferred paymet method of customers not determined.",
        value: revenueStreamValues.preferedPayment == "yes" ? "No Recommendation" : "Market research, competitor analysis",
        type: 1,
        question: 4,
        answered: revenueStreamValues.preferedPayment == "yes" || revenueStreamValues.preferedPayment == "no" ? true : false
      }
    ]
    //Value Proposition
    const valuePropositionSegment = [
      {
        key: propositionSegmentValues.problem === "yes" ? "Problem being solved has been determined." : "Problem being solved not determined",
        value: propositionSegmentValues.problem === "yes" ? "No recommendation" : "Value proposition canvas",
        type: 1,
        question: 1,
        answered: propositionSegmentValues.problem == "yes" || propositionSegmentValues.problem == "no" ? true : false
      },
      {
        key: propositionSegmentValues.cusValue === "yes" ? "Value being delivered has been determined." : "Value being delivered not determined.",
        value: propositionSegmentValues.cusValue === "yes" ? "No recommendation" : "Business model canvas",
        type: 1,
        question: 2,
        answered: propositionSegmentValues.cusValue == "yes" || propositionSegmentValues.cusValue == "no" ? true : false
      },
      {
        key: propositionSegmentValues.needsSatisfied === "yes" ? "Customer needs have been determined." : "Customer needs have not been determined.",
        value: propositionSegmentValues.needsSatisfied === "yes" ? "No recommendation" : "Value proposition canvas",
        type: 1,
        question: 3,
        answered: propositionSegmentValues.needsSatisfied == "yes" || propositionSegmentValues.needsSatisfied == "no" ? true : false
      },
      {
        key: propositionSegmentValues.productUniqueness === "yes" ? "uniques selling point has been determined." : "Uniques selling point not determined.",
        value: propositionSegmentValues.productUniqueness === "yes" ? "No recommendation" : "Value proposition canvas",
        type: 1,
        question: 4,
        answered: propositionSegmentValues.productUniqueness == "yes" || propositionSegmentValues.productUniqueness == "no" ? true : false
      },
      {
        key: propositionSegmentValues.elevatorPitch === "yes" ? "An elevator pitch has been prepared." : "elevator pitch template",
        value: propositionSegmentValues.elevatorPitch === "yes" ? "No recommendation" : "No elevator pitch",
        type: 1,
        question: 5,
        answered: propositionSegmentValues.elevatorPitch == "yes" || propositionSegmentValues.elevatorPitch == "no" ? true : false
      }
    ]
    //Financial Management

    const financialSegment = [
      {
        key: financialManagementValues.budgetForecast === "yes" ? "Proper Budget forecasting in place." : "No Proper Budget forecasting in place.",
        value: financialManagementValues.budgetForecast === "yes" ? "No recommendation" : "Budget Forecasting",
        type: 2,
        question: 1,
        answered: financialManagementValues.budgetForecast == "yes" || financialManagementValues.budgetForecast == "no" ? true : false
      },
      {
        key: financialManagementValues.reconsiliation === "yes" ? "Company Performs Reconsilistions." : "Company does not perfom Reconciliation.",
        value: financialManagementValues.reconsiliation === "yes" ? "No recommendation" : "Reconsiliation",
        type: 2,
        question: 2,
        answered: financialManagementValues.reconsiliation == "yes" || financialManagementValues.reconsiliation == "no" ? true : false
      },
      {
        key: financialManagementValues.cashFlow === "yes" ? "Has proper cash flow management." : "Does not have proper cash flow management.",
        value: financialManagementValues.cashFlow === "yes" ? "No recommendation" : "Cash Flow Management",
        type: 2,
        question: 3,
        answered: financialManagementValues.cashFlow == "yes" || financialManagementValues.cashFlow == "no" ? true : false
      },
      {
        key: financialManagementValues.documentFinancials === "yes" ? "Financials are documented." : "There are no Documented Financials.",
        value: financialManagementValues.documentFinancials === "yes" ? "No recommendation" : "Documenting Financials",
        type: 2,
        question: 4,
        answered: financialManagementValues.documentFinancials == "yes" || financialManagementValues.documentFinancials == "no" ? true : false
      },
      {
        key: financialManagementValues.FinancialManager === "yes" ? "Has a financial Manager." : "Does Not have a financial Manager.",
        value: financialManagementValues.FinancialManager === "yes" ? "No recommendation" : "Job Opportunity : BookKeeper",
        type: 2,
        question: 5,
        answered: financialManagementValues.FinancialManager == "yes" || financialManagementValues.FinancialManager == "no" ? true : false
      }
    ]
    //Proof of Concept
    const proofSegment = [
      {
        key: proofConceptValues.proofOfConcept === "yes" ? "Ideal customer experience has been determined." : "Ideal customer experience has not been determined.",
        value: proofConceptValues.proofOfConcept === "yes" ? "No recommendation" : "Proof of Concept",
        type: 1,
        question: 1,
        answered: proofConceptValues.proofOfConcept == "yes" || proofConceptValues.proofOfConcept == "no" ? true : false
      }
    ]
    const payload = {
      "segment": "Funding",
      "userId": user?.id,
      "segmentResponses": {
        "Channels": channels,
        "Customer": customerSegment,
        "Revenue": revenue,
        "Value": valuePropositionSegment,
        "Financial": financialSegment,
        "Proof": proofSegment
      },
      "segmentValues": {
        "channelValues": channelValues,
        "customerSegmentValues": customerSegmentValues,
        "Revenue": revenueStreamValues,
        "Value": propositionSegmentValues,
        "financialManagementValues": financialManagementValues,
        "proofConceptValues": proofConceptValues,
      }
    } as IFunding
    console.log("array of answers", payload)


    const isUpdate = recommendation.segmentResponses ? true : false;
    if (isUpdate) {
      await supabase
        .from('Recomendations')
        .update({
          segmentResponses: {
            "Channels": channels,
            "Customer": customerSegment,
            "Revenue": revenue,
            "Value": valuePropositionSegment,
            "Financial": financialSegment,
            "Proof": proofSegment
          }
        })
        .eq('id', recommendation.id);

      await supabase
        .from('Recomendations')
        .update({
          segmentValues: {
            "channelValues": channelValues,
            "customerSegmentValues": customerSegmentValues,
            "Revenue": revenueStreamValues,
            "Value": propositionSegmentValues,
            "financialManagementValues": financialManagementValues,
            "proofConceptValues": proofConceptValues,
          }
        })
        .eq('id', recommendation.id)

    } else {
      const payload = {
        "segment": "Funding",
        "userId": user?.id,
        "assessment": "Funding",
        "phase": bizPhase[0].label,
        "industry": bizInd[0].label,
        "segmentResponses": {
          "Channels": channels,
          "Customer": customerSegment,
          "Revenue": revenue,
          "Value": valuePropositionSegment,
          "Financial": financialSegment,
          "Proof": proofSegment
        },
        "segmentValues": {
          "channelValues": channelValues,
          "customerSegmentValues": customerSegmentValues,
          "revenueStreamValues": revenueStreamValues,
          "propositionSegmentValues": propositionSegmentValues,
          "financialManagementValues": financialManagementValues,
          "proofConceptValues": proofConceptValues,
        }
      } as IFunding

      const result = await Api.POST_CreateFundingRecommendation(payload)
      console.log('Result is', result)
    }

  }
  const handleChangeChannelsSegment = (question: string, field: string, event: React.ChangeEvent<HTMLInputElement>, index: number) => {
    const indexOfObject = Channel.findIndex(object => {
      return object.question === question;
    });
    setChannelValues({ ...channelValues, [field]: (event.target as HTMLInputElement).value });

    Channel.splice(indexOfObject, 1);
  };

  const handleChangeCustomerSegment = (question: string, field: string, event: React.ChangeEvent<HTMLInputElement>, index: number) => {
    const indexOfObject = CustomerSegment.findIndex(object => {
      return object.question === question;
    });
    setCustomerSegmentValues({ ...customerSegmentValues, [field]: (event.target as HTMLInputElement).value });

    CustomerSegment.splice(indexOfObject, 1);
  };
  const handleChangeRevenueSegment = (question: string, field: string, event: React.ChangeEvent<HTMLInputElement>, index: number) => {
    const indexOfObject = RevenueStream.findIndex(object => {
      return object.question === question;
    });
    setRevenueStreamValues({ ...revenueStreamValues, [field]: (event.target as HTMLInputElement).value });

    RevenueStream.splice(indexOfObject, 1);
  };
  const handleChangeValueSegment = (question: string, field: string, event: React.ChangeEvent<HTMLInputElement>, index: number) => {
    const indexOfObject = PropositionSegment.findIndex(object => {
      return object.question === question;
    });
    setPropositionSegmentValues({ ...propositionSegmentValues, [field]: (event.target as HTMLInputElement).value });

    PropositionSegment.splice(indexOfObject, 1);
  };
  const handleChangeFinancialSegment = (question: string, field: string, event: React.ChangeEvent<HTMLInputElement>, index: number) => {
    const indexOfObject = FinancialManagement.findIndex(object => {
      return object.question === question;
    });
    setFinancialManagementValues({ ...financialManagementValues, [field]: (event.target as HTMLInputElement).value });

    FinancialManagement.splice(indexOfObject, 1);
  };
  const handleChangeProofSegment = (question: string, field: string, event: React.ChangeEvent<HTMLInputElement>, index: number) => {
    const indexOfObject = ProofConcept.findIndex(object => {
      return object.question === question;
    });
    setProofConceptValues({ ...propositionSegmentValues, [field]: (event.target as HTMLInputElement).value });

    ProofConcept.splice(indexOfObject, 1);
  };
  const state = useSelector(selectRecomendationState);
  const recommendation: any = state.persistedReducer.RecomendationReducer.selectedRecomendation;
  console.log(recommendation)
  console.log(customerSegment);
  //Channel
  let channelQuestions: { question: string, field: string }[] = []

  if (recommendation.segmentResponses) {
    channels.forEach(question => {
      if (recommendation.segmentResponses?.Channels.some((res: any) => res.question == question.number && !res.answered)) {
        channelQuestions.push(question);
      }
    });
  } else {
    channelQuestions = [...channels]
  }
  //Customer
  let customerSegmentQuestions: { question: string, field: string }[] = []

  if (recommendation.segmentResponses) {
    customerSegment.forEach(question => {
      if (recommendation.segmentResponses?.Customer.some((res: any) => res.question == question.number && !res.answered)) {
        customerSegmentQuestions.push(question);
      }
    });
  } else {
    customerSegmentQuestions = [...customerSegment]
  }
  //Revenue
  let revenueQuestions: { question: string, field: string }[] = []

  if (recommendation.segmentResponses) {
    revenue.forEach(question => {
      if (recommendation.segmentResponses?.Revenue.some((res: any) => res.question == question.number && !res.answered)) {
        revenueQuestions.push(question);
      }
    });
  } else {
    revenueQuestions = [...revenue]
  }

  //Value Prop
  let valueQuestions: { question: string, field: string }[] = []

  if (recommendation.segmentResponses) {
    valueProposition.forEach(question => {
      if (recommendation.segmentResponses?.Value.some((res: any) => res.question == question.number && !res.answered)) {
        valueQuestions.push(question);
      }
    });
  } else {
    valueQuestions = [...valueProposition]
  }
  //Financial Management
  let financialQuestions: { question: string, field: string }[] = []

  if (recommendation.segmentResponses) {
    financial.forEach(question => {
      if (recommendation.segmentResponses?.Financial.some((res: any) => res.question == question.number && !res.answered)) {
        financialQuestions.push(question);
      }
    });
  } else {
    financialQuestions = [...financial]
  }

  //Proof of Concept
  let proofQuestions: { question: string, field: string }[] = []


  if (recommendation.segmentResponses) {
    proof.forEach(question => {
      if (recommendation.segmentResponses?.Proof.some((res: any) => res.question == question.number && !res.answered)) {
        proofQuestions.push(question);
      }
    });
  } else {
    proofQuestions = [...proof]
  }
  useEffect(() => {
    if (recommendation?.segmentValues && recommendation.segmentValues.channelValues) {
      setChannelValues(recommendation.segmentValues.channelValues);
    }
    if (recommendation?.segmentValues && recommendation.segmentValues.customerSegmentValues) {
      setCustomerSegmentValues(recommendation.segmentValues.customerSegmentValues);
    }
    if (recommendation?.segmentValues && recommendation.segmentValues.revenueStreamValues) {
      debugger
      setRevenueStreamValues(recommendation.segmentValues.revenueStreamValues);
    }
    if (recommendation?.segmentValues && recommendation.segmentValues.propositionSegmentValues) {
      setPropositionSegmentValues(recommendation.segmentValues.propositionSegmentValues);
    }
    if (recommendation?.segmentValues && recommendation.segmentValues.financialManagementValues) {
      setFinancialManagementValues(recommendation.segmentValues.financialManagementValues);
    }
    if (recommendation?.segmentValues && recommendation.segmentValues.propositionSegmentValues) {
      debugger
      setProofConceptValues(recommendation.segmentValues.propositionSegmentValues);
    }
  }, [])

  return (
    <div className="sell-con">
      <UserNavbar />
      <Container>
        <Grid container spacing={2}>
          {/* <div style={{}}> */}
          <Grid item xs={12} sm={12} md={4} lg={4}>
            <Typography variant='h5' style={{ fontFamily: "Rockwell !important", marginTop: "15%" }}>Company</Typography>
            <Button
              className='profAdd'
              variant='outlined'
            >
              Add Company
            </Button>
            <div className='Accords' style={{ paddingRight: "10px", marginBottom: "10%", marginTop: "10%" }} >
              <div className='sideAccord'>
                <Accordion>
                  <AccordionSummary
                    expandIcon={<ExpandMoreIcon />}
                    aria-controls="panel1a-content"
                    id="panel1a-header"
                  >
                    <Typography className=''>No Name</Typography>
                  </AccordionSummary>
                  <AccordionDetails>
                    <Typography>
                      Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse malesuada lacus ex,
                      sit amet blandit leo lobortis eget.
                    </Typography>
                  </AccordionDetails>
                </Accordion>
              </div>
            </div>
          </Grid>
          {/* </div> */}
          <Grid item xs={12} sm={12} md={8} lg={8}>
            <Alert style={{ backgroundColor: "#00d3dd" }} severity="info">Next Step! Complete your Company Assessment.</Alert>
            <Typography className='biz' variant='h5'>Biz Assessment</Typography>
            <div className='companyBox'>
              <img
                src={company}
                alt='comLogo'
                className='company'
              />
              <div className='companyInf'>
                <div className='Location' style={{ marginTop: "20px" }}>
                  <Typography>Location: N/A</Typography>
                </div>
                <div className="indust">
                  <Typography>Industry: {bizInd ? bizInd[0]?.label : recommendation.industry}</Typography>
                </div>
                <div className="phase">
                  <Typography>Business Phase: {bizPhase ? bizPhase[0]?.label : recommendation.phase}</Typography>
                </div>
              </div>
            </div>
            <div className="questionare">
              <Accordion>
                <AccordionSummary
                  expandIcon={<ExpandMoreIcon />}
                  aria-controls="panel2a-content"
                  id="panel2a-header"
                >
                  <Typography className=''>Channels</Typography>
                </AccordionSummary>
                <AccordionDetails>
                  <div className='rev'>
                    {
                      channelQuestions.map((val, index) => {
                        return (
                          <div key={index}>
                            <FormControl>
                              <FormLabel id="demo-controlled-radio-buttons-group">
                                {val.question}
                              </FormLabel>
                              <RadioGroup
                                aria-labelledby="demo-controlled-radio-buttons-group"
                                //name="controlled-radio-buttons-group"
                                value={values[index]}
                                onChange={(e) => handleChangeChannelsSegment(val.question, val.field, e, index)}
                              >
                                <FormControlLabel value="yes" checked={false} control={<Radio />} label="Yes" />
                                <FormControlLabel value="no" checked={false} control={<Radio />} label="No" />

                              </RadioGroup>
                            </FormControl>
                          </div>
                        )

                      })
                    }
                  </div>
                </AccordionDetails>
              </Accordion>
              <Accordion>
                <AccordionSummary
                  expandIcon={<ExpandMoreIcon />}
                  aria-controls="panel2a-content"
                  id="panel2a-header"
                >
                  <Typography className=''>Customer segment</Typography>
                </AccordionSummary>
                <AccordionDetails>
                  <div className='rev'>
                    {
                      customerSegmentQuestions.map((val, index) => {
                        return (
                          <div key={index}>
                            <FormControl>
                              <FormLabel id="demo-controlled-radio-buttons-group">
                                {val.question}
                              </FormLabel>
                              <RadioGroup
                                aria-labelledby="demo-controlled-radio-buttons-group"
                                //name="controlled-radio-buttons-group"
                                value={values[index]}
                                onChange={(e) => handleChangeCustomerSegment(val.question, val.field, e, index)}
                              >
                                <FormControlLabel value="yes" checked={false} control={<Radio />} label="Yes" />
                                <FormControlLabel value="no" checked={false} control={<Radio />} label="No" />

                              </RadioGroup>
                            </FormControl>
                          </div>
                        )

                      })
                    }
                  </div>
                </AccordionDetails>
              </Accordion>
              <Accordion>
                <AccordionSummary
                  expandIcon={<ExpandMoreIcon />}
                  aria-controls="panel2a-content"
                  id="panel2a-header"
                >
                  <Typography className=''>Revenue Streams</Typography>
                </AccordionSummary>
                <AccordionDetails>
                  <div className='rev'>
                    {
                      revenueQuestions.map((val, index) => {
                        return (
                          <div key={index}>
                            <FormControl>
                              <FormLabel id="demo-controlled-radio-buttons-group">
                                {val.question}
                              </FormLabel>
                              <RadioGroup
                                aria-labelledby="demo-controlled-radio-buttons-group"
                                //name="controlled-radio-buttons-group"
                                value={values[index]}
                                onChange={(e) => handleChangeRevenueSegment(val.question, val.field, e, index)}
                              >
                                <FormControlLabel value="yes" checked={false} control={<Radio />} label="Yes" />
                                <FormControlLabel value="no" checked={false} control={<Radio />} label="No" />

                              </RadioGroup>
                            </FormControl>
                          </div>
                        )

                      })
                    }
                  </div>

                </AccordionDetails>
              </Accordion>
              <Accordion>
                <AccordionSummary
                  expandIcon={<ExpandMoreIcon />}
                  aria-controls="panel2a-content"
                  id="panel2a-header"
                >
                  <Typography className=''>Value Proposition</Typography>
                </AccordionSummary>
                <AccordionDetails>
                  <div className='rev'>
                    {
                      valueQuestions.map((val, index) => {
                        return (
                          <div key={index}>
                            <FormControl>
                              <FormLabel id="demo-controlled-radio-buttons-group">
                                {val.question}
                              </FormLabel>
                              <RadioGroup
                                aria-labelledby="demo-controlled-radio-buttons-group"
                                //name="controlled-radio-buttons-group"
                                value={values[index]}
                                onChange={(e) => handleChangeValueSegment(val.question, val.field, e, index)}
                              >
                                <FormControlLabel value="yes" checked={false} control={<Radio />} label="Yes" />
                                <FormControlLabel value="no" checked={false} control={<Radio />} label="No" />

                              </RadioGroup>
                            </FormControl>
                          </div>
                        )

                      })
                    }
                  </div>

                </AccordionDetails>
              </Accordion>
              <Accordion>
                <AccordionSummary
                  expandIcon={<ExpandMoreIcon />}
                  aria-controls="panel2a-content"
                  id="panel2a-header"
                >
                  <Typography className=''>Financial Management</Typography>
                </AccordionSummary>
                <AccordionDetails>
                  <div className='rev'>
                    {
                      financialQuestions.map((val, index) => {
                        return (
                          <div key={index}>
                            <FormControl>
                              <FormLabel id="demo-controlled-radio-buttons-group">
                                {val.question}
                              </FormLabel>
                              <RadioGroup
                                aria-labelledby="demo-controlled-radio-buttons-group"
                                //name="controlled-radio-buttons-group"
                                value={values[index]}
                                onChange={(e) => handleChangeFinancialSegment(val.question, val.field, e, index)}
                              >
                                <FormControlLabel value="yes" checked={false} control={<Radio />} label="Yes" />
                                <FormControlLabel value="no" checked={false} control={<Radio />} label="No" />

                              </RadioGroup>
                            </FormControl>
                          </div>
                        )

                      })
                    }
                  </div>
                </AccordionDetails>
              </Accordion>
              <Accordion>
                <AccordionSummary
                  expandIcon={<ExpandMoreIcon />}
                  aria-controls="panel2a-content"
                  id="panel2a-header"
                >
                  <Typography className=''>Proof of concept</Typography>
                </AccordionSummary>
                <AccordionDetails>
                  <div className='rev'>
                    {
                      proofQuestions.map((val, index) => {
                        return (
                          <div key={index}>
                            <FormControl>
                              <FormLabel id="demo-controlled-radio-buttons-group">
                                {val.question}
                              </FormLabel>
                              <RadioGroup
                                aria-labelledby="demo-controlled-radio-buttons-group"
                                //name="controlled-radio-buttons-group"
                                value={values[index]}
                                onChange={(e) => handleChangeProofSegment(val.question, val.field, e, index)}
                              >
                                <FormControlLabel value="yes" checked={false} control={<Radio />} label="Yes" />
                                <FormControlLabel value="no" checked={false} control={<Radio />} label="No" />

                              </RadioGroup>
                            </FormControl>
                          </div>
                        )

                      })
                    }
                  </div>

                </AccordionDetails>
              </Accordion>
              <Button
                style={{ marginTop: "10px" }}
                variant='outlined'
                className='AssesSave'
                onClick={() => createReport()}

              >
                <Link to='/HealthReport' style={{ minWidth: "100px", color: "white", textDecoration: "none" }}>Save</Link>

              </Button>
            </div>
          </Grid>
        </Grid>
      </Container>
      <div className="footAs">
        <Footernew />
      </div>
    </div >
  )

}
export default Funding