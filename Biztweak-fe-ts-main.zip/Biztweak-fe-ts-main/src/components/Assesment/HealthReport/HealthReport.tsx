import React, { } from 'react';
import { makeStyles, Theme, createStyles } from '@material-ui/core/styles';
import Dialog from '@material-ui/core/Dialog';
import DialogActions from '@material-ui/core/DialogActions';
import DialogContent from '@material-ui/core/DialogContent';
import DialogContentText from '@material-ui/core/DialogContentText';
import { Container, Grid } from '@material-ui/core';
import Typography from '@material-ui/core/Typography';
import Alert from '@material-ui/lab/Alert';
import UserNavbar from '../../UserNav/UserNav';
import Footernew from '../../Footer/Footernew';
import Card from '@material-ui/core/Card';
import CardActions from '@material-ui/core/CardActions';
import CardContent from '@material-ui/core/CardContent';
import Button from '@material-ui/core/Button';
import pop3 from '../../../Images/pop3.png';
import { Link, useLocation , useNavigate } from 'react-router-dom';
import { useSelector } from "react-redux";
import { selectRecomendationState } from "../../../Slice/createSlice";
import './HealthReport.css';
import AccessmentAccordion from '../../AssessmentsAccordion/AccessmentsAccordion';
import { isMobile } from "../../../lib/screenQuery"

var _isMobile = isMobile();

const linkStyle = {
	margin: "1rem",
	textDecoration: "none",
};


function rand() {
	return Math.round(Math.random() * 20) - 10;
}

function getModalStyle() {
	const top = 50 + rand();
	const left = 50 + rand();

	return {
		top: `${top}%`,
		left: `${left}%`,
		transform: `translate(-${top}%, -${left}%)`
	};
}

const useStyles = makeStyles((theme: Theme) =>
	createStyles({
		root: {
			width: '100%',
			'& > * + *': {
				marginTop: theme.spacing(2)
			}
		},
		bullet: {
			display: 'inline-block',
			margin: '0 2px',
			transform: 'scale(0.8)'
		},
		title: {
			fontSize: 14
		},
		pos: {
			marginBottom: 12
		},
		paper: {
			backgroundColor: theme.palette.background.paper,
			border: '2px solid #000',
			boxShadow: theme.shadows[5],
			padding: theme.spacing(2, 4, 3)
		}
	})
);

type LocationState = {
	bizInd: Array<{
	  value: number;
	  label: string
	}>,
	bizPhase: Array<{
	  value: number;
	  label: string
	}>
  }

const HealthReport = () => {
	const location = useLocation();
	const navigate = useNavigate();
console.log("here is the location", location)
	const bizInd = (location.state as LocationState)?.bizInd;
	const bizPhase = (location.state as LocationState)?.bizPhase;
console.log("industry", bizInd)
console.log("Phase", bizPhase)
	const classes = useStyles();
	const [modalStyle] = React.useState(getModalStyle);
	const [open, setOpen] = React.useState(false);
	const handleOpen = () => {
		setOpen(true);
	};

	const handleClose = () => {
		setOpen(false);
	};
	const state = useSelector(selectRecomendationState)
	const recommendation: any = state.persistedReducer.RecomendationReducer.selectedRecomendation;
	const SendState = () => {
		navigate('/Profile',{ state: { bizInd: bizInd, bizPhase: bizPhase } });
	}

	const stateData = []
	stateData.push(state)
	console.log("stateData .", stateData)
	const stateDataview = []
	stateDataview.push(state.persistedReducer)

	return (
		<div className="HR-con">
			<UserNavbar />
			<Container>
				<Grid container spacing={2}>
					<Grid item xs={12} sm={12} md={3} lg={3}>
						{/* onClick={() => setSelectedRecomendation(AllRecomendations[index]) */}
						<h4 className='poptypo' style={{ fontFamily: "Rockwell !important", fontWeight: "400", fontSize: "16pt", margin: "10% 10px" }}>Current Reports</h4>
						<AccessmentAccordion setSelectedRecommedation ={true}/>
					</Grid>

					<Grid item xs={12} sm={12} md={9} lg={9} style={{ marginTop: "8%" }}>
						<Card className={classes.root}>
							<CardContent>
								<div className="cont">
									<div className="HR-Alert">
										<Alert severity="success">SUCCESS! Company Assessment Completed.</Alert>
									</div>
									<div className="HR-Header">
										<Typography variant="h3" className="headers">
											Business Health Report
										</Typography>
										<Typography style={{ marginTop: "10px" }}>
											In this nicely designed report you can check your business factors in
											graphical way and understand easily, moreover you will also get
											recommendations from our system based on the assessment.
										</Typography>
									</div>
								</div>
							</CardContent>
							<CardActions>
								{recommendation.completed !== false?  <Button size="small" variant="outlined" className="bizReport"
								
									style={{
										backgroundColor: "#44969b !important",
										color: "white",
										border: "none",
										padding: "10px 50px",
										marginBottom: "10px"
									}}
									onClick={handleOpen}>
									View Biz Report
								</Button> : <Button size="small" variant="outlined" className="bizReport"
								
								style={{
									backgroundColor: "#44969b !important",
									color: "white",
									border: "none",
									padding: "10px 50px",
									marginBottom: "10px"
								}}
								>
									<Link style={{ color: "white", textDecoration: "none", padding: "2px", cursor: "pointer" }} to={`/${recommendation.assessment}`}>Complete Biz Assesment</Link>
								
							</Button>}
							</CardActions>
						</Card>
					</Grid>
				</Grid>
			</Container>
			<Footernew />
			<div className="popUp">
				<div className='HRPop'>
					<Dialog
						open={open}
						onClose={handleClose}
						aria-labelledby="alert-dialog-title"
						aria-describedby="alert-dialog-description"
					>
						{/* <DialogTitle id="alert-dialog-title">{"Use Google's location service?"}</DialogTitle> */}
						<DialogContent>
							<DialogContentText id="alert-dialog-description">
								<img className="pop3" alt="pop3" src={pop3} />
							</DialogContentText>
							<div className='pop3Txt'>
								<h5 className='poptypo' style={{ fontFamily: "Rockwell !important", fontWeight: _isMobile ? "" : "1000", fontSize: _isMobile ? "" : "30px" }}>
									Complete Company Profile
								</h5>
								<Typography className='pTxTHr' style={{ padding: "5px", maxWidth: "85%" }}>
									Completing your company information will help us know more about your business.
									Lets fill the assessment text: Completing your business assessment will help us
									know what kind of help your business needs.
								</Typography>
							</div>
						</DialogContent>
						<DialogActions>
							
								<Button 
									className="popSave" 
									variant="outlined"
									onClick={() => SendState()}
									>
									OK
								</Button>
							
						</DialogActions>
					</Dialog>
				</div>
			</div>
		</div >
	);
};

export default HealthReport;

//

