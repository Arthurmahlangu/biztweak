import React, { useEffect, useState } from 'react';
import { Container, Grid, Button } from '@material-ui/core';
import Accordion from '@material-ui/core/Accordion';
import AccordionSummary from '@material-ui/core/AccordionSummary';
import AccordionDetails from '@material-ui/core/AccordionDetails';
import Typography from '@material-ui/core/Typography';
import ExpandMoreIcon from '@material-ui/icons/ExpandMore';
import MuiAlert from '@material-ui/lab/Alert';
import UserNavbar from '../UserNav/UserNav';
import company from '../../Images/company.png'
import Radio from "@mui/material/Radio";
import RadioGroup from "@mui/material/RadioGroup";
import FormControlLabel from "@mui/material/FormControlLabel";
import FormControl from "@mui/material/FormControl";
import FormLabel from "@mui/material/FormLabel";
import { useNavigate, useLocation } from 'react-router-dom';
import './Assessment.css'
import { Api } from '../../services/endpoints';
import { IRecomendation } from '../../Interfaces/IRecomendation'
import Footernew from '../Footer/Footernew';
import { supabase } from '../../supabaseClient';
import marketingSales from '../../json/marketingSales.json';
import customerSegment from '../../json/customerSegment.json';
import valuePropositionSegment from '../../json/valueProposition.json';
import keyActivitiesSegment from '../../json/keyActivities.json';
import keyResourcesSegment from '../../json/keyResources.json';
import { useSelector } from 'react-redux';
import { selectRecomendationState } from "../../Slice/createSlice";
import AccessmentAccordion from '../AssessmentsAccordion/AccessmentsAccordion';


type LocationState = {
  bizInd: Array<{
    value: number;
    label: string
  }>,
  bizPhase: Array<{
    value: number;
    label: string
  }>
}

const linkStyle = {
  margin: "1rem",
  textDecoration: "none",

};


const AssessBasic = () => {
  const location = useLocation();
  const navigate = useNavigate();

  const bizInd = (location.state as LocationState)?.bizInd;
  const bizPhase = (location.state as LocationState)?.bizPhase;
  const [value, setValue] = React.useState('');
  const [mkSales, setMkSales] = useState<{ question: string, field: string }[]>(marketingSales);
  const [CustomerSegment, setCustomerSegment] = useState<{ question: string, field: string }[]>(customerSegment);
  const [PropositionSegment, setPropositionSegment] = useState<{ question: string, field: string }[]>(valuePropositionSegment);
  const [KeyActivitiesSegment, setKeyActivitiesSegment] = useState<{ question: string, field: string }[]>(keyActivitiesSegment);
  const [KeyResourcesSegment, setKeyResourcesSegment] = useState<{ question: string, field: string }[]>(keyResourcesSegment);


  const [values, setValues] = useState<any>({});
  const [customerSegmentValues, setCustomerSegmentValues] = useState<any>({});
  const [propositionSegmentValues, setPropositionSegmentValues] = useState<any>({});
  const [keyActivitiesSegmentValues, setKeyActivitiesSegmentValues] = useState<any>({});
  const [keyResourcesSegmentValues, setKeyResourcesSegmentValues] = useState<any>({});



  const user = supabase.auth.user()
  function Alert(props: any) {
    return <MuiAlert elevation={6} variant="filled" {...props} />;
  }


  const createReport = async () => {
    // Customer Segment
    const customerSegment = [
      {
        key: customerSegmentValues.productOwner == "yes" ? "Customer profile has been determined." : "Customer profile not determined",
        value: customerSegmentValues.productOwner == "yes" ? "No recommendation" : "Market Research",
        type: 1,
        question: 1,
        answered: customerSegmentValues.productOwner == "yes" || customerSegmentValues.productOwner == "no" ? true : false
      },
      {
        key: customerSegmentValues.tagetAudiance == "yes" ? "Target audience has been determined." : "Target audience has not been selected",
        value: customerSegmentValues.tagetAudiance == "yes" ? "No recommendation" : "Market Intelligence",
        type: 1,
        question: 2,
        answered: customerSegmentValues.tagetAudiance == "yes" || customerSegmentValues.tagetAudiance == "no" ? true : false
      },
      {
        key: customerSegmentValues.tagetAudianceLocation == "yes" ? "Target audience has been located geographically." : "Target audience has not been located geographically",
        value: customerSegmentValues.tagetAudianceLocation == "yes" ? "No recommendation" : "Market Research",
        type: 1,
        question: 3,
        answered: customerSegmentValues.tagetAudianceLocation == "yes" || customerSegmentValues.tagetAudianceLocation == "no" ? true : false
      },
      {
        key: customerSegmentValues.tagetMarketSize == "yes" ? "Target audience has been segmented." : "Target audience has not been segmented.",
        value: customerSegmentValues.tagetMarketSize == "yes" ? "No recommendation" : "SAM SOM TAM",
        type: 1,
        question: 4,
        answered: customerSegmentValues.tagetMarketSize == "yes" || customerSegmentValues.tagetMarketSize == "no" ? true : false
      },
      {
        key: customerSegmentValues.cusReach == "yes" ? "Total accessible market has been determined." : "Total accessible market has not been determined",
        value: customerSegmentValues.cusReach == "yes" ? "No recommendation" : "Market Strategy",
        type: 1,
        question: 5,
        answered: customerSegmentValues.cusReach == "yes" || customerSegmentValues.cusReach == "no" ? true : false
      },
      {
        key: customerSegmentValues.competitor == "yes" ? "Competitors have been identified" : "competitors have not been identified",
        value: customerSegmentValues.competitor == "yes" ? "No recommendation" : "Competitor Analysis",
        type: 1,
        question: 6,
        answered: customerSegmentValues.competitor == "yes" || customerSegmentValues.competitor == "no" ? true : false
      },
      {
        key: customerSegmentValues.marketAccess == "yes" ? "Total accessible market has been determined." : "Total accessible market has not been determined",
        value: customerSegmentValues.marketAccess == "yes" ? "No recommendation" : "Total Addressable market",
        type: 1,
        question: 7,
        answered: customerSegmentValues.marketAccess == "yes" || customerSegmentValues.marketAccess == "no" ? true : false
      },
      {
        key: customerSegmentValues.marketLocation == "yes" ? "Total observable market has been determined." : "Total observable market has not been determined.",
        value: customerSegmentValues.marketLocation == "yes" ? "No recommendation" : "Market Reasearch",
        type: 1,
        question: 8,
        answered: customerSegmentValues.marketLocation == "yes" || customerSegmentValues.marketLocation == "no" ? true : false
      },
      {
        key: customerSegmentValues.idealCustomer == "yes" ? "Ideal customer profile has been determined." : "Ideal customer profile has not been determined.",
        value: customerSegmentValues.idealCustomer == "yes" ? "No recommendation" : "Ideal Customer profile",
        type: 1,
        question: 9,
        answered: customerSegmentValues.idealCustomer == "yes" || customerSegmentValues.idealCustomer == "no" ? true : false
      },
      {
        key: customerSegmentValues.importantCustomer == "yes" ? "Most important not determined." : "Most important customers not determined",
        value: customerSegmentValues.importantCustomer == "yes" ? "No recommendation" : "Market Research",
        type: 1,
        question: 10,
        answered: customerSegmentValues.importantCustomer == "yes" || customerSegmentValues.importantCustomer == "no" ? true : false
      },
      {
        key: customerSegmentValues.customerReaserch == "yes" ? "Customer research has been done" : "Customer research has not been done",
        value: customerSegmentValues.customerReaserch == "yes" ? "No recommendation" : "Business Research Officer",
        type: 1,
        question: 11,
        answered: customerSegmentValues.customerReaserch == "yes" || customerSegmentValues.customerReaserch == "no" ? true : false
      }
    ]


    // Market and Sales
    const Market = [
      {
        key: values.effectiveAd === "yes" ? "The advertising is effective" : "The advertising is not effective",
        value: values.effectiveAd === "yes" ? "No recommendation" : "Marketing plan, social media marketing",
        type: 2,
        question: 1,
        answered: values.effectiveAd == "yes" || values.effectiveAd == "no" ? true : false
      }, {
        key: values.companyAd === "yes" ? "The company does advertise" : "The company does not advertise",
        value: values.companyAd === "yes" ? "No recommendation" : "monitoring & evaluation",
        type: 2,
        question: 2,
        answered: values.companyAd == "yes" || values.companyAd == "no" ? true : false
      },
      {
        key: values.planning === "yes" ? "Sales Planning is conducted" : "Sales Planning is not conducted",
        value: values.planning === "yes" ? "No recommendation" : "Sales planning, Customer acquistion plan.",
        type: 2,
        question: 3,
        answered: values.planning == "yes" || values.planning == "no" ? true : false
      }, {
        key: values.priceStrategy === "yes" ? "Price strategy planning is done" : "Price strategy planning is not done",
        value: values.priceStrategy === "yes" ? "No recommendation" : "Revenue models",
        type: 2,
        question: 4,
        answered: values.priceStrategy == "yes" || values.priceStrategy == "no" ? true : false
      }, {
        key: values.priceReview === "yes" ? "Prive reviews are done" : "Prive reviews are not done",
        value: values.priceReview === "yes" ? "No recommendation" : "Costing, product & service pricing",
        type: 2,
        question: 5,
        answered: values.priceReview == "yes" || values.priceReview == "no" ? true : false
      }
    ]

    // Key Proposition
    const valuePropositionSegment = [
      {
        key: propositionSegmentValues.problem === "yes" ? "Problem being solved has been determined." : "Problem being solved not determined",
        value: propositionSegmentValues.problem === "yes" ? "No recommendation" : "Value proposition canvas",
        type: 1,
        question: 1,
        answered: propositionSegmentValues.problem == "yes" || propositionSegmentValues.problem == "no" ? true : false
      },
      {
        key: propositionSegmentValues.cusValue === "yes" ? "Value being delivered has been determined." : "Value being delivered not determined.",
        value: propositionSegmentValues.cusValue === "yes" ? "No recommendation" : "Business model canvas",
        type: 1,
        question: 2,
        answered: propositionSegmentValues.cusValue == "yes" || propositionSegmentValues.cusValue == "no" ? true : false
      },
      {
        key: propositionSegmentValues.needsSatisfied === "yes" ? "Customer needs have been determined." : "Customer needs have not been determined.",
        value: propositionSegmentValues.needsSatisfied === "yes" ? "No recommendation" : "Value proposition canvas",
        type: 1,
        question: 3,
        answered: propositionSegmentValues.needsSatisfied == "yes" || propositionSegmentValues.needsSatisfied == "no" ? true : false
      },
      {
        key: propositionSegmentValues.productUniqueness === "yes" ? "uniques selling point has been determined." : "Uniques selling point not determined.",
        value: propositionSegmentValues.productUniqueness === "yes" ? "No recommendation" : "Value proposition canvas",
        type: 1,
        question: 4,
        answered: propositionSegmentValues.productUniqueness == "yes" || propositionSegmentValues.productUniqueness == "no" ? true : false
      },
      {
        key: propositionSegmentValues.elevatorPitch === "yes" ? "An elevator pitch has been prepared." : "elevator pitch template",
        value: propositionSegmentValues.elevatorPitch === "yes" ? "No recommendation" : "No elevator pitch",
        type: 1,
        question: 5,
        answered: propositionSegmentValues.elevatorPitch == "yes" || propositionSegmentValues.elevatorPitch == "no" ? true : false
      }
    ]

    //Key Activities
    const keyActivities = [
      {
        key: keyActivitiesSegmentValues.bizModel === "yes" ? "Key activities in the business have been determined" : "Key activities in the business not determined",
        value: keyActivitiesSegmentValues.bizModel === "yes" ? "No recommendation" : "Process development",
        type: 1,
        question: 1,
        answered: keyActivitiesSegmentValues.bizModel == "yes" || keyActivitiesSegmentValues.bizModel == "no" ? true : false

      }
    ]

    //Key Resources

    const keyResources = [{
      key: keyResourcesSegmentValues.resources === "yes" ? "Key resources needed have been determined." : "Key resources needed have not been determined",
      value: keyResourcesSegmentValues.resources === "yes" ? "No recommendation" : "organizational design and development",
      type: 1,
      question: 1,
      answered: keyResourcesSegmentValues.resources == "yes" || keyResourcesSegmentValues.resources == "no" ? true : false
    }]

    const isUpdate = recommendation.segmentResponses ? true : false;
    if (isUpdate) {
      await supabase
        .from('Recomendations')
        .update({
          segmentResponses: {
            "Customer": customerSegment,
            "Market": Market,
            "Value": valuePropositionSegment,
            "Activities": keyActivities,
            "Resources": keyResources
          }
        })
        .eq('id', recommendation.id);

      await supabase
        .from('Recomendations')
        .update({
          segmentValues:
          {
            "customer": customerSegmentValues,
            "marketSales": values,
            "value": propositionSegmentValues,
            "activities": keyActivitiesSegmentValues,
            "resources": keyResourcesSegmentValues
          }
        })
        .eq('id', recommendation.id);

      navigate('/HealthReport', { state: { bizInd: bizInd, bizPhase: bizPhase } });

    } else {
      const payload = {
        "assessment": "AssesSales",
        "phase": bizPhase[0].label,
        "industry": bizInd[0].label,
        "segment": "customer",
        "userId": user?.id,
        "segmentResponses": {
          "Customer": customerSegment,
          "Market": Market,
          "Value": valuePropositionSegment,
          "Activities": keyActivities,
          "Resources": keyResources
        },
        "segmentValues": {
          "customer": customerSegmentValues,
          "marketSales": values,
          "value": propositionSegmentValues,
          "activities": keyActivitiesSegmentValues,
          "resources": keyResourcesSegmentValues
        }

      } as IRecomendation

      const result = await Api.POST_CreateRecommendation(payload)
      navigate('/HealthReport', { state: { bizInd: bizInd, bizPhase: bizPhase } });
    }

  }

  const handleChangeMarketingAndSales = (question: string, field: string, event: React.ChangeEvent<HTMLInputElement>, index: number) => {
    // console.log(index, question, field)
    const indexOfObject = mkSales.findIndex(object => {
      return object.question === question;
    });
    setValues({ ...values, [field]: (event.target as HTMLInputElement).value });

    mkSales.splice(indexOfObject, 1);
  };

  const handleChangeCustomerSegment = (question: string, field: string, event: React.ChangeEvent<HTMLInputElement>, index: number) => {
    const indexOfObject = CustomerSegment.findIndex(object => {
      return object.question === question;
    });
    setCustomerSegmentValues({ ...customerSegmentValues, [field]: (event.target as HTMLInputElement).value });

    CustomerSegment.splice(indexOfObject, 1);
  };

  const handleChangePropositionSegment = (question: string, field: string, event: React.ChangeEvent<HTMLInputElement>, index: number) => {
    const indexOfObject = PropositionSegment.findIndex(object => {
      return object.question === question;
    });
    setPropositionSegmentValues({ ...propositionSegmentValues, [field]: (event.target as HTMLInputElement).value });

    PropositionSegment.splice(indexOfObject, 1);
  };

  const handleChangeKeyActivitiesSegment = (question: string, field: string, event: React.ChangeEvent<HTMLInputElement>, index: number) => {
    const indexOfObject = KeyActivitiesSegment.findIndex(object => {
      return object.question === question;
    });
    setKeyActivitiesSegmentValues({ ...keyActivitiesSegmentValues, [field]: (event.target as HTMLInputElement).value });

    KeyActivitiesSegment.splice(indexOfObject, 1);
  };

  const handleChangeKeyResourcesSegment = (question: string, field: string, event: React.ChangeEvent<HTMLInputElement>, index: number) => {
    const indexOfObject = KeyResourcesSegment.findIndex(object => {
      return object.question === question;
    });
    setKeyResourcesSegmentValues({ ...keyResourcesSegmentValues, [field]: (event.target as HTMLInputElement).value });

    KeyResourcesSegment.splice(indexOfObject, 1);
  };




  const state = useSelector(selectRecomendationState);
  const recommendation: any = state.persistedReducer.RecomendationReducer.selectedRecomendation;
  console.log(recommendation)
  console.log(customerSegment);


  let customerSegmentQuestions: { question: string, field: string }[] = []

  if (recommendation.segmentResponses) {
    customerSegment.forEach(question => {
      if (recommendation.segmentResponses?.Customer.some((res: any) => res.question == question.number && !res.answered)) {
        customerSegmentQuestions.push(question);
      }
    });
  } else {
    customerSegmentQuestions = [...customerSegment]
  }

  //market and Sale
  let marketSalesQuestions: { question: string, field: string }[] = []

  if (recommendation.segmentResponses) {
    marketingSales.forEach(question => {
      if (recommendation.segmentResponses?.Market.some((res: any) => res.question == question.number && !res.answered)) {
        marketSalesQuestions.push(question);
      }
    });
  } else {
    marketSalesQuestions = [...marketingSales]
  }

  //Value Proposition
  let propositionQuestions: { question: string, field: string }[] = []

  if (recommendation.segmentResponses) {
    valuePropositionSegment.forEach(question => {
      if (recommendation.segmentResponses?.Value.some((res: any) => res.question == question.number && !res.answered)) {
        propositionQuestions.push(question);
      }
    });
  } else {
    propositionQuestions = [...valuePropositionSegment]
  }
  // Key Activities
  let activitiesQuestions: { question: string, field: string }[] = []

  if (recommendation.segmentResponses) {
    keyActivitiesSegment.forEach(question => {
      if (recommendation.segmentResponses?.Activities.some((res: any) => res.question == question.number && !res.answered)) {
        activitiesQuestions.push(question);
      }
    });
  } else {
    activitiesQuestions = [...keyActivitiesSegment]
  }
  // Key Resources
  let resourcesQuestions: { question: string, field: string }[] = []

  if (recommendation.segmentResponses) {
    keyResourcesSegment.forEach(question => {
      if (recommendation.segmentResponses?.Resources.some((res: any) => res.question == question.number && !res.answered)) {
        resourcesQuestions.push(question);
      }
    });
  } else {
    resourcesQuestions = [...keyResourcesSegment]
  }
  useEffect(() => {
    if (recommendation?.segmentValues && recommendation.segmentValues.customer) {
      setCustomerSegmentValues(recommendation.segmentValues.customer);
    }
    if (recommendation?.segmentValues && recommendation.segmentValues.marketSales) {
      setValues(recommendation.segmentValues.marketSales);
    }
    if (recommendation?.segmentValues && recommendation.segmentValues.value) {
      setPropositionSegmentValues(recommendation.segmentValues.value);
    }
    if (recommendation?.segmentValues && recommendation.segmentValues.activities) {
      setKeyActivitiesSegmentValues(recommendation.segmentValues.activities);
    }
    if (recommendation?.segmentValues && recommendation.segmentValues.resources) {
      setKeyResourcesSegmentValues(recommendation.segmentValues.resources);
    }
  }, [])

  console.log(customerSegmentQuestions)





  return (
    <div className='Basic'>
      <UserNavbar />
      <Container>
        <Grid container spacing={2}>
          <Grid item xs={12} sm={12} md={4} lg={4}>
            <Typography>Company</Typography>
            <Button
              className='profAdd'
              variant='outlined'
            >
              Add Company
            </Button>
            <div className='Accords'>
              <div className='sideAccord'>
                <AccessmentAccordion setSelectedRecommedation ={false}/>
              </div>
            </div>
          </Grid>
          <Grid item xs={12} sm={12} md={8} lg={8}>
            <Alert style={{ backgroundColor: "#00d3dd" }} severity="info">Next Step! Complete your Company Assessment.</Alert>
            <Typography className='biz' variant='h5'>Biz Assessment</Typography>
            <div className='companyBox'>
              <img
                src={company}
                alt='comLogo'
                className='company'
              />
              <div className='companyInf'>
                <div className='Location'>
                  <Typography>Location: N/A</Typography>
                </div>
                <div className='indust'>
                  <Typography>Industry: {bizInd ? bizInd[0].label : recommendation.industry}</Typography>
                </div>
                <div className='phase'>
                  <Typography>Business Phase: {bizPhase ? bizPhase[0].label : recommendation.phase}</Typography>
                </div>
              </div>
            </div>
            <div className='bassicAccords'>
              <Accordion>
                <AccordionSummary
                  expandIcon={<ExpandMoreIcon />}
                  aria-controls="panel2a-content"
                  id="panel2a-header"
                >
                  <Typography className=''>Customer segment</Typography>
                </AccordionSummary>
                <AccordionDetails>
                  <div className='rev'>
                    {
                      customerSegmentQuestions.map((val, index) => {
                        return (
                          <div key={index}>
                            <FormControl>
                              <FormLabel id="demo-controlled-radio-buttons-group">
                                {val.question}
                              </FormLabel>
                              <RadioGroup
                                aria-labelledby="demo-controlled-radio-buttons-group"
                                //name="controlled-radio-buttons-group"
                                value={values[index]}
                                onChange={(e) => handleChangeCustomerSegment(val.question, val.field, e, index)}
                              >
                                <FormControlLabel value="yes" checked={false} control={<Radio />} label="Yes" />
                                <FormControlLabel value="no" checked={false} control={<Radio />} label="No" />

                              </RadioGroup>
                            </FormControl>
                          </div>
                        )

                      })
                    }
                  </div>
                </AccordionDetails>
              </Accordion>
              <Accordion>
                <AccordionSummary
                  expandIcon={<ExpandMoreIcon />}
                  aria-controls="panel2a-content"
                  id="panel2a-header"
                >
                  <Typography className=''>Marketing and Sales</Typography>
                </AccordionSummary>
                <AccordionDetails>
                  <div className='rev'>
                    {
                      marketSalesQuestions.map((val, index) => {
                        return (
                          <div key={index}>
                            <FormControl>
                              <FormLabel id="demo-controlled-radio-buttons-group">
                                {val.question}
                              </FormLabel>
                              <RadioGroup
                                aria-labelledby="demo-controlled-radio-buttons-group"
                                //name="controlled-radio-buttons-group"
                                value={values[index]}
                                onChange={(e) => handleChangeMarketingAndSales(val.question, val.field, e, index)}
                              >
                                <FormControlLabel value="yes" checked={false} control={<Radio />} label="Yes" />
                                <FormControlLabel value="no" checked={false} control={<Radio />} label="No" />

                              </RadioGroup>
                            </FormControl>
                          </div>
                        )

                      })
                    }
                  </div>
                </AccordionDetails>
              </Accordion>
              <Accordion>
                <AccordionSummary
                  expandIcon={<ExpandMoreIcon />}
                  aria-controls="panel2a-content"
                  id="panel2a-header"
                >
                  <Typography className=''>Value Proposition</Typography>
                </AccordionSummary>
                <AccordionDetails>
                  <div className='rev'>
                    {
                      propositionQuestions.map((val, index) => {
                        return (
                          <div key={index}>
                            <FormControl>
                              <FormLabel id="demo-controlled-radio-buttons-group">
                                {val.question}
                              </FormLabel>
                              <RadioGroup
                                aria-labelledby="demo-controlled-radio-buttons-group"
                                //name="controlled-radio-buttons-group"
                                value={values[index]}
                                onChange={(e) => handleChangePropositionSegment(val.question, val.field, e, index)}
                              >
                                <FormControlLabel value="yes" checked={false} control={<Radio />} label="Yes" />
                                <FormControlLabel value="no" checked={false} control={<Radio />} label="No" />

                              </RadioGroup>
                            </FormControl>
                          </div>
                        )

                      })
                    }
                  </div>
                </AccordionDetails>
              </Accordion>
              <Accordion>
                <AccordionSummary
                  expandIcon={<ExpandMoreIcon />}
                  aria-controls="panel2a-content"
                  id="panel2a-header"
                >
                  <Typography className=''>Key Activities</Typography>
                </AccordionSummary>
                <AccordionDetails>
                  <div className='rev'>
                    {
                      activitiesQuestions.map((val, index) => {
                        return (
                          <div key={index}>
                            <FormControl>
                              <FormLabel id="demo-controlled-radio-buttons-group">
                                {val.question}
                              </FormLabel>
                              <RadioGroup
                                aria-labelledby="demo-controlled-radio-buttons-group"
                                //name="controlled-radio-buttons-group"
                                value={values[index]}
                                onChange={(e) => handleChangeKeyActivitiesSegment(val.question, val.field, e, index)}
                              >
                                <FormControlLabel value="yes" checked={false} control={<Radio />} label="Yes" />
                                <FormControlLabel value="no" checked={false} control={<Radio />} label="No" />

                              </RadioGroup>
                            </FormControl>
                          </div>
                        )

                      })
                    }
                  </div>
                </AccordionDetails>
              </Accordion>
              <Accordion>
                <AccordionSummary
                  expandIcon={<ExpandMoreIcon />}
                  aria-controls="panel2a-content"
                  id="panel2a-header"
                >
                  <Typography className=''>Key Resources</Typography>
                </AccordionSummary>
                <AccordionDetails>
                  <div className='rev'>
                    {
                      resourcesQuestions.map((val, index) => {
                        return (
                          <div key={index}>
                            <FormControl>
                              <FormLabel id="demo-controlled-radio-buttons-group">
                                {val.question}
                              </FormLabel>
                              <RadioGroup
                                aria-labelledby="demo-controlled-radio-buttons-group"
                                //name="controlled-radio-buttons-group"
                                value={values[index]}
                                onChange={(e) => handleChangeKeyResourcesSegment(val.question, val.field, e, index)}
                              >
                                <FormControlLabel value="yes" checked={false} control={<Radio />} label="Yes" />
                                <FormControlLabel value="no" checked={false} control={<Radio />} label="No" />

                              </RadioGroup>
                            </FormControl>
                          </div>
                        )

                      })
                    }
                  </div>
                </AccordionDetails>
              </Accordion>
            </div>

            <div className='AssesButtonsA'>
              <Button
                variant='outlined'
                className='AssesBack'
              >
                Back
              </Button>
              <Button
                variant='outlined'
                className='AssesSave'
                onClick={() => createReport()}

              >
                Save

              </Button>
            </div>
          </Grid>
        </Grid>
      </Container>
      <div className='footD'>
        <Footernew />
      </div>
    </div>
  )
}

export default AssessBasic;
