import React, { useState } from 'react';
import { Container, Grid, Button } from '@material-ui/core';
import Accordion from '@material-ui/core/Accordion';
import AccordionSummary from '@material-ui/core/AccordionSummary';
import AccordionDetails from '@material-ui/core/AccordionDetails';
import Typography from '@material-ui/core/Typography';
import ExpandMoreIcon from '@material-ui/icons/ExpandMore';
import MuiAlert from '@material-ui/lab/Alert';
import UserNavbar from '../../UserNav/UserNav';
import company from '../../../Images/company.png'
import Radio from "@mui/material/Radio";
import RadioGroup from "@mui/material/RadioGroup";
import FormControlLabel from "@mui/material/FormControlLabel";
import FormControl from "@mui/material/FormControl";
import FormLabel from "@mui/material/FormLabel";
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { createSlice } from '@reduxjs/toolkit';
import { Api } from '../../../services/endpoints';
import { IInvestment } from '../../../Interfaces/IRecomendation'
import Footernew from '../../Footer/Footernew';
import { supabase } from '../../../supabaseClient';
import customerSegment from '../../../json/customerSegment.json';
import businessCustomersSeg from '../../../json/businessCustomers.json';
import marketingSales from '../../../json/marketingSales.json';
import owner from '../../../json/ownershipMindset.json'
import customerRelations from '../../../json/customerRelations.json'
import channels from "../../../json/channels.json";
import functionalCapability from "../../../json/functionalCapability.json";
import revenue from "../../../json/revenueStreams.json";
import valuePropositionSegment from '../../../json/valueProposition.json';
import current from '../../../json/currentAlternatives.json'
import partners from '../../../json/keyPartners.json'
import conAgreement from '../../../json/legalComContract.json'
import traction from '../../../json/traction.json'
import financial from "../../../json/financialManagement.json"
import costStructureSeg from "../../../json/costStructure.json"
import unique from '../../../json/uniqueSellintPoint.json'
import growth from '../../../json/growthStrategy.json'
import businessProcess from '../../../json/businessProcessManagement.json'
import employee from '../../../json/EmployeeSatisfaction.json'
import keyResourcesSegment from '../../../json/keyResources.json';
import compliance from '../../../json/complianceCertification.json'
import legal from '../../../json/legal.json'
import { useSelector } from 'react-redux';
import { selectRecomendationState } from "../../../Slice/createSlice";
import AccessmentAccordion from '../../AssessmentsAccordion/AccessmentsAccordion';
import '../Assessment.css'

type LocationState = {
  bizInd: Array<{
    value: number;
    label: string
  }>,
  bizPhase: Array<{
    value: number;
    label: string
  }>
}




const Investment = () => {
  const location = useLocation();
  const bizInd = (location.state as LocationState)?.bizInd;
  const bizPhase = (location.state as LocationState)?.bizPhase;
  const navigate = useNavigate();
  // const [value, setValue] = React.useState('');
  const [CustomerRelations, setCustomerRelations] = useState<{ question: string, field: string }[]>(customerRelations);
  const [Channel, setChannel] = useState<{ question: string, field: string }[]>(channels);
  const [FunctionalSegment, setFunctionalSegment] = useState<{ question: string, field: string }[]>(functionalCapability);
  const [BusinessCustomer, setBusinessCustomer] = useState<{ question: string, field: string }[]>(businessCustomersSeg);
  const [mkSales, setMkSales] = useState<{ question: string, field: string }[]>(marketingSales);
  const [OwnerSeg, setOwnerSeg] = useState<{ question: string, field: string }[]>(owner);
  const [RevenueStream, setRevenueStream] = useState<{ question: string, field: string }[]>(revenue);
  const [CustomerSegment, setCustomerSegment] = useState<{ question: string, field: string }[]>(customerSegment);
  const [PropositionSegment, setPropositionSegment] = useState<{ question: string, field: string }[]>(valuePropositionSegment);
  const [CurrentAlternativeSegment, setCurrentAlternativeSegment] = useState<{ question: string, field: string }[]>(current);
  const [KeyPartnersSegment, setKeyPartnersSegment] = useState<{ question: string, field: string }[]>(partners);
  const [ContractAgreementSegment, setContractAgreementSegment] = useState<{ question: string, field: string }[]>(conAgreement);
  const [TractionSegment, setTractionSegment] = useState<{ question: string, field: string }[]>(traction);
  const [FinancialManagement, setFinancialManagement] = useState<{ question: string, field: string }[]>(financial);
  const [CostStructure, setCostStructure] = useState<{ question: string, field: string }[]>(costStructureSeg);
  const [UniqueSelling, setUniqueSelling] = useState<{ question: string, field: string }[]>(unique);
  const [GrowthStrat, setGrowthStrat] = useState<{ question: string, field: string }[]>(growth);
  const [BusinessProcess, setBusinessProcess] = useState<{ question: string, field: string }[]>(businessProcess);
  const [EmployeeSat, setEmployeeSat] = useState<{ question: string, field: string }[]>(employee);
  const [KeyResourcesSegment, setKeyResourcesSegment] = useState<{ question: string, field: string }[]>(keyResourcesSegment);
  const [ComplianceSegment, setComplianceSegment] = useState<{ question: string, field: string }[]>(compliance);
  const [LegalSegment, setLegalSegment] = useState<{ question: string, field: string }[]>(legal);


  const [values, setValues] = useState<any>([]);
  const [customerRelationsValue, setCustomerReltionsValues] = useState<any>([]);
  const [channelValues, setChannelValues] = useState<any>([]);
  const [functionalSegmentValues, setFunctionalSegmentValues] = useState<any>([]);
  const [OwnerSegValues, setOwnerSegValues] = useState<any>([]);
  const [businessCustomerValues, setBusinessCustomerValues] = useState<any>([]);
  const [customerSegmentValues, setCustomerSegmentValues] = useState<any>([]);
  const [revenueStreamValues, setRevenueStreamValues] = useState<any>([]);
  const [propositionSegmentValues, setPropositionSegmentValues] = useState<any>([]);
  const [currentAlternativeSegmentValues, setcurrentAlternativeSegmentValues] = useState<any>([]);
  const [keyPartnersSegmentValues, setKeyPartnersSegmentValues] = useState<any>([]);
  const [contractAgreementSegmentValues, setContractAgreementSegmentValues] = useState<any>([]);
  const [tractionSegmentValues, setTractionSegmentValues] = useState<any>([]);
  const [financialManagementValues, setFinancialManagementValues] = useState<any>([]);
  const [costStructureValues, setCostStructureValues] = useState<any>([]);
  const [uniqueSellingValues, setUniqueSellingValues] = useState<any>([]);
  const [growthStratValues, setGrowthStratValues] = useState<any>([]);
  const [businessProcessValues, setBusinessProcessValues] = useState<any>([]);
  const [employeeStatValues, setEmployeeStatValues] = useState<any>([]);
  const [keyResourcesSegmentValues, setKeyResourcesSegmentValues] = useState<any>([]);
  const [complianceValues, setComplianceValues] = useState<any>([]);
  const [legalValues, setLegalValues] = useState<any>([]);




  const user = supabase.auth.user()
  function Alert(props: any) {
    return <MuiAlert elevation={6} variant="filled" {...props} />;
  }
  const createReport = async () => {
    //Channels
    const channels = [
      {
        key: channelValues.reachCustomer == "yes" ? "Customer profile has been determined." : "Customer profile not determined",
        value: channelValues.reachCustomer == "yes" ? "No Recommendation" : "Social media marketing, marketing plan, marketing startegy, sales funnel, customer acquisition plan.",
        type: 1,
        question: 1,
        answered: channelValues.reachCustomer == "yes" || channelValues.reachCustomer == "no" ? true : false
      },
      {
        key: channelValues.marketingPlan == "yes" ? "Strategies to reach customers has been determined." : "Strategies to reach customers has not been determined.",
        value: channelValues.marketingPlan == "yes" ? "No Recommendation" : "Marketing Plan.",
        type: 1,
        question: 2,
        answered: channelValues.marketingPlan == "yes" || channelValues.marketingPlan == "no" ? true : false
      },
      {
        key: channelValues.developedNetwork == "yes" ? "Network to reach target audience has been determined." : "Network to reach target audience has been determined.",
        value: channelValues.developedNetwork == "yes" ? "No Recommendation" : "Sales Funnel",
        type: 1,
        question: 3,
        answered: channelValues.developedNetwork == "yes" || channelValues.developedNetwork == "no" ? true : false
      },
      {
        key: channelValues.customerSupport == "yes" ? "Post sales support has been provided." : "Post sales support is not provided.",
        value: channelValues.customerSupport == "yes" ? "No Recommendation" : "Sales personnel.",
        type: 1,
        question: 4,
        answered: channelValues.customerSupport == "yes" || channelValues.customerSupport == "no" ? true : false
      }
    ]

    //Functional Capability
    const functionalSegment = [
      {
        key: functionalSegmentValues.sufficientAdministration == "yes" ? "There is an administration system that's in use in the company." : "No administration systems in place.",
        value: functionalSegmentValues.sufficientAdministration == "yes" ? "No recommendation" : "Process development & documentation",
        type: 2,
        question: 1,
        answered: functionalSegmentValues.sufficientAdministration == "yes" || functionalSegmentValues.sufficientAdministration == "no" ? true : false
      },
      {
        key: functionalSegmentValues.companyOrg == "yes" ? "Organizational structure is sufficient to deliver on product/service" : "Organizational structure not sufficient.",
        value: functionalSegmentValues.companyOrg == "yes" ? "No recommendation" : "Process development & documentation",
        type: 2,
        question: 2,
        answered: functionalSegmentValues.companyOrg == "yes" || functionalSegmentValues.companyOrg == "no" ? true : false
      }
    ]
    //Business Customer
    const businessCustomers = [
      {
        key: businessCustomerValues.businessPlan === "yes" ? "There is a business plan that has been drafted." : "No defined business plan.",
        value: businessCustomerValues.businessPlan === "yes" ? "No recommendation" : "Business Plan",
        type: 2,
        question: 1,
        answered: businessCustomerValues.businessPlan == "yes" || businessCustomerValues.businessPlan == "no" ? true : false
      },
      {
        key: businessCustomerValues.executePlan === "yes" ? "The company is currently executing the business plan." : "No defined business plan.",
        value: businessCustomerValues.executePlan === "yes" ? "No recommendation" : "Business Plan",
        type: 2,
        question: 2,
        answered: businessCustomerValues.executePlan == "yes" || businessCustomerValues.executePlan == "no" ? true : false
      },
      {
        key: businessCustomerValues.clientSatisfaction === "yes" ? "Client satisfaction measured by the company" : "Client satisfaction not measured.",
        value: businessCustomerValues.clientSatisfaction === "yes" ? "No recommendation" : "CRM",
        type: 2,
        question: 3,
        answered: businessCustomerValues.clientSatisfaction == "yes" || businessCustomerValues.clientSatisfaction == "no" ? true : false
      },
      {
        key: businessCustomerValues.clientEngagement === "yes" ? "Customer engagement is measured" : "Effectiveness of customer engagement not measured.",
        value: businessCustomerValues.clientEngagement === "yes" ? "No recommendation" : "CRM, Monitoring and Evaluation",
        type: 2,
        question: 4,
        answered: businessCustomerValues.clientEngagement == "yes" || businessCustomerValues.clientEngagement == "no" ? true : false
      }
    ]
    // Customer Segment
    const customerSegment = [
      {
        key: customerSegmentValues.productOwner == "yes" ? "Customer profile has been determined." : "Customer profile not determined",
        value: customerSegmentValues.productOwner == "yes" ? "No recommendation" : "Market Research",
        type: 1,
        question: 1,
        answered: customerSegmentValues.productOwner == "yes" || customerSegmentValues.productOwner == "no" ? true : false
      },
      {
        key: customerSegmentValues.tagetAudiance == "yes" ? "Target audience has been determined." : "Target audience has not been selected",
        value: customerSegmentValues.tagetAudiance == "yes" ? "No recommendation" : "Market Intelligence",
        type: 1,
        question: 2,
        answered: customerSegmentValues.tagetAudiance == "yes" || customerSegmentValues.tagetAudiance == "no" ? true : false
      },
      {
        key: customerSegmentValues.tagetAudianceLocation == "yes" ? "Target audience has been located geographically." : "Target audience has not been located geographically",
        value: customerSegmentValues.tagetAudianceLocation == "yes" ? "No recommendation" : "Market Research",
        type: 1,
        question: 3,
        answered: customerSegmentValues.tagetAudianceLocation == "yes" || customerSegmentValues.tagetAudianceLocation == "no" ? true : false
      },
      {
        key: customerSegmentValues.tagetMarketSize == "yes" ? "Target audience has been segmented." : "Target audience has not been segmented.",
        value: customerSegmentValues.tagetMarketSize == "yes" ? "No recommendation" : "SAM SOM TAM",
        type: 1,
        question: 4,
        answered: customerSegmentValues.tagetMarketSize == "yes" || customerSegmentValues.tagetMarketSize == "no" ? true : false
      },
      {
        key: customerSegmentValues.cusReach == "yes" ? "Total accessible market has been determined." : "Total accessible market has not been determined",
        value: customerSegmentValues.cusReach == "yes" ? "No recommendation" : "Market Strategy",
        type: 1,
        question: 5,
        answered: customerSegmentValues.cusReach == "yes" || customerSegmentValues.cusReach == "no" ? true : false
      },
      {
        key: customerSegmentValues.competitor == "yes" ? "Competitors have been identified" : "competitors have not been identified",
        value: customerSegmentValues.competitor == "yes" ? "No recommendation" : "Competitor Analysis",
        type: 1,
        question: 6,
        answered: customerSegmentValues.competitor == "yes" || customerSegmentValues.competitor == "no" ? true : false
      },
      {
        key: customerSegmentValues.marketAccess == "yes" ? "Total accessible market has been determined." : "Total accessible market has not been determined",
        value: customerSegmentValues.marketAccess == "yes" ? "No recommendation" : "Total Addressable market",
        type: 1,
        question: 7,
        answered: customerSegmentValues.marketAccess == "yes" || customerSegmentValues.marketAccess == "no" ? true : false
      },
      {
        key: customerSegmentValues.marketLocation == "yes" ? "Total observable market has been determined." : "Total observable market has not been determined.",
        value: customerSegmentValues.marketLocation == "yes" ? "No recommendation" : "Market Reasearch",
        type: 1,
        question: 8,
        answered: customerSegmentValues.marketLocation == "yes" || customerSegmentValues.marketLocation == "no" ? true : false
      },
      {
        key: customerSegmentValues.idealCustomer == "yes" ? "Ideal customer profile has been determined." : "Ideal customer profile has not been determined.",
        value: customerSegmentValues.idealCustomer == "yes" ? "No recommendation" : "Ideal Customer profile",
        type: 1,
        question: 9,
        answered: customerSegmentValues.idealCustomer == "yes" || customerSegmentValues.idealCustomer == "no" ? true : false
      },
      {
        key: customerSegmentValues.importantCustomer == "yes" ? "Most important not determined." : "Most important customers not determined",
        value: customerSegmentValues.importantCustomer == "yes" ? "No recommendation" : "Market Research",
        type: 1,
        question: 10,
        answered: customerSegmentValues.importantCustomer == "yes" || customerSegmentValues.importantCustomer == "no" ? true : false
      },
      {
        key: customerSegmentValues.customerReaserch == "yes" ? "Customer research has been done" : "Customer research has not been done",
        value: customerSegmentValues.customerReaserch == "yes" ? "No recommendation" : "Business Research Officer",
        type: 1,
        question: 11,
        answered: customerSegmentValues.customerReaserch == "yes" || customerSegmentValues.customerReaserch == "no" ? true : false
      }
    ]
    //Revenue Streams
    const revenue = [
      {
        key: revenueStreamValues.generatingRevenue == "yes" ? "Has Knowledge of how revenue is generated." : "Does not have Knowledge of how revenue is generated.",
        value: revenueStreamValues.generatingRevenue == "yes" ? "No Recommendation" : "Revenue models",
        type: 1,
        question: 1,
        answered: revenueStreamValues.generatingRevenue == "yes" || revenueStreamValues.generatingRevenue == "no" ? true : false
      },
      {
        key: revenueStreamValues.willingPay == "yes" ? "Value customers are willing to pay for has been determined." : "Value customers are willing to pay fpr not determined.",
        value: revenueStreamValues.willingPay == "yes" ? "No Recommendation" : "Proof of concept",
        type: 1,
        question: 2,
        answered: revenueStreamValues.willingPay == "yes" || revenueStreamValues.willingPay == "no" ? true : false
      },
      {
        key: revenueStreamValues.cusPaymentMethod == "yes" ? "Current payment trends of customers are known." : "Current payment trends of customers are not known.",
        value: revenueStreamValues.cusPaymentMethod == "yes" ? "No Recommendation" : "Competitor analysis",
        type: 1,
        question: 3,
        answered: revenueStreamValues.cusPaymentMethod == "yes" || revenueStreamValues.cusPaymentMethod == "no" ? true : false
      },
      {
        key: revenueStreamValues.preferedPayment == "yes" ? "Preferred paymet method of customers has been determined." : "Preferred paymet method of customers not determined.",
        value: revenueStreamValues.preferedPayment == "yes" ? "No Recommendation" : "Market research, competitor analysis",
        type: 1,
        question: 4,
        answered: revenueStreamValues.preferedPayment == "yes" || revenueStreamValues.preferedPayment == "no" ? true : false
      }
    ]
    //Ownership and mindset
    const owner = [
      {
        key: OwnerSegValues.ownerExperience == "yes" ? "Owners have the required experience." : "Owners don't have required experience.",
        value: OwnerSegValues.ownerExperience == "yes" ? "No Recommendation" : "Founder skills and expertise",
        type: 2,
        question: 1,
        answered: OwnerSegValues.ownerExperience == "yes" || OwnerSegValues.ownerExperience == "no" ? true : false
      },
      {
        key: OwnerSegValues.ownerTime == "yes" ? "Owners work fulltime in the business." : "Owners work part-time in the business.",
        value: OwnerSegValues.ownerTime == "yes" ? "No Recommendation" : "Owner & management commitment",
        type: 2,
        question: 2,
        answered: OwnerSegValues.ownerTime == "yes" || OwnerSegValues.ownerTime == "no" ? true : false
      },
      {
        key: OwnerSegValues.ownerQualification == "yes" ? "Expertise are enough to deliver on the product/service." : "Not enough expertise to deliver on products/service.",
        value: OwnerSegValues.ownerQualification == "yes" ? "No Recommendation" : "Founder skills and expertise",
        type: 2,
        question: 3,
        answered: OwnerSegValues.ownerQualification == "yes" || OwnerSegValues.ownerQualification == "no" ? true : false
      }
    ]
    // Key Proposition
    const valuePropositionSegment = [
      {
        key: propositionSegmentValues.problem === "yes" ? "Problem being solved has been determined." : "Problem being solved not determined",
        value: propositionSegmentValues.problem === "yes" ? "No recommendation" : "Value proposition canvas",
        type: 1,
        question: 1,
        answered: propositionSegmentValues.problem == "yes" || propositionSegmentValues.problem == "no" ? true : false
      },
      {
        key: propositionSegmentValues.cusValue === "yes" ? "Value being delivered has been determined." : "Value being delivered not determined.",
        value: propositionSegmentValues.cusValue === "yes" ? "No recommendation" : "Business model canvas",
        type: 1,
        question: 2,
        answered: propositionSegmentValues.cusValue == "yes" || propositionSegmentValues.cusValue == "no" ? true : false
      },
      {
        key: propositionSegmentValues.needsSatisfied === "yes" ? "Customer needs have been determined." : "Customer needs have not been determined.",
        value: propositionSegmentValues.needsSatisfied === "yes" ? "No recommendation" : "Value proposition canvas",
        type: 1,
        question: 3,
        answered: propositionSegmentValues.needsSatisfied == "yes" || propositionSegmentValues.needsSatisfied == "no" ? true : false
      },
      {
        key: propositionSegmentValues.productUniqueness === "yes" ? "uniques selling point has been determined." : "Uniques selling point not determined.",
        value: propositionSegmentValues.productUniqueness === "yes" ? "No recommendation" : "Value proposition canvas",
        type: 1,
        question: 4,
        answered: propositionSegmentValues.productUniqueness == "yes" || propositionSegmentValues.productUniqueness == "no" ? true : false
      },
      {
        key: propositionSegmentValues.elevatorPitch === "yes" ? "An elevator pitch has been prepared." : "elevator pitch template",
        value: propositionSegmentValues.elevatorPitch === "yes" ? "No recommendation" : "No elevator pitch",
        type: 1,
        question: 5,
        answered: propositionSegmentValues.elevatorPitch == "yes" || propositionSegmentValues.elevatorPitch == "no" ? true : false
      }
    ]

    //Current Activities
    const currentAlternatives = [

      {
        key: currentAlternativeSegmentValues.addressedHow === "yes" ? "The business is aware of current solutions from competitors." : "The business is not aware of current solutions",
        value: currentAlternativeSegmentValues.addressedHow === "yes" ? "No recommendation" : "Competitor analysis",
        type: 1,
        question: 1,
        answered: currentAlternativeSegmentValues.addressedHow == "yes" || currentAlternativeSegmentValues.addressedHow == "no" ? true : false
      },
      {
        key: currentAlternativeSegmentValues.currentCompetition === "yes" ? "The business is aware of its competitors" : "The business is not aware of its competitors",
        value: currentAlternativeSegmentValues.currentCompetition === "yes" ? "No recommendation" : "Competitor analysis",
        type: 1,
        question: 2,
        answered: currentAlternativeSegmentValues.currentCompetition == "yes" || currentAlternativeSegmentValues.currentCompetition == "no" ? true : false
      },
    ]

    // key partners
    const keyPartners = [

      {
        key: keyPartnersSegmentValues.strategicPartnership === "yes" ? "Strategic partners have been determined." : "Strategic partners have not been determined.",
        value: keyPartnersSegmentValues.strategicPartnership === "yes" ? "No recommendation" : "Boot Strapping Stratgey",
        type: 1,
        question: 1,
        answered: keyPartnersSegmentValues.strategicPartnership == "yes" || keyPartnersSegmentValues.strategicPartnership == "no" ? true : false
      },
      {
        key: keyPartnersSegmentValues.partnerAssist === "yes" ? "The value of strategic partnerships has been determined" : "Value of strategic partnerships not determined",
        value: keyPartnersSegmentValues.partnerAssist === "yes" ? "No recommendation" : "Boot Strapping Stratgey",
        type: 1,
        question: 2,
        answered: keyPartnersSegmentValues.partnerAssist == "yes" || keyPartnersSegmentValues.partnerAssist == "no" ? true : false
      },
      {
        key: keyPartnersSegmentValues.partnerDevelopment === "yes" ? "Has a person appointed for partner development" : "does not have a person appointed for partner development",
        value: keyPartnersSegmentValues.partnerDevelopment === "yes" ? "No recommendation" : "Job Opportunity : Business Developer",
        type: 1,
        question: 3,
        answered: keyPartnersSegmentValues.partnerDevelopment == "yes" || keyPartnersSegmentValues.partnerDevelopment == "no" ? true : false
      },
    ]
    // contract Agreement
    const contractAgreement = [

      {
        key: contractAgreementSegmentValues.nda === "yes" ? "NDA is available." : "No draft NDA",
        value: contractAgreementSegmentValues.nda === "yes" ? "No recommendation" : "Corporate Law",
        type: 2,
        question: 1,
        answered: contractAgreementSegmentValues.nda == "yes" || contractAgreementSegmentValues.nda == "no" ? true : false
      },
      {
        key: contractAgreementSegmentValues.servicesAgreement === "yes" ? "Contract on general terms and conditions is available" : "No General terms and conditions contract",
        value: contractAgreementSegmentValues.servicesAgreement === "yes" ? "No recommendation" : "Corporate Law",
        type: 2,
        question: 2,
        answered: contractAgreementSegmentValues.servicesAgreement == "yes" || contractAgreementSegmentValues.servicesAgreement == "no" ? true : false
      },
      {
        key: contractAgreementSegmentValues.subContractor === "yes" ? "Sub-contractor contract template is available" : "No sub-contractor contract template",
        value: contractAgreementSegmentValues.subContractor === "yes" ? "No recommendation" : "Corporate Law",
        type: 2,
        question: 3,
        answered: contractAgreementSegmentValues.subContractor == "yes" || contractAgreementSegmentValues.subContractor == "no" ? true : false
      },
      {
        key: contractAgreementSegmentValues.jointVenture === "yes" ? "Teaming agreement contract template is available" : "No teaming agreement contract template",
        value: contractAgreementSegmentValues.jointVenture === "yes" ? "No recommendation" : "Corporate Law",
        type: 2,
        question: 4,
        answered: contractAgreementSegmentValues.jointVenture == "yes" || contractAgreementSegmentValues.jointVenture == "no" ? true : false
      },
    ]
    //Traction
    const tractionSeg = [
      {
        key: tractionSegmentValues.payingCustomers == "yes" ? "has paying customers." : "does not have paying customer",
        value: tractionSegmentValues.payingCustomers == "yes" ? "No recommendation" : "Sales Funnel",
        type: 1,
        question: 1,
        answered: tractionSegmentValues.payingCustomers == "yes" || tractionSegmentValues.payingCustomers == "no" ? true : false
      },
      {
        key: tractionSegmentValues.letterOfIntent == "yes" ? "Has letters of intent." : "Does not have a letter of intent",
        value: tractionSegmentValues.letterOfIntent == "yes" ? "No recommendation" : " ",
        type: 1,
        question: 2,
        answered: tractionSegmentValues.letterOfIntent == "yes" || tractionSegmentValues.letterOfIntent == "no" ? true : false
      },
      {
        key: tractionSegmentValues.memoOfUnderstanding == "yes" ? "Does have memorandum of understanding." : "Does not have memorandum of understanding",
        value: tractionSegmentValues.memoOfUnderstanding == "yes" ? "No recommendation" : " ",
        type: 1,
        question: 4,
        answered: tractionSegmentValues.memoOfUnderstanding == "yes" || tractionSegmentValues.memoOfUnderstanding == "no" ? true : false
      }
    ]
    //Financial Management

    const financialSegment = [
      {
        key: financialManagementValues.budgetForecast === "yes" ? "Proper Budget forecasting in place." : "No Proper Budget forecasting in place.",
        value: financialManagementValues.budgetForecast === "yes" ? "No recommendation" : "Budget Forecasting",
        type: 2,
        question: 1,
        answered: financialManagementValues.budgetForecast == "yes" || financialManagementValues.budgetForecast == "no" ? true : false
      },
      {
        key: financialManagementValues.reconsiliation === "yes" ? "Company Performs Reconsilistions." : "Company does not perfom Reconciliation.",
        value: financialManagementValues.reconsiliation === "yes" ? "No recommendation" : "Reconsiliation",
        type: 2,
        question: 2,
        answered: financialManagementValues.reconsiliation == "yes" || financialManagementValues.reconsiliation == "no" ? true : false
      },
      {
        key: financialManagementValues.cashFlow === "yes" ? "Has proper cash flow management." : "Does not have proper cash flow management.",
        value: financialManagementValues.cashFlow === "yes" ? "No recommendation" : "Cash Flow Management",
        type: 2,
        question: 3,
        answered: financialManagementValues.cashFlow == "yes" || financialManagementValues.cashFlow == "no" ? true : false
      },
      {
        key: financialManagementValues.documentFinancials === "yes" ? "Financials are documented." : "There are no Documented Financials.",
        value: financialManagementValues.documentFinancials === "yes" ? "No recommendation" : "Documenting Financials",
        type: 2,
        question: 4,
        answered: financialManagementValues.documentFinancials == "yes" || financialManagementValues.documentFinancials == "no" ? true : false
      },
      {
        key: financialManagementValues.FinancialManager === "yes" ? "Has a financial Manager." : "Does Not have a financial Manager.",
        value: financialManagementValues.FinancialManager === "yes" ? "No recommendation" : "Job Opportunity : BookKeeper",
        type: 2,
        question: 5,
        answered: financialManagementValues.FinancialManager == "yes" || financialManagementValues.FinancialManager == "no" ? true : false
      }
    ]
    //Cost Structure
    const costSegment = [
      {
        key: costStructureValues.deliveryCost == "yes" ? "Cost of sales has been determined." : "Cost of sales not determined.",
        value: costStructureValues.deliveryCost == "yes" ? "No Recommendation" : "Costing, product & service pricing",
        type: 1,
        question: 1,
        answered: costStructureValues.deliveryCost == "yes" || costStructureValues.deliveryCost == "no" ? true : false
      },
      {
        key: costStructureValues.acquiringCost == "yes" ? "Cos of sales has been determined." : "Cost of sales not determined.",
        value: costStructureValues.acquiringCost == "yes" ? "No Recommendation" : "Costing, product & service pricing",
        type: 1,
        question: 2,
        answered: costStructureValues.acquiringCost == "yes" || costStructureValues.acquiringCost == "no" ? true : false
      },
      {
        key: costStructureValues.customerRelationship == "yes" ? "Cost of customer retention  determined." : "Cost of customer retention not determined.",
        value: costStructureValues.customerRelationship == "yes" ? "No Recommendation" : "Costing, product & service pricing",
        type: 1,
        question: 3,
        answered: costStructureValues.customerRelationship == "yes" || costStructureValues.customerRelationship == "no" ? true : false
      },
      {
        key: costStructureValues.marketSegments == "yes" ? "cost of market penetration has been determined." : "Cost of market penetration not determined.",
        value: costStructureValues.marketSegments == "yes" ? "No Recommendation" : "Costing, product & service pricing",
        type: 1,
        question: 4,
        answered: costStructureValues.marketSegments == "yes" || costStructureValues.marketSegments == "no" ? true : false
      }
    ]
    //Unique Selling Points
    const uniqueSell = [
      {
        key: uniqueSellingValues.specialAttribute == "yes" ? "Unique selleing point has been determined." : "Uniques Selling Point has not been determined.",
        value: uniqueSellingValues.specialAttribute == "yes" ? "No recommendation" : "Disruptive technology, disruptive business model,new market &GTM strategy",
        type: 1,
        question: 1,
        answered: uniqueSellingValues.specialAttribute == "yes" || uniqueSellingValues.specialAttribute == "no" ? true : false
      },

    ]
    //Growth
    const growth = [
      {
        key: growthStratValues.growthArea == "yes" ? "Unique selleing point has been determined." : "Uniques Selling Point has not been determined.",
        value: growthStratValues.growthArea == "yes" ? "No recommendation" : "Scale Strategy",
        type: 2,
        question: 1,
        answered: growthStratValues.growthArea == "yes" || growthStratValues.growthArea == "no" ? true : false
      },
      {
        key: growthStratValues.suffecientInvestment == "yes" ? "Unique selleing point has been determined." : "Uniques Selling Point has not been determined.",
        value: growthStratValues.suffecientInvestment == "yes" ? "No recommendation" : "Scale Strategy",
        type: 2,
        question: 2,
        answered: growthStratValues.suffecientInvestment == "yes" || growthStratValues.suffecientInvestment == "no" ? true : false
      },
    ]
    //BusinessProcess
    const businessProsessSeg = [
      {
        key: businessProcessValues.documentProcess === "yes" ? "Business processes are documented" : "Business processes are not documented",
        value: businessProcessValues.documentProcess === "yes" ? "No recommendation" : "Process development & documentation",
        type: 2,
        question: 1,
        answered: businessProcessValues.documentProcess == "yes" || businessProcessValues.documentProcess == "no" ? true : false
      }, {
        key: businessProcessValues.processUpdate === "yes" ? "Business processes are reviewed" : "Business processes not reviewed regularly or updated.",
        value: businessProcessValues.processUpdate === "yes" ? "No recommendation" : "Process development & documentation, process auditing and review",
        type: 2,
        question: 2,
        answered: businessProcessValues.processUpdate == "yes" || businessProcessValues.processUpdate == "no" ? true : false
      },
      {
        key: businessProcessValues.manageDeviations === "yes" ? "Method to identify deviations in processes has been established." : "No method to manage deviations in business processes.",
        value: businessProcessValues.manageDeviations === "yes" ? "No recommendation" : "Non-conformance & corrective actions management.",
        type: 2,
        question: 3,
        answered: businessProcessValues.manageDeviations == "yes" || businessProcessValues.manageDeviations == "no" ? true : false
      }, {
        key: businessProcessValues.communicatedProcesses === "yes" ? "Business process are communicated within the organization" : "Business processes not communicated throughout the company",
        value: businessProcessValues.communicatedProcesses === "yes" ? "No recommendation" : "Communication &  tracking",
        type: 2,
        question: 4,
        answered: businessProcessValues.communicatedProcesses == "yes" || businessProcessValues.communicatedProcesses == "no" ? true : false
      }, {
        key: businessProcessValues.designatedEmployee === "yes" ? "Has a designated employee" : "Does not have a designated employee",
        value: businessProcessValues.designatedEmployee === "yes" ? "No recommendation" : "Job Opportunity : Management & Administration",
        type: 2,
        question: 5,
        answered: businessProcessValues.designatedEmployee == "yes" || businessProcessValues.designatedEmployee == "no" ? true : false
      }
    ]
    //Employee Satisfaction
    const employeeSatisfaction = [
      {
        key: employeeStatValues.satisfactionSurveys == "yes" ? "Employee satisfaction surveys are completed." : "No employee satisfaction surveys",
        value: employeeStatValues.satisfactionSurveys == "yes" ? "No recommendation" : "Employee Satisfaction",
        type: 2,
        question: 1,
        answered: employeeStatValues.satisfactionSurveys == "yes" || employeeStatValues.satisfactionSurveys == "no" ? true : false
      },
      {
        key: employeeStatValues.rankSatisfaction == "yes" ? "Employee satisfaction surveys are completed." : "No employee satisfaction surveys.",
        value: employeeStatValues.rankSatisfaction == "yes" ? "No recommendation" : "Employee Satisfaction",
        type: 2,
        question: 2,
        answered: employeeStatValues.rankSatisfaction == "yes" || employeeStatValues.rankSatisfaction == "no" ? true : false
      }
    ]
    //Key Resources

    const keyResources = [{
      key: keyResourcesSegmentValues.resources === "yes" ? "Key resources needed have been determined." : "Key resources needed have not been determined",
      value: keyResourcesSegmentValues.resources === "yes" ? "No recommendation" : "organizational design and development",
      type: 1,
      question: 1,
      answered: keyResourcesSegmentValues.resources == "yes" || keyResourcesSegmentValues.resources == "no" ? true : false
    }]

    //Compliance and Certification
    const complianceSeg = [
      {
        key: complianceValues.relevantCompliance === "yes" ? "relevant compliance in place" : "Relevant compliance not in place",
        value: complianceValues.relevantCompliance === "yes" ? "No recommendation" : "",
        type: 2,
        question: 1,
        answered: complianceValues.relevantCompliance == "yes" || complianceValues.relevantCompliance == "no" ? true : false
      }, {
        key: complianceValues.qualityAssurance === "yes" ? "Quality assurance processes have been put in place" : "No quality assurance process in place.",
        value: complianceValues.qualityAssurance === "yes" ? "No recommendation" : "",
        type: 2,
        question: 2,
        answered: complianceValues.qualityAssurance == "yes" || complianceValues.qualityAssurance == "no" ? true : false
      },
      {
        key: complianceValues.certifiedAccredited === "yes" ? "Company has relevant certifications/accreditations." : "Company not certified/accredited for core services.",
        value: complianceValues.certifiedAccredited === "yes" ? "No recommendation" : "",
        type: 2,
        question: 3,
        answered: complianceValues.certifiedAccredited == "yes" || complianceValues.certifiedAccredited == "no" ? true : false
      }, {
        key: complianceValues.certifiedSASDC === "yes" ? "Company certified by SASDC" : "Company not certified by SASDC",
        value: complianceValues.certifiedSASDC === "yes" ? "No recommendation" : "",
        type: 2,
        question: 4,
        answered: complianceValues.certifiedSASDC == "yes" || complianceValues.certifiedSASDC == "no" ? true : false
      },
    ]
    //Legal
    const LegalSeg = [
      {
        key: legalValues.incorporationMemo === "yes" ? "Company is incorporated" : "Company not incorporated",
        value: legalValues.incorporationMemo === "yes" ? "No recommendation" : "",
        type: 2,
        question: 1,
        answered: legalValues.incorporationMemo == "yes" || legalValues.incorporationMemo == "no" ? true : false
      },
      {
        key: legalValues.shareholdersAgreement === "yes" ? "Shareholder certificates are available." : "Only one director in the company",
        value: legalValues.shareholdersAgreement === "yes" ? "No recommendation" : "",
        type: 2,
        question: 2,
        answered: legalValues.shareholdersAgreement == "yes" || legalValues.shareholdersAgreement == "no" ? true : false
      },
      {
        key: legalValues.shareCertificates === "yes" ? "Share certificates are available" : "No shares issued",
        value: legalValues.shareCertificates === "yes" ? "No recommendation" : "",
        type: 2,
        question: 3,
        answered: legalValues.shareCertificates == "yes" || legalValues.shareCertificates == "no" ? true : false
      },
      {
        key: legalValues.shareRegister === "yes" ? "A valuation on the business is available" : "No valuation has been done",
        value: legalValues.shareRegister === "yes" ? "No recommendation" : "",
        type: 2,
        question: 4,
        answered: legalValues.shareRegister == "yes" || legalValues.shareRegister == "no" ? true : false
      },
    ]







    const payload = {
      "segment": "Investment",
      "userId": user?.id,
      "segmentResponses": {
        "Channels": channels,
        "Functional": functionalSegment,
        "Customer": customerSegment,
        "BusinessCustomers": businessCustomers,
        "Revenue": revenue,
        "OwnershipMindset": owner,
        "Value": valuePropositionSegment,
        "CurrentAlternatives": currentAlternatives,
        "Partners": keyPartners,
        "Commercial": contractAgreement,
        "Traction": tractionSeg,
        "Financial": financialSegment,
        "Cost": costSegment,
        "Unique": uniqueSell,
        "Growth": growth,
        "BusinessProcess": businessProsessSeg,
        "Employee": employeeSatisfaction,
        "Resources": keyResources,
        "Compliance": complianceSeg,
        "Legal": LegalSeg
      },
      "segmentValues": {
        "channelValues": channelValues,
        "functionalSegmentValues": functionalSegmentValues,
        "customerSegmentValues": customerSegmentValues,
        "businessCustomerValues": businessCustomerValues,
        "revenueStreamValues": revenueStreamValues,
        "OwnerSegValues": OwnerSegValues,
        "propositionSegmentValues": propositionSegmentValues,
        "currentAlternativeSegmentValues": currentAlternativeSegmentValues,
        "keyPartnersSegmentValues": keyPartnersSegmentValues,
        "contractAgreementSegmentValues": contractAgreementSegmentValues,
        "tractionSegmentValues": tractionSegmentValues,
        "financialManagementValues": financialManagementValues,
        "costStructureValues": costStructureValues,
        "uniqueSellingValues": uniqueSellingValues,
        "growthStratValues": growthStratValues,
        "businessProcessValues": businessProcessValues,
        "employeeStatValues": employeeStatValues,
        "keyResourcesSegmentValues": keyResourcesSegmentValues,
        "complianceValues": complianceValues,
        "legalValues": legalValues
      }

    } as IInvestment
    console.log("array of answers", payload)
    const isUpdate = recommendation.segmentResponses ? true : false;
    if (isUpdate) {
      await supabase
        .from('Recomendations')
        .update({
          segmentResponses: {
            "Channels": channels,
            "Functional": functionalSegment,
            "Customer": customerSegment,
            "BusinessCustomers": businessCustomers,
            "Revenue": revenue,
            "OwnershipMindset": owner,
            "Value": valuePropositionSegment,
            "CurrentAlternatives": currentAlternatives,
            "Partners": keyPartners,
            "Commercial": contractAgreement,
            "Traction": tractionSeg,
            "Financial": financialSegment,
            "Cost": costSegment,
            "Unique": uniqueSell,
            "Growth": growth,
            "BusinessProcess": businessProsessSeg,
            "Employee": employeeSatisfaction,
            "Resources": keyResources,
            "Compliance": complianceSeg,
            "Legal": LegalSeg
          }
        })
        .eq('id', recommendation.id);

      await supabase
        .from('Recomendations')
        .update({
          segmentValues: {
            "channelValues": channelValues,
            "functionalSegmentValues": functionalSegmentValues,
            "customerSegmentValues": customerSegmentValues,
            "businessCustomerValues": businessCustomerValues,
            "revenueStreamValues": revenueStreamValues,
            "OwnerSegValues": OwnerSegValues,
            "propositionSegmentValues": propositionSegmentValues,
            "currentAlternativeSegmentValues": currentAlternativeSegmentValues,
            "keyPartnersSegmentValues": keyPartnersSegmentValues,
            "contractAgreementSegmentValues": contractAgreementSegmentValues,
            "tractionSegmentValues": tractionSegmentValues,
            "financialManagementValues": financialManagementValues,
            "costStructureValues": costStructureValues,
            "uniqueSellingValues": uniqueSellingValues,
            "growthStratValues": growthStratValues,
            "businessProcessValues": businessProcessValues,
            "employeeStatValues": employeeStatValues,
            "keyResourcesSegmentValues": keyResourcesSegmentValues,
            "complianceValues": complianceValues,
            "legalValues": legalValues
          }
        })
        .eq('id', recommendation.id)

    } else {
      const result = await Api.POST_CreateInvestmentRecommendation(payload)
      navigate('/HealthReport', { state: { bizInd: bizInd, bizPhase: bizPhase } });
      console.log('Result is', result)
    }

  }
  const handleChangeChannelsSegment = (question: string, field: string, event: React.ChangeEvent<HTMLInputElement>, index: number) => {
    const indexOfObject = Channel.findIndex(object => {
      return object.question === question;
    });
    setChannelValues({ ...channelValues, [field]: (event.target as HTMLInputElement).value });

    Channel.splice(indexOfObject, 1);
  };

  const handleChangeFunctional = (question: string, field: string, event: React.ChangeEvent<HTMLInputElement>, index: number) => {
    const indexOfObject = FunctionalSegment.findIndex(object => {
      return object.question === question;
    });
    setFunctionalSegmentValues({ ...functionalSegmentValues, [field]: (event.target as HTMLInputElement).value });

    FunctionalSegment.splice(indexOfObject, 1);
  };

  const handleChangeCustomerSegment = (question: string, field: string, event: React.ChangeEvent<HTMLInputElement>, index: number) => {
    const indexOfObject = CustomerSegment.findIndex(object => {
      return object.question === question;
    });
    setCustomerSegmentValues({ ...customerSegmentValues, [field]: (event.target as HTMLInputElement).value });

    CustomerSegment.splice(indexOfObject, 1);
  };
  const handleChangeBusinessCusSegment = (question: string, field: string, event: React.ChangeEvent<HTMLInputElement>, index: number) => {
    const indexOfObject = BusinessCustomer.findIndex(object => {
      return object.question === question;
    });
    setBusinessCustomerValues({ ...businessCustomerValues, [field]: (event.target as HTMLInputElement).value });

    BusinessCustomer.splice(indexOfObject, 1);
  };

  const handleChangeMarketingAndSales = (question: string, field: string, event: React.ChangeEvent<HTMLInputElement>, index: number) => {
    // console.log(index, question, field)
    const indexOfObject = mkSales.findIndex(object => {
      return object.question === question;
    });
    setValues({ ...values, [field]: (event.target as HTMLInputElement).value });

    mkSales.splice(indexOfObject, 1);
  };
  const handleChangeRevenueSegment = (question: string, field: string, event: React.ChangeEvent<HTMLInputElement>, index: number) => {
    const indexOfObject = RevenueStream.findIndex(object => {
      return object.question === question;
    });
    setRevenueStreamValues({ ...revenueStreamValues, [field]: (event.target as HTMLInputElement).value });

    RevenueStream.splice(indexOfObject, 1);
  };
  const handleChangeOwnerSegment = (question: string, field: string, event: React.ChangeEvent<HTMLInputElement>, index: number) => {
    const indexOfObject = OwnerSeg.findIndex(object => {
      return object.question === question;
    });
    setOwnerSegValues({ ...OwnerSegValues, [field]: (event.target as HTMLInputElement).value });

    OwnerSeg.splice(indexOfObject, 1);
  };
  const handleChangePropositionSegment = (question: string, field: string, event: React.ChangeEvent<HTMLInputElement>, index: number) => {
    const indexOfObject = PropositionSegment.findIndex(object => {
      return object.question === question;
    });
    setPropositionSegmentValues({ ...customerSegmentValues, [field]: (event.target as HTMLInputElement).value });

    PropositionSegment.splice(indexOfObject, 1);
  };
  const handleChangeKeyCurrentSegment = (question: string, field: string, event: React.ChangeEvent<HTMLInputElement>, index: number) => {
    const indexOfObject = CurrentAlternativeSegment.findIndex(object => {
      return object.question === question;
    });
    setcurrentAlternativeSegmentValues({ ...currentAlternativeSegmentValues, [field]: (event.target as HTMLInputElement).value });

    CurrentAlternativeSegment.splice(indexOfObject, 1);
  };
  const handleChangeKeyPartnerSegment = (question: string, field: string, event: React.ChangeEvent<HTMLInputElement>, index: number) => {
    const indexOfObject = KeyPartnersSegment.findIndex(object => {
      return object.question === question;
    });
    setKeyPartnersSegmentValues({ ...keyPartnersSegmentValues, [field]: (event.target as HTMLInputElement).value });

    KeyPartnersSegment.splice(indexOfObject, 1);
  };
  const handleChangeContractAgreeSegment = (question: string, field: string, event: React.ChangeEvent<HTMLInputElement>, index: number) => {
    const indexOfObject = ContractAgreementSegment.findIndex(object => {
      return object.question === question;
    });
    setContractAgreementSegmentValues({ ...contractAgreementSegmentValues, [field]: (event.target as HTMLInputElement).value });

    ContractAgreementSegment.splice(indexOfObject, 1);
  };
  const handleChangeTractionSegment = (question: string, field: string, event: React.ChangeEvent<HTMLInputElement>, index: number) => {
    const indexOfObject = TractionSegment.findIndex(object => {
      return object.question === question;
    });
    setTractionSegmentValues({ ...tractionSegmentValues, [field]: (event.target as HTMLInputElement).value });

    TractionSegment.splice(indexOfObject, 1);
  };
  const handleChangeFinancialSegment = (question: string, field: string, event: React.ChangeEvent<HTMLInputElement>, index: number) => {
    const indexOfObject = FinancialManagement.findIndex(object => {
      return object.question === question;
    });
    setFinancialManagementValues({ ...propositionSegmentValues, [field]: (event.target as HTMLInputElement).value });

    FinancialManagement.splice(indexOfObject, 1);
  };
  const handleChangeCostSegment = (question: string, field: string, event: React.ChangeEvent<HTMLInputElement>, index: number) => {
    const indexOfObject = CostStructure.findIndex(object => {
      return object.question === question;
    });
    setCostStructureValues({ ...costStructureValues, [field]: (event.target as HTMLInputElement).value });

    CostStructure.splice(indexOfObject, 1);
  };
  const handleChangeUniqueSegment = (question: string, field: string, event: React.ChangeEvent<HTMLInputElement>, index: number) => {
    const indexOfObject = UniqueSelling.findIndex(object => {
      return object.question === question;
    });
    setUniqueSellingValues({ ...uniqueSellingValues, [field]: (event.target as HTMLInputElement).value });

    UniqueSelling.splice(indexOfObject, 1);
  };
  const handleChangeGrowthSegment = (question: string, field: string, event: React.ChangeEvent<HTMLInputElement>, index: number) => {
    const indexOfObject = GrowthStrat.findIndex(object => {
      return object.question === question;
    });
    setGrowthStratValues({ ...growthStratValues, [field]: (event.target as HTMLInputElement).value });

    GrowthStrat.splice(indexOfObject, 1);
  };
  const handleChangeBusinessProcessSegment = (question: string, field: string, event: React.ChangeEvent<HTMLInputElement>, index: number) => {
    const indexOfObject = BusinessProcess.findIndex(object => {
      return object.question === question;
    });
    setBusinessProcessValues({ ...businessProcessValues, [field]: (event.target as HTMLInputElement).value });

    BusinessProcess.splice(indexOfObject, 1);
  };
  const handleChangeEmployeeSegment = (question: string, field: string, event: React.ChangeEvent<HTMLInputElement>, index: number) => {
    const indexOfObject = EmployeeSat.findIndex(object => {
      return object.question === question;
    });
    setEmployeeStatValues({ ...employeeStatValues, [field]: (event.target as HTMLInputElement).value });

    EmployeeSat.splice(indexOfObject, 1);
  };
  const handleChangeKeyResourcesSegment = (question: string, field: string, event: React.ChangeEvent<HTMLInputElement>, index: number) => {
    const indexOfObject = KeyResourcesSegment.findIndex(object => {
      return object.question === question;
    });
    setKeyResourcesSegmentValues({ ...keyResourcesSegmentValues, [field]: (event.target as HTMLInputElement).value });

    KeyResourcesSegment.splice(indexOfObject, 1);
  };
  const handleChangeComplianceSegment = (question: string, field: string, event: React.ChangeEvent<HTMLInputElement>, index: number) => {
    const indexOfObject = ComplianceSegment.findIndex(object => {
      return object.question === question;
    });
    setComplianceValues({ ...complianceValues, [field]: (event.target as HTMLInputElement).value });

    ComplianceSegment.splice(indexOfObject, 1);
  };
  const handleChangeLegalSegment = (question: string, field: string, event: React.ChangeEvent<HTMLInputElement>, index: number) => {
    const indexOfObject = LegalSegment.findIndex(object => {
      return object.question === question;
    });
    setLegalValues({ ...legalValues, [field]: (event.target as HTMLInputElement).value });

    LegalSegment.splice(indexOfObject, 1);
  };
  const state = useSelector(selectRecomendationState);
  const recommendation: any = state.persistedReducer.RecomendationReducer.selectedRecomendation;
  console.log(recommendation)
  console.log(customerSegment);
  //Channel
  let channelQuestions: { question: string, field: string }[] = []

  if (recommendation.segmentResponses) {
    channels.forEach(question => {
      if (recommendation.segmentResponses?.Channels.some((res: any) => res.question == question.number && !res.answered)) {
        channelQuestions.push(question);
      }
    });
  } else {
    channelQuestions = [...channels]
  }
  //Functional
  let functionalQuestions: { question: string, field: string }[] = []

  if (recommendation.segmentResponses) {
    functionalCapability.forEach(question => {
      if (recommendation.segmentResponses?.Functional.some((res: any) => res.question == question.number && !res.answered)) {
        functionalQuestions.push(question);
      }
    });
  } else {
    functionalQuestions = [...functionalCapability]
  }
  // Customer
  let customerSegmentQuestions: { question: string, field: string }[] = []

  if (recommendation.segmentResponses) {
    customerSegment.forEach(question => {
      if (recommendation.segmentResponses?.Customer.some((res: any) => res.question == question.number && !res.answered)) {
        customerSegmentQuestions.push(question);
      }
    });
  } else {
    customerSegmentQuestions = [...customerSegment]
  }
  //Business And Customers
  let businessCustomerQuestions: { question: string, field: string }[] = [...businessCustomersSeg]

  if (recommendation.segmentResponses) {
    businessCustomersSeg.forEach(question => {
      if (recommendation.segmentResponses?.BusinessCustomers.some((res: any) => res.question == question.number && !res.answered)) {
        businessCustomerQuestions.push(question);
      }
    });
  } else {
    businessCustomerQuestions = [...businessCustomersSeg]
  }
  //Revenue
  let revenueQuestions: { question: string, field: string }[] = []

  if (recommendation.segmentResponses) {
    revenue.forEach(question => {
      if (recommendation.segmentResponses?.Revenue.some((res: any) => res.question == question.number && !res.answered)) {
        revenueQuestions.push(question);
      }
    });
  } else {
    revenueQuestions = [...revenue]
  }

  //Ownership Mindset
  let ownerQuestions: { question: string, field: string }[] = []

  if (recommendation.segmentResponses) {
    owner.forEach(question => {
      if (recommendation.segmentResponses?.OwnershipMindset.some((res: any) => res.question == question.number && !res.answered)) {
        ownerQuestions.push(question);
      }
    });
  } else {
    ownerQuestions = [...owner]
  };
  //MArket
  let marketSalesQuestions: { question: string, field: string }[] = []

  if (recommendation.segmentResponses) {
    marketingSales.forEach(question => {
      if (recommendation.segmentResponses?.Market.some((res: any) => res.question == question.number && !res.answered)) {
        marketSalesQuestions.push(question);
      }
    });
  } else {
    marketSalesQuestions = [...marketingSales]
  }

  //Value Prop
  let valueQuestions: { question: string, field: string }[] = []

  if (recommendation.segmentResponses) {
    valuePropositionSegment.forEach(question => {
      if (recommendation.segmentResponses?.Value.some((res: any) => res.question == question.number && !res.answered)) {
        valueQuestions.push(question);
      }
    });
  } else {
    valueQuestions = [...valuePropositionSegment]
  }
  //Current Alternatives
  let currentAltQuestions: { question: string, field: string }[] = []

  if (recommendation.segmentResponses) {
    current.forEach(question => {
      if (recommendation.segmentResponses?.CurrentAlternatives.some((res: any) => res.question == question.number && !res.answered)) {
        currentAltQuestions.push(question);
      }
    });
  } else {
    currentAltQuestions = [...current]
  }

  //Key Partners
  let keyPartnersQuestions: { question: string, field: string }[] = []

  if (recommendation.segmentResponses) {
    partners.forEach(question => {
      if (recommendation.segmentResponses?.Partners.some((res: any) => res.question == question.number && !res.answered)) {
        keyPartnersQuestions.push(question);
      }
    });
  } else {
    keyPartnersQuestions = [...partners]
  }
  //Contract Agreement
  let contractAgreementQuestions: { question: string, field: string }[] = []

  if (recommendation.segmentResponses) {
    conAgreement.forEach(question => {
      if (recommendation.segmentResponses?.Commercial.some((res: any) => res.question == question.number && !res.answered)) {
        contractAgreementQuestions.push(question);
      }
    });
  } else {
    contractAgreementQuestions = [...conAgreement]
  }

  //Traction
  let tractionQuestions: { question: string, field: string }[] = []

  if (recommendation.segmentResponses) {
    traction.forEach(question => {
      if (recommendation.segmentResponses?.Traction.some((res: any) => res.question == question.number && !res.answered)) {
        tractionQuestions.push(question);
      }
    });
  } else {
    tractionQuestions = [...traction]
  }

  //Financial Management
  let financialQuestions: { question: string, field: string }[] = []

  if (recommendation.segmentResponses) {
    financial.forEach(question => {
      if (recommendation.segmentResponses?.Financial.some((res: any) => res.question == question.number && !res.answered)) {
        financialQuestions.push(question);
      }
    });
  } else {
    financialQuestions = [...financial]
  }
  //Cost Structure

  let costQuestions: { question: string, field: string }[] = []

  if (recommendation.segmentResponses) {
    costStructureSeg.forEach(question => {
      if (recommendation.segmentResponses?.Cost.some((res: any) => res.question == question.number && !res.answered)) {
        costQuestions.push(question);
      }
    });
  } else {
    costQuestions = [...costStructureSeg]
  }
  //Unique selling point 

  let uniqueQuestions: { question: string, field: string }[] = []

  if (recommendation.segmentResponses) {
    unique.forEach(question => {
      if (recommendation.segmentResponses?.Unique.some((res: any) => res.question == question.number && !res.answered)) {
        uniqueQuestions.push(question);
      }
    });
  } else {
    uniqueQuestions = [...unique]
  }

  //Growth Strategy

  let growthQuestions: { question: string, field: string }[] = []

  if (recommendation.segmentResponses) {
    growth.forEach(question => {
      if (recommendation.segmentResponses?.Growth.some((res: any) => res.question == question.number && !res.answered)) {
        growthQuestions.push(question);
      }
    });
  } else {
    growthQuestions = [...growth]
  }


  //Business Process Management

  let BusinessPMQuestions: { question: string, field: string }[] = []

  if (recommendation.segmentResponses) {
    businessProcess.forEach(question => {
      if (recommendation.segmentResponses?.BusinessProcess.some((res: any) => res.question == question.number && !res.answered)) {
        BusinessPMQuestions.push(question);
      }
    });
  } else {
    BusinessPMQuestions = [...businessProcess]
  }
  //Employee Satisfaction

  let employeeQuestions: { question: string, field: string }[] = []

  if (recommendation.segmentResponses) {
    employee.forEach(question => {
      if (recommendation.segmentResponses?.Employee.some((res: any) => res.question == question.number && !res.answered)) {
        employeeQuestions.push(question);
      }
    });
  } else {
    employeeQuestions = [...employee]
  }

  //Resources
  let resourcesQuestions: { question: string, field: string }[] = []

  if (recommendation.segmentResponses) {
    keyResourcesSegment.forEach(question => {
      if (recommendation.segmentResponses?.Value.some((res: any) => res.question == question.number && !res.answered)) {
        resourcesQuestions.push(question);
      }
    });
  } else {
    resourcesQuestions = [...keyResourcesSegment]
  }
  //Compliance
  let complianceQuestions: { question: string, field: string }[] = []

  if (recommendation.segmentResponses) {
    compliance.forEach(question => {
      if (recommendation.segmentResponses?.Compliance.some((res: any) => res.question == question.number && !res.answered)) {
        complianceQuestions.push(question);
      }
    });
  } else {
    complianceQuestions = [...compliance]
  }

  //Legal
  let legalQuestions: { question: string, field: string }[] = []


  if (recommendation.segmentResponses) {
    legal.forEach(question => {
      if (recommendation.segmentResponses?.Compliance.some((res: any) => res.question == question.number && !res.answered)) {
        legalQuestions.push(question);
      }
    });
  } else {
    legalQuestions = [...legal]
  }
  if (recommendation?.segmentValues && recommendation.segmentValues.channelValues) {
    setChannelValues(recommendation.segmentValues.channelValues);
  }
  if (recommendation?.segmentValues && recommendation.segmentValues.functionalSegmentValues) {
    setFunctionalSegmentValues(recommendation.segmentValues.functionalSegmentValues);
  }
  if (recommendation?.segmentValues && recommendation.segmentValues.customerSegmentValues) {
    setCustomerSegmentValues(recommendation.segmentValues.customerSegmentValues);
  }
  if (recommendation?.segmentValues && recommendation.segmentValues.businessCustomerValues) {
    setBusinessCustomerValues(recommendation.segmentValues.businessCustomerValues);
  }
  if (recommendation?.segmentValues && recommendation.segmentValues.revenueStreamValues) {
    debugger
    setRevenueStreamValues(recommendation.segmentValues.revenueStreamValues);
  }
  if (recommendation?.segmentValues && recommendation.segmentValues.OwnerSegValues) {
    setOwnerSegValues(recommendation.segmentValues.OwnerSegValues);
  }
  if (recommendation?.segmentValues && recommendation.segmentValues.marketSaleValues) {
    setValues(recommendation.segmentValues.marketSaleValues);
  }
  if (recommendation?.segmentValues && recommendation.segmentValues.propositionSegmentValues) {
    setPropositionSegmentValues(recommendation.segmentValues.propositionSegmentValues);
  }
  if (recommendation?.segmentValues && recommendation.segmentValues.currentAlternativeSegmentValues) {
    setcurrentAlternativeSegmentValues(recommendation.segmentValues.currentAlternativeSegmentValues);
  }
  if (recommendation?.segmentValues && recommendation.segmentValues.keyPartnersSegmentValues) {
    setKeyPartnersSegmentValues(recommendation.segmentValues.keyPartnersSegmentValues);
  }
  if (recommendation?.segmentValues && recommendation.segmentValues.contractAgreementSegmentValues) {
    setContractAgreementSegmentValues(recommendation.segmentValues.contractAgreementSegmentValues);
  }
  if (recommendation?.segmentValues && recommendation.segmentValues.tractionSegmentValues) {
    setTractionSegmentValues(recommendation.segmentValues.tractionSegmentValues);
  }
  if (recommendation?.segmentValues && recommendation.segmentValues.financialManagementValues) {
    setFinancialManagementValues(recommendation.segmentValues.financialManagementValues);
  }
  if (recommendation?.segmentValues && recommendation.segmentValues.costStructureValues) {
    setCostStructureValues(recommendation.segmentValues.costStructureValues);
  }
  if (recommendation?.segmentValues && recommendation.segmentValues.uniqueSellingValues) {
    setUniqueSellingValues(recommendation.segmentValues.uniqueSellingValues);
  }
  if (recommendation?.segmentValues && recommendation.segmentValues.growthStratValues) {
    setGrowthStratValues(recommendation.segmentValues.growthStratValues);
  }
  if (recommendation?.segmentValues && recommendation.segmentValues.businessProcessValues) {
    setBusinessProcessValues(recommendation.segmentValues.businessProcessValues);
  }
  if (recommendation?.segmentValues && recommendation.segmentValues.employeeStatValues) {
    setEmployeeStatValues(recommendation.segmentValues.employeeStatValues);
  }
  if (recommendation?.segmentValues && recommendation.segmentValues.keyResourcesSegmentValues) {
    setKeyResourcesSegmentValues(recommendation.segmentValues.keyResourcesSegmentValues);
  }
  if (recommendation?.segmentValues && recommendation.segmentValues.complianceValues) {
    setComplianceValues(recommendation.segmentValues.complianceValues);
  }
  if (recommendation?.segmentValues && recommendation.segmentValues.legalValues) {
    setLegalValues(recommendation.segmentValues.legalValues);
  }



  return (
    <div className='Basic'>
      <UserNavbar />
      <Container>
        <Grid container spacing={4}>
          <Grid item xs={12} sm={12} md={4} lg={4}>
            <Typography>Company</Typography>
            <Button
              className='profAdd'
              variant='outlined'
            >
              Add Company
            </Button>
            <div className='Accords'>
              <div className='sideAccord'>
                <AccessmentAccordion setSelectedRecommedation ={false}/>
              </div>
            </div>
          </Grid>
          <Grid item xs={12} sm={12} md={8} lg={8}>
            <Alert style={{ backgroundColor: "#00d3dd" }} severity="info">Next Step! Complete your Company Assessment.</Alert>
            <Typography className='biz' variant='h5'>Biz Assessment</Typography>
            <div className='companyBox'>
              <img
                src={company}
                alt='comLogo'
                className='company'
              />
              <div className='companyInf'>
                <div className='Location'>
                  <Typography>Location: N/A</Typography>
                </div>
                <div className='indust'>
                  <Typography>Industry: {bizInd[0]?.label}</Typography>
                </div>
                <div className='phase'>
                  <Typography>Business Phase: {bizPhase[0].label}</Typography>
                </div>
              </div>
            </div>
            <div className='bassicAccords'>
              <Accordion>
                <AccordionSummary
                  expandIcon={<ExpandMoreIcon />}
                  aria-controls="panel2a-content"
                  id="panel2a-header"
                >
                  <Typography className="">Channels</Typography>
                </AccordionSummary>
                <AccordionDetails>
                  <div className='rev'>
                    {
                      channelQuestions.map((val, index) => {
                        return (
                          <div key={index}>
                            <FormControl>
                              <FormLabel id="demo-controlled-radio-buttons-group">
                                {val.question}
                              </FormLabel>
                              <RadioGroup
                                aria-labelledby="demo-controlled-radio-buttons-group"
                                //name="controlled-radio-buttons-group"
                                value={values[index]}
                                onChange={(e) => handleChangeChannelsSegment(val.question, val.field, e, index)}
                              >
                                <FormControlLabel value="yes" checked={false} control={<Radio />} label="Yes" />
                                <FormControlLabel value="no" checked={false} control={<Radio />} label="No" />

                              </RadioGroup>
                            </FormControl>
                          </div>
                        )

                      })
                    }
                  </div>
                </AccordionDetails>
              </Accordion>
              <Accordion>
                <AccordionSummary
                  expandIcon={<ExpandMoreIcon />}
                  aria-controls="panel2a-content"
                  id="panel2a-header"
                >
                  <Typography className=''>Functional Capability</Typography>
                </AccordionSummary>
                <AccordionDetails>
                  <div className='rev'>
                    {
                      functionalQuestions.map((val, index) => {
                        return (
                          <div key={index}>
                            <FormControl>
                              <FormLabel id="demo-controlled-radio-buttons-group">
                                {val.question}
                              </FormLabel>
                              <RadioGroup
                                aria-labelledby="demo-controlled-radio-buttons-group"
                                //name="controlled-radio-buttons-group"
                                value={values[index]}
                                onChange={(e) => handleChangeFunctional(val.question, val.field, e, index)}
                              >
                                <FormControlLabel value="yes" checked={false} control={<Radio />} label="Yes" />
                                <FormControlLabel value="no" checked={false} control={<Radio />} label="No" />

                              </RadioGroup>
                            </FormControl>
                          </div>
                        )

                      })
                    }
                  </div>
                </AccordionDetails>
              </Accordion>
              <Accordion>
                <AccordionSummary
                  expandIcon={<ExpandMoreIcon />}
                  aria-controls="panel2a-content"
                  id="panel2a-header"
                >
                  <Typography className=''>Customer segment</Typography>
                </AccordionSummary>
                <AccordionDetails>
                  <div className='rev'>
                    {
                      customerSegmentQuestions.map((val, index) => {
                        return (
                          <div key={index}>
                            <FormControl>
                              <FormLabel id="demo-controlled-radio-buttons-group">
                                {val.question}
                              </FormLabel>
                              <RadioGroup
                                aria-labelledby="demo-controlled-radio-buttons-group"
                                //name="controlled-radio-buttons-group"
                                value={values[index]}
                                onChange={(e) => handleChangeCustomerSegment(val.question, val.field, e, index)}
                              >
                                <FormControlLabel value="yes" checked={false} control={<Radio />} label="Yes" />
                                <FormControlLabel value="no" checked={false} control={<Radio />} label="No" />

                              </RadioGroup>
                            </FormControl>
                          </div>
                        )

                      })
                    }
                  </div>
                </AccordionDetails>
              </Accordion>
              <Accordion>
                <AccordionSummary
                  expandIcon={<ExpandMoreIcon />}
                  aria-controls="panel2a-content"
                  id="panel2a-header"
                >
                  <Typography className=''>Business and Customers</Typography>
                </AccordionSummary>
                <AccordionDetails>
                  <div className='rev'>
                    {
                      businessCustomerQuestions.map((val, index) => {
                        return (
                          <div key={index}>
                            <FormControl>
                              <FormLabel id="demo-controlled-radio-buttons-group">
                                {val.question}
                              </FormLabel>
                              <RadioGroup
                                aria-labelledby="demo-controlled-radio-buttons-group"
                                //name="controlled-radio-buttons-group"
                                value={values[index]}
                                onChange={(e) => handleChangeBusinessCusSegment(val.question, val.field, e, index)}
                              >
                                <FormControlLabel value="yes" checked={false} control={<Radio />} label="Yes" />
                                <FormControlLabel value="no" checked={false} control={<Radio />} label="No" />

                              </RadioGroup>
                            </FormControl>
                          </div>
                        )

                      })
                    }
                  </div>
                </AccordionDetails>
              </Accordion>
              <Accordion>
                <AccordionSummary
                  expandIcon={<ExpandMoreIcon />}
                  aria-controls="panel2a-content"
                  id="panel2a-header"
                >
                  <Typography className=''>Revenue Streams</Typography>
                </AccordionSummary>
                <AccordionDetails>
                  <div className='rev'>
                    {
                      revenueQuestions.map((val, index) => {
                        return (
                          <div key={index}>
                            <FormControl>
                              <FormLabel id="demo-controlled-radio-buttons-group">
                                {val.question}
                              </FormLabel>
                              <RadioGroup
                                aria-labelledby="demo-controlled-radio-buttons-group"
                                //name="controlled-radio-buttons-group"
                                value={values[index]}
                                onChange={(e) => handleChangeRevenueSegment(val.question, val.field, e, index)}
                              >
                                <FormControlLabel value="yes" checked={false} control={<Radio />} label="Yes" />
                                <FormControlLabel value="no" checked={false} control={<Radio />} label="No" />

                              </RadioGroup>
                            </FormControl>
                          </div>
                        )

                      })
                    }
                  </div>

                </AccordionDetails>
              </Accordion>
              <Accordion>
                <AccordionSummary
                  expandIcon={<ExpandMoreIcon />}
                  aria-controls="panel2a-content"
                  id="panel2a-header"
                >
                  <Typography className=''>Ownership and Mindset</Typography>
                </AccordionSummary>
                <AccordionDetails>
                  <div className='rev'>
                    {
                      ownerQuestions.map((val, index) => {
                        return (
                          <div key={index}>
                            <FormControl>
                              <FormLabel id="demo-controlled-radio-buttons-group">
                                {val.question}
                              </FormLabel>
                              <RadioGroup
                                aria-labelledby="demo-controlled-radio-buttons-group"
                                //name="controlled-radio-buttons-group"
                                value={values[index]}
                                onChange={(e) => handleChangeOwnerSegment(val.question, val.field, e, index)}
                              >
                                <FormControlLabel value="yes" checked={false} control={<Radio />} label="Yes" />
                                <FormControlLabel value="no" checked={false} control={<Radio />} label="No" />

                              </RadioGroup>
                            </FormControl>
                          </div>
                        )

                      })
                    }
                  </div>
                </AccordionDetails>
              </Accordion>
              <Accordion>
                <AccordionSummary
                  expandIcon={<ExpandMoreIcon />}
                  aria-controls="panel2a-content"
                  id="panel2a-header"
                >
                  <Typography className=''>Marketing and Sales</Typography>
                </AccordionSummary>
                <AccordionDetails>
                  <div className='rev'>
                    {
                      marketSalesQuestions.map((val, index) => {
                        return (
                          <div key={index}>
                            <FormControl>
                              <FormLabel id="demo-controlled-radio-buttons-group">
                                {val.question}
                              </FormLabel>
                              <RadioGroup
                                aria-labelledby="demo-controlled-radio-buttons-group"
                                //name="controlled-radio-buttons-group"
                                value={values[index]}
                                onChange={(e) => handleChangeMarketingAndSales(val.question, val.field, e, index)}
                              >
                                <FormControlLabel value="yes" checked={false} control={<Radio />} label="Yes" />
                                <FormControlLabel value="no" checked={false} control={<Radio />} label="No" />

                              </RadioGroup>
                            </FormControl>
                          </div>
                        )

                      })
                    }
                  </div>
                </AccordionDetails>
              </Accordion>
              <Accordion>
                <AccordionSummary
                  expandIcon={<ExpandMoreIcon />}
                  aria-controls="panel2a-content"
                  id="panel2a-header"
                >
                  <Typography className=''>Value Proposition</Typography>
                </AccordionSummary>
                <AccordionDetails>
                  <div className='rev'>
                    {
                      valueQuestions.map((val, index) => {
                        return (
                          <div key={index}>
                            <FormControl>
                              <FormLabel id="demo-controlled-radio-buttons-group">
                                {val.question}
                              </FormLabel>
                              <RadioGroup
                                aria-labelledby="demo-controlled-radio-buttons-group"
                                //name="controlled-radio-buttons-group"
                                value={values[index]}
                                onChange={(e) => handleChangePropositionSegment(val.question, val.field, e, index)}
                              >
                                <FormControlLabel value="yes" checked={false} control={<Radio />} label="Yes" />
                                <FormControlLabel value="no" checked={false} control={<Radio />} label="No" />

                              </RadioGroup>
                            </FormControl>
                          </div>
                        )

                      })
                    }
                  </div>
                </AccordionDetails>
              </Accordion>
              <Accordion>
                <AccordionSummary
                  expandIcon={<ExpandMoreIcon />}
                  aria-controls="panel2a-content"
                  id="panel2a-header"
                >
                  <Typography className=''>Current Alternatives</Typography>
                </AccordionSummary>
                <AccordionDetails>
                  <div className='rev'>
                    {
                      currentAltQuestions.map((val, index) => {
                        return (
                          <div key={index}>
                            <FormControl>
                              <FormLabel id="demo-controlled-radio-buttons-group">
                                {val.question}
                              </FormLabel>
                              <RadioGroup
                                aria-labelledby="demo-controlled-radio-buttons-group"
                                //name="controlled-radio-buttons-group"
                                value={values[index]}
                                onChange={(e) => handleChangeKeyCurrentSegment(val.question, val.field, e, index)}
                              >
                                <FormControlLabel value="yes" checked={false} control={<Radio />} label="Yes" />
                                <FormControlLabel value="no" checked={false} control={<Radio />} label="No" />

                              </RadioGroup>
                            </FormControl>
                          </div>
                        )

                      })
                    }
                  </div>
                </AccordionDetails>
              </Accordion>
              <Accordion>
                <AccordionSummary
                  expandIcon={<ExpandMoreIcon />}
                  aria-controls="panel2a-content"
                  id="panel2a-header"
                >
                  <Typography className=''>Key Partners</Typography>
                </AccordionSummary>
                <AccordionDetails>
                  <div className='rev'>
                    {
                      keyPartnersQuestions.map((val, index) => {
                        return (
                          <div key={index}>
                            <FormControl>
                              <FormLabel id="demo-controlled-radio-buttons-group">
                                {val.question}
                              </FormLabel>
                              <RadioGroup
                                aria-labelledby="demo-controlled-radio-buttons-group"
                                //name="controlled-radio-buttons-group"
                                value={values[index]}
                                onChange={(e) => handleChangeKeyPartnerSegment(val.question, val.field, e, index)}
                              >
                                <FormControlLabel value="yes" checked={false} control={<Radio />} label="Yes" />
                                <FormControlLabel value="no" checked={false} control={<Radio />} label="No" />

                              </RadioGroup>
                            </FormControl>
                          </div>
                        )

                      })
                    }
                  </div>
                </AccordionDetails>
              </Accordion>
              <Accordion>
                <AccordionSummary
                  expandIcon={<ExpandMoreIcon />}
                  aria-controls="panel2a-content"
                  id="panel2a-header"
                >
                  <Typography className=''>Legal : Contract Agreement</Typography>
                </AccordionSummary>
                <AccordionDetails>
                  <div className='rev'>
                    {
                      contractAgreementQuestions.map((val, index) => {
                        return (
                          <div key={index}>
                            <FormControl>
                              <FormLabel id="demo-controlled-radio-buttons-group">
                                {val.question}
                              </FormLabel>
                              <RadioGroup
                                aria-labelledby="demo-controlled-radio-buttons-group"
                                //name="controlled-radio-buttons-group"
                                value={values[index]}
                                onChange={(e) => handleChangeContractAgreeSegment(val.question, val.field, e, index)}
                              >
                                <FormControlLabel value="yes" checked={false} control={<Radio />} label="Yes" />
                                <FormControlLabel value="no" checked={false} control={<Radio />} label="No" />

                              </RadioGroup>
                            </FormControl>
                          </div>
                        )

                      })
                    }
                  </div>
                </AccordionDetails>
              </Accordion>
              <Accordion>
                <AccordionSummary
                  expandIcon={<ExpandMoreIcon />}
                  aria-controls="panel2a-content"
                  id="panel2a-header"
                >
                  <Typography className=''>Traction</Typography>
                </AccordionSummary>
                <AccordionDetails>
                  <div className='rev'>
                    {
                      tractionQuestions.map((val, index) => {
                        return (
                          <div key={index}>
                            <FormControl>
                              <FormLabel id="demo-controlled-radio-buttons-group">
                                {val.question}
                              </FormLabel>
                              <RadioGroup
                                aria-labelledby="demo-controlled-radio-buttons-group"
                                //name="controlled-radio-buttons-group"
                                value={values[index]}
                                onChange={(e) => handleChangeTractionSegment(val.question, val.field, e, index)}
                              >
                                <FormControlLabel value="yes" checked={false} control={<Radio />} label="Yes" />
                                <FormControlLabel value="no" checked={false} control={<Radio />} label="No" />

                              </RadioGroup>
                            </FormControl>
                          </div>
                        )

                      })
                    }
                  </div>
                </AccordionDetails>
              </Accordion>
              <Accordion>
                <AccordionSummary
                  expandIcon={<ExpandMoreIcon />}
                  aria-controls="panel2a-content"
                  id="panel2a-header"
                >
                  <Typography className=''>Financial Management</Typography>
                </AccordionSummary>
                <AccordionDetails>
                  <div className='rev'>
                    {
                      financialQuestions.map((val, index) => {
                        return (
                          <div key={index}>
                            <FormControl>
                              <FormLabel id="demo-controlled-radio-buttons-group">
                                {val.question}
                              </FormLabel>
                              <RadioGroup
                                aria-labelledby="demo-controlled-radio-buttons-group"
                                //name="controlled-radio-buttons-group"
                                value={values[index]}
                                onChange={(e) => handleChangeFinancialSegment(val.question, val.field, e, index)}
                              >
                                <FormControlLabel value="yes" checked={false} control={<Radio />} label="Yes" />
                                <FormControlLabel value="no" checked={false} control={<Radio />} label="No" />

                              </RadioGroup>
                            </FormControl>
                          </div>
                        )

                      })
                    }
                  </div>
                </AccordionDetails>
              </Accordion>
              <Accordion>
                <AccordionSummary
                  expandIcon={<ExpandMoreIcon />}
                  aria-controls="panel2a-content"
                  id="panel2a-header"
                >
                  <Typography className="">Cost Structure</Typography>
                </AccordionSummary>
                <AccordionDetails>
                  <div className='rev'>
                    {
                      costQuestions.map((val, index) => {
                        return (
                          <div key={index}>
                            <FormControl>
                              <FormLabel id="demo-controlled-radio-buttons-group">
                                {val.question}
                              </FormLabel>
                              <RadioGroup
                                aria-labelledby="demo-controlled-radio-buttons-group"
                                //name="controlled-radio-buttons-group"
                                value={values[index]}
                                onChange={(e) => handleChangeCostSegment(val.question, val.field, e, index)}
                              >
                                <FormControlLabel value="yes" checked={false} control={<Radio />} label="Yes" />
                                <FormControlLabel value="no" checked={false} control={<Radio />} label="No" />

                              </RadioGroup>
                            </FormControl>
                          </div>
                        )

                      })
                    }
                  </div>

                </AccordionDetails>
              </Accordion>
              <Accordion>
                <AccordionSummary
                  expandIcon={<ExpandMoreIcon />}
                  aria-controls="panel2a-content"
                  id="panel2a-header"
                >
                  <Typography className="">Unique Selling point</Typography>
                </AccordionSummary>
                <AccordionDetails>
                  <div className='rev'>
                    {
                      uniqueQuestions.map((val, index) => {
                        return (
                          <div key={index}>
                            <FormControl>
                              <FormLabel id="demo-controlled-radio-buttons-group">
                                {val.question}
                              </FormLabel>
                              <RadioGroup
                                aria-labelledby="demo-controlled-radio-buttons-group"
                                //name="controlled-radio-buttons-group"
                                value={values[index]}
                                onChange={(e) => handleChangeUniqueSegment(val.question, val.field, e, index)}
                              >
                                <FormControlLabel value="yes" checked={false} control={<Radio />} label="Yes" />
                                <FormControlLabel value="no" checked={false} control={<Radio />} label="No" />

                              </RadioGroup>
                            </FormControl>
                          </div>
                        )

                      })
                    }
                  </div>

                </AccordionDetails>
              </Accordion>
              <Accordion>
                <AccordionSummary
                  expandIcon={<ExpandMoreIcon />}
                  aria-controls="panel2a-content"
                  id="panel2a-header"
                >
                  <Typography className="">Growth Strategy</Typography>
                </AccordionSummary>
                <AccordionDetails>
                  <div className='rev'>
                    {
                      growthQuestions.map((val, index) => {
                        return (
                          <div key={index}>
                            <FormControl>
                              <FormLabel id="demo-controlled-radio-buttons-group">
                                {val.question}
                              </FormLabel>
                              <RadioGroup
                                aria-labelledby="demo-controlled-radio-buttons-group"
                                //name="controlled-radio-buttons-group"
                                value={values[index]}
                                onChange={(e) => handleChangeGrowthSegment(val.question, val.field, e, index)}
                              >
                                <FormControlLabel value="yes" checked={false} control={<Radio />} label="Yes" />
                                <FormControlLabel value="no" checked={false} control={<Radio />} label="No" />

                              </RadioGroup>
                            </FormControl>
                          </div>
                        )

                      })
                    }
                  </div>

                </AccordionDetails>
              </Accordion>
              <Accordion>
                <AccordionSummary
                  expandIcon={<ExpandMoreIcon />}
                  aria-controls="panel2a-content"
                  id="panel2a-header"
                >
                  <Typography className="">Business Process Management</Typography>
                </AccordionSummary>
                <AccordionDetails>
                  <div className='rev'>
                    {
                      BusinessPMQuestions.map((val, index) => {
                        return (
                          <div key={index}>
                            <FormControl>
                              <FormLabel id="demo-controlled-radio-buttons-group">
                                {val.question}
                              </FormLabel>
                              <RadioGroup
                                aria-labelledby="demo-controlled-radio-buttons-group"
                                //name="controlled-radio-buttons-group"
                                value={values[index]}
                                onChange={(e) => handleChangeBusinessProcessSegment(val.question, val.field, e, index)}
                              >
                                <FormControlLabel value="yes" checked={false} control={<Radio />} label="Yes" />
                                <FormControlLabel value="no" checked={false} control={<Radio />} label="No" />

                              </RadioGroup>
                            </FormControl>
                          </div>
                        )

                      })
                    }
                  </div>

                </AccordionDetails>
              </Accordion>
              <Accordion>
                <AccordionSummary
                  expandIcon={<ExpandMoreIcon />}
                  aria-controls="panel2a-content"
                  id="panel2a-header"
                >
                  <Typography className="">Employee Satisfaction</Typography>
                </AccordionSummary>
                <AccordionDetails>
                  <div className='rev'>
                    {
                      employeeQuestions.map((val, index) => {
                        return (
                          <div key={index}>
                            <FormControl>
                              <FormLabel id="demo-controlled-radio-buttons-group">
                                {val.question}
                              </FormLabel>
                              <RadioGroup
                                aria-labelledby="demo-controlled-radio-buttons-group"
                                //name="controlled-radio-buttons-group"
                                value={values[index]}
                                onChange={(e) => handleChangeEmployeeSegment(val.question, val.field, e, index)}
                              >
                                <FormControlLabel value="yes" checked={false} control={<Radio />} label="Yes" />
                                <FormControlLabel value="no" checked={false} control={<Radio />} label="No" />

                              </RadioGroup>
                            </FormControl>
                          </div>
                        )

                      })
                    }
                  </div>

                </AccordionDetails>
              </Accordion>
              <Accordion>
                <AccordionSummary
                  expandIcon={<ExpandMoreIcon />}
                  aria-controls="panel2a-content"
                  id="panel2a-header"
                >
                  <Typography className=''>Key Resources</Typography>
                </AccordionSummary>
                <AccordionDetails>
                  <div className='rev'>
                    {
                      resourcesQuestions.map((val, index) => {
                        return (
                          <div key={index}>
                            <FormControl>
                              <FormLabel id="demo-controlled-radio-buttons-group">
                                {val.question}
                              </FormLabel>
                              <RadioGroup
                                aria-labelledby="demo-controlled-radio-buttons-group"
                                //name="controlled-radio-buttons-group"
                                value={values[index]}
                                onChange={(e) => handleChangeKeyResourcesSegment(val.question, val.field, e, index)}
                              >
                                <FormControlLabel value="yes" checked={false} control={<Radio />} label="Yes" />
                                <FormControlLabel value="no" checked={false} control={<Radio />} label="No" />

                              </RadioGroup>
                            </FormControl>
                          </div>
                        )

                      })
                    }
                  </div>
                </AccordionDetails>
              </Accordion>
              <Accordion>
                <AccordionSummary
                  expandIcon={<ExpandMoreIcon />}
                  aria-controls="panel2a-content"
                  id="panel2a-header"
                >
                  <Typography className=''>Compliance and Certification</Typography>
                </AccordionSummary>
                <AccordionDetails>
                  <div className='rev'>
                    {
                      complianceQuestions.map((val, index) => {
                        return (
                          <div key={index}>
                            <FormControl>
                              <FormLabel id="demo-controlled-radio-buttons-group">
                                {val.question}
                              </FormLabel>
                              <RadioGroup
                                aria-labelledby="demo-controlled-radio-buttons-group"
                                //name="controlled-radio-buttons-group"
                                value={values[index]}
                                onChange={(e) => handleChangeComplianceSegment(val.question, val.field, e, index)}
                              >
                                <FormControlLabel value="yes" checked={false} control={<Radio />} label="Yes" />
                                <FormControlLabel value="no" checked={false} control={<Radio />} label="No" />

                              </RadioGroup>
                            </FormControl>
                          </div>
                        )

                      })
                    }
                  </div>
                </AccordionDetails>
              </Accordion>
              <Accordion>
                <AccordionSummary
                  expandIcon={<ExpandMoreIcon />}
                  aria-controls="panel2a-content"
                  id="panel2a-header"
                >
                  <Typography className=''>Legal</Typography>
                </AccordionSummary>
                <AccordionDetails>
                  <div className='rev'>
                    {
                      legalQuestions.map((val, index) => {
                        return (
                          <div key={index}>
                            <FormControl>
                              <FormLabel id="demo-controlled-radio-buttons-group">
                                {val.question}
                              </FormLabel>
                              <RadioGroup
                                aria-labelledby="demo-controlled-radio-buttons-group"
                                //name="controlled-radio-buttons-group"
                                value={values[index]}
                                onChange={(e) => handleChangeLegalSegment(val.question, val.field, e, index)}
                              >
                                <FormControlLabel value="yes" checked={false} control={<Radio />} label="Yes" />
                                <FormControlLabel value="no" checked={false} control={<Radio />} label="No" />

                              </RadioGroup>
                            </FormControl>
                          </div>
                        )

                      })
                    }
                  </div>
                </AccordionDetails>
              </Accordion>




            </div>

            <div className='AssesButtonsA'>
              <Button
                variant='outlined'
                className='AssesBack'
              >
                Back
              </Button>
              <Button
                variant='outlined'
                className='AssesSave'
                onClick={() => createReport()}

              >
                Save

              </Button>
            </div>
          </Grid>
        </Grid>
      </Container>
      <div className='footD'>
        <Footernew />
      </div>
    </div>
  )
}

export default Investment;
// export const { save } = actions;
// export default reducer;

//try Export at the top