import React, { useEffect, useState } from 'react';
import { Container, Grid, Button } from '@material-ui/core';
import Accordion from '@material-ui/core/Accordion';
import AccordionSummary from '@material-ui/core/AccordionSummary';
import AccordionDetails from '@material-ui/core/AccordionDetails';
import Typography from '@material-ui/core/Typography';
import ExpandMoreIcon from '@material-ui/icons/ExpandMore';
import MuiAlert from '@material-ui/lab/Alert';
import UserNavbar from '../../UserNav/UserNav';
import company from '../../../Images/company.png';
import Radio from '@mui/material/Radio';
import RadioGroup from '@mui/material/RadioGroup';
import FormControlLabel from '@mui/material/FormControlLabel';
import FormControl from '@mui/material/FormControl';
import FormLabel from '@mui/material/FormLabel';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { createSlice } from '@reduxjs/toolkit';
import { Api } from '../../../services/endpoints';
import { IRecomendation, ICustomer } from '../../../Interfaces/IRecomendation';
import { supabase } from '../../../supabaseClient';
import Footernew from '../../Footer/Footernew';
import customerSegment from '../../../json/customerSegment.json';
import channels from "../../../json/channels.json";
import marketIntSeg from "../../../json/marketInteligence.json"
import costStructureSeg from "../../../json/costStructure.json"
import { useSelector } from 'react-redux';
import { selectRecomendationState } from "../../../Slice/createSlice";
import AccessmentAccordion from '../../AssessmentsAccordion/AccessmentsAccordion';
import '../Assessment.css';

type LocationState = {
	bizInd: Array<{
		value: number;
		label: string
	}>,
	bizPhase: Array<{
		value: number;
		label: string
	}>
}

const Customer = () => {
	const location = useLocation();
	const bizInd = (location.state as LocationState)?.bizInd;
	const bizPhase = (location.state as LocationState)?.bizPhase;
	const navigate = useNavigate();
	const user = supabase.auth.user()
	function Alert(props: any) {
		return <MuiAlert elevation={6} variant="filled" {...props} />;
	}

	const [Channel, setChannel] = useState<{ question: string, field: string }[]>(channels);
	const [CustomerSegment, setCustomerSegment] = useState<{ question: string, field: string }[]>(customerSegment);
	const [MarketInt, setMarketInt] = useState<{ question: string, field: string }[]>(marketIntSeg);
	const [CostStructure, setCostStructure] = useState<{ question: string, field: string }[]>(costStructureSeg);

	const [values, setValues] = useState<any>([]);
	const [channelValues, setChannelValues] = useState<any>([]);
	const [customerSegmentValues, setCustomerSegmentValues] = useState<any>([]);
	const [marketIntValues, setmarketIntValues] = useState<any>([]);
	const [costStructureValues, setCostStructureValues] = useState<any>([]);




	const createReport = async () => {
		//Channels
		const channels = [
			{
				key: channelValues.reachCustomer == "yes" ? "Customer profile has been determined." : "Customer profile not determined",
				value: channelValues.reachCustomer == "yes" ? "No Recommendation" : "Social media marketing, marketing plan, marketing startegy, sales funnel, customer acquisition plan.",
				type: 1,
				question: 1,
				answered: channelValues.reachCustomer == "yes" || channelValues.reachCustomer == "no" ? true : false
			},
			{
				key: channelValues.marketingPlan == "yes" ? "Strategies to reach customers has been determined." : "Strategies to reach customers has not been determined.",
				value: channelValues.marketingPlan == "yes" ? "No Recommendation" : "Marketing Plan.",
				type: 1,
				question: 2,
				answered: channelValues.marketingPlan == "yes" || channelValues.marketingPlan == "no" ? true : false
			},
			{
				key: channelValues.developedNetwork == "yes" ? "Network to reach target audience has been determined." : "Network to reach target audience has been determined.",
				value: channelValues.developedNetwork == "yes" ? "No Recommendation" : "Sales Funnel",
				type: 1,
				question: 3,
				answered: channelValues.developedNetwork == "yes" || channelValues.developedNetwork == "no" ? true : false
			},
			{
				key: channelValues.customerSupport == "yes" ? "Post sales support has been provided." : "Post sales support is not provided.",
				value: channelValues.customerSupport == "yes" ? "No Recommendation" : "Sales personnel.",
				type: 1,
				question: 4,
				answered: channelValues.customerSupport == "yes" || channelValues.customerSupport == "no" ? true : false
			}
		]

		// Customer Segment
		const customerSegment = [
			{
				key: customerSegmentValues.productOwner == "yes" ? "Customer profile has been determined." : "Customer profile not determined",
				value: customerSegmentValues.productOwner == "yes" ? "No recommendation" : "Market Research",
				type: 1,
				question: 1,
				answered: customerSegmentValues.productOwner == "yes" || customerSegmentValues.productOwner == "no" ? true : false
			},
			{
				key: customerSegmentValues.tagetAudiance == "yes" ? "Target audience has been determined." : "Target audience has not been selected",
				value: customerSegmentValues.tagetAudiance == "yes" ? "No recommendation" : "Market Intelligence",
				type: 1,
				question: 2,
				answered: customerSegmentValues.tagetAudiance == "yes" || customerSegmentValues.tagetAudiance == "no" ? true : false
			},
			{
				key: customerSegmentValues.tagetAudianceLocation == "yes" ? "Target audience has been located geographically." : "Target audience has not been located geographically",
				value: customerSegmentValues.tagetAudianceLocation == "yes" ? "No recommendation" : "Market Research",
				type: 1,
				question: 3,
				answered: customerSegmentValues.tagetAudianceLocation == "yes" || customerSegmentValues.tagetAudianceLocation == "no" ? true : false
			},
			{
				key: customerSegmentValues.tagetMarketSize == "yes" ? "Target audience has been segmented." : "Target audience has not been segmented.",
				value: customerSegmentValues.tagetMarketSize == "yes" ? "No recommendation" : "SAM SOM TAM",
				type: 1,
				question: 4,
				answered: customerSegmentValues.tagetMarketSize == "yes" || customerSegmentValues.tagetMarketSize == "no" ? true : false
			},
			{
				key: customerSegmentValues.cusReach == "yes" ? "Total accessible market has been determined." : "Total accessible market has not been determined",
				value: customerSegmentValues.cusReach == "yes" ? "No recommendation" : "Market Strategy",
				type: 1,
				question: 5,
				answered: customerSegmentValues.cusReach == "yes" || customerSegmentValues.cusReach == "no" ? true : false
			},
			{
				key: customerSegmentValues.competitor == "yes" ? "Competitors have been identified" : "competitors have not been identified",
				value: customerSegmentValues.competitor == "yes" ? "No recommendation" : "Competitor Analysis",
				type: 1,
				question: 6,
				answered: customerSegmentValues.competitor == "yes" || customerSegmentValues.competitor == "no" ? true : false
			},
			{
				key: customerSegmentValues.marketAccess == "yes" ? "Total accessible market has been determined." : "Total accessible market has not been determined",
				value: customerSegmentValues.marketAccess == "yes" ? "No recommendation" : "Total Addressable market",
				type: 1,
				question: 7,
				answered: customerSegmentValues.marketAccess == "yes" || customerSegmentValues.marketAccess == "no" ? true : false
			},
			{
				key: customerSegmentValues.marketLocation == "yes" ? "Total observable market has been determined." : "Total observable market has not been determined.",
				value: customerSegmentValues.marketLocation == "yes" ? "No recommendation" : "Market Reasearch",
				type: 1,
				question: 8,
				answered: customerSegmentValues.marketLocation == "yes" || customerSegmentValues.marketLocation == "no" ? true : false
			},
			{
				key: customerSegmentValues.idealCustomer == "yes" ? "Ideal customer profile has been determined." : "Ideal customer profile has not been determined.",
				value: customerSegmentValues.idealCustomer == "yes" ? "No recommendation" : "Ideal Customer profile",
				type: 1,
				question: 9,
				answered: customerSegmentValues.idealCustomer == "yes" || customerSegmentValues.idealCustomer == "no" ? true : false
			},
			{
				key: customerSegmentValues.importantCustomer == "yes" ? "Most important not determined." : "Most important customers not determined",
				value: customerSegmentValues.importantCustomer == "yes" ? "No recommendation" : "Market Research",
				type: 1,
				question: 10,
				answered: customerSegmentValues.importantCustomer == "yes" || customerSegmentValues.importantCustomer == "no" ? true : false
			},
			{
				key: customerSegmentValues.customerReaserch == "yes" ? "Customer research has been done" : "Customer research has not been done",
				value: customerSegmentValues.customerReaserch == "yes" ? "No recommendation" : "Business Research Officer",
				type: 1,
				question: 11,
				answered: customerSegmentValues.customerReaserch == "yes" || customerSegmentValues.customerReaserch == "no" ? true : false
			}
		]
		//Market Intelligence
		const marketSegment = [
			{
				key: marketIntValues.marketResearch == "yes" ? "Customer research has been done." : "Customer research has not been done",
				value: marketIntValues.marketResearch == "yes" ? "No Recommendation" : "Job Opportunity : Business Research Officer.",
				type: 1,
				question: 1,
				answered: marketIntValues.marketResearch == "yes" || marketIntValues.marketResearch == "no" ? true : false
			},
			{
				key: marketIntValues.marketPlaninPlace == "yes" ? "There is a marketing plan in Place." : "There is no marketing plan in Place.",
				value: marketIntValues.marketPlaninPlace == "yes" ? "No Recommendation" : "Marketing Plan.",
				type: 1,
				question: 2,
				answered: marketIntValues.marketPlaninPlace == "yes" || marketIntValues.marketPlaninPlace == "no" ? true : false
			},
			{
				key: marketIntValues.targetNetwork == "yes" ? "There is a target network." : "There is no target network.",
				value: marketIntValues.targetNetwork == "yes" ? "No Recommendation" : "Networking.",
				type: 1,
				question: 3,
				answered: marketIntValues.targetNetwork == "yes" || marketIntValues.targetNetwork == "no" ? true : false
			},
			{
				key: marketIntValues.postSales == "yes" ? "Post sales support has been provided." : "Post sales support is not provided.",
				value: marketIntValues.postSales == "yes" ? "No Recommendation" : "Job Opportunity : Sales personel.",
				type: 1,
				question: 4,
				answered: marketIntValues.postSales == "yes" || marketIntValues.postSales == "no" ? true : false
			},
		]
		//Cost Structure
		const costSegment = [
			{
				key: costStructureValues.deliveryCost == "yes" ? "Cost of sales has been determined." : "Cost of sales not determined.",
				value: costStructureValues.deliveryCost == "yes" ? "No Recommendation" : "Costing, product & service pricing",
				type: 1,
				question: 1,
				answered: costStructureValues.deliveryCost == "yes" || costStructureValues.deliveryCost == "no" ? true : false
			},
			{
				key: costStructureValues.acquiringCost == "yes" ? "Cos of sales has been determined." : "Cost of sales not determined.",
				value: costStructureValues.acquiringCost == "yes" ? "No Recommendation" : "Costing, product & service pricing",
				type: 1,
				question: 2,
				answered: costStructureValues.acquiringCost == "yes" || costStructureValues.acquiringCost == "no" ? true : false
			},
			{
				key: costStructureValues.customerRelationship == "yes" ? "Cost of customer retention  determined." : "Cost of customer retention not determined.",
				value: costStructureValues.customerRelationship == "yes" ? "No Recommendation" : "Costing, product & service pricing",
				type: 1,
				question: 3,
				answered: costStructureValues.customerRelationship == "yes" || costStructureValues.customerRelationship == "no" ? true : false
			},
			{
				key: costStructureValues.marketSegments == "yes" ? "cost of market penetration has been determined." : "Cost of market penetration not determined.",
				value: costStructureValues.marketSegments == "yes" ? "No Recommendation" : "Costing, product & service pricing",
				type: 1,
				question: 4,
				answered: costStructureValues.marketSegments == "yes" || costStructureValues.marketSegments == "no" ? true : false
			}
		]
		const payload = {
			"segment": "customer",
			"userId": user?.id,
			"segmentResponses": {
				"Channels": channels,
				"Customer": customerSegment,
				"MarketInt": marketSegment,
				"Cost": costSegment

			},
			"segmentValues": {
				"channelValues": channelValues,
				"customerSegmentValues": customerSegmentValues,
				"marketIntValues": marketIntValues,
				"costStructureValues": costStructureValues,
			}


		} as ICustomer
		console.log("array of answers", payload)
		const isUpdate = recommendation.segmentResponses ? true : false;
		if (isUpdate) {
			await supabase
				.from('Recomendations')
				.update({
					segmentResponses: {
						"Channels": channels,
						"Customer": customerSegment,
						"MarketInt": marketSegment,
						"Cost": costSegment
					}
				})
				.eq('id', recommendation.id);

			await supabase
				.from('Recomendations')
				.update({
					segmentValues: {
						"channelValues": channelValues,
						"customerSegmentValues": customerSegmentValues,
						"marketIntValues": marketIntValues,
						"costStructureValues": costStructureValues,
					}
				})
				.eq('id', recommendation.id)

		} else {
			const result = await Api.POST_CreateCustomerRecommendation(payload)
			navigate('/HealthReport', { state: { bizInd: bizInd, bizPhase: bizPhase } });
			console.log('Result is', result)
		}

	}
	const handleChangeChannelsSegment = (question: string, field: string, event: React.ChangeEvent<HTMLInputElement>, index: number) => {
		const indexOfObject = Channel.findIndex(object => {
			return object.question === question;
		});
		setChannelValues({ ...channelValues, [field]: (event.target as HTMLInputElement).value });

		Channel.splice(indexOfObject, 1);
	};

	const handleChangeCustomerSegment = (question: string, field: string, event: React.ChangeEvent<HTMLInputElement>, index: number) => {
		const indexOfObject = CustomerSegment.findIndex(object => {
			return object.question === question;
		});
		setCustomerSegmentValues({ ...customerSegmentValues, [field]: (event.target as HTMLInputElement).value });

		CustomerSegment.splice(indexOfObject, 1);
	};
	const handleChangeMarketSegment = (question: string, field: string, event: React.ChangeEvent<HTMLInputElement>, index: number) => {
		const indexOfObject = MarketInt.findIndex(object => {
			return object.question === question;
		});
		setmarketIntValues({ ...marketIntValues, [field]: (event.target as HTMLInputElement).value });

		MarketInt.splice(indexOfObject, 1);
	};
	const handleChangeCostSegment = (question: string, field: string, event: React.ChangeEvent<HTMLInputElement>, index: number) => {
		const indexOfObject = CostStructure.findIndex(object => {
			return object.question === question;
		});
		setCostStructureValues({ ...costStructureValues, [field]: (event.target as HTMLInputElement).value });

		CostStructure.splice(indexOfObject, 1);
	};
	const state = useSelector(selectRecomendationState);
	const recommendation: any = state.persistedReducer.RecomendationReducer.selectedRecomendation;
	console.log(recommendation)
	console.log(customerSegment);
	//Channel
	let channelQuestions: { question: string, field: string }[] = [...channels]

	if (recommendation.segmentResponses) {
		channels.forEach(question => {
			if (recommendation.segmentResponses?.Channels.some((res: any) => res.question == question.number && !res.answered)) {
				customerSegmentQuestions.push(question);
			}
		});
	} else {
		channelQuestions = [...channels]
	}

	//Customer
	let customerSegmentQuestions: { question: string, field: string }[] = []

	if (recommendation.segmentResponses) {
		customerSegment.forEach(question => {
			if (recommendation.segmentResponses?.Customer.some((res: any) => res.question == question.number && !res.answered)) {
				customerSegmentQuestions.push(question);
			}
		});
	} else {
		customerSegmentQuestions = [...customerSegment]
	}
	// Market Intelligence
	let marketIntelligenceQuestions: { question: string, field: string }[] = []

	if (recommendation.segmentResponses) {
		marketIntSeg.forEach(question => {
			if (recommendation.segmentResponses?.MarketInt.some((res: any) => res.question == question.number && !res.answered)) {
				marketIntelligenceQuestions.push(question);
			}
		});
	} else {
		marketIntelligenceQuestions = [...marketIntSeg]
	}
	//Cost Structure

	let costQuestions: { question: string, field: string }[] = []

	if (recommendation.segmentResponses) {
		costStructureSeg.forEach(question => {
			if (recommendation.segmentResponses?.Cost.some((res: any) => res.question == question.number && !res.answered)) {
				costQuestions.push(question);
			}
		});
	} else {
		costQuestions = [...costStructureSeg]
	}
	useEffect(() => {
		if (recommendation?.segmentValues && recommendation.segmentValues.channelValues) {
			setChannelValues(recommendation.segmentValues.channelValues);
		}
		if (recommendation?.segmentValues && recommendation.segmentValues.customerSegmentValues) {
			setCustomerSegmentValues(recommendation.segmentValues.customerSegmentValues);
		}
		if (recommendation?.segmentValues && recommendation.segmentValues.marketIntValues) {
			setmarketIntValues(recommendation.segmentValues.marketIntValues);
		}
		if (recommendation?.segmentValues && recommendation.segmentValues.costStructureValues) {
			setCostStructureValues(recommendation.segmentValues.costStructureValues);
		}

	}, [])
	return (
		<div className="sell-con">
			<UserNavbar />
			<Container>
				<Grid container spacing={2}>
					<Grid item xs={12} sm={12} md={4} lg={4}>
						<Typography>Company</Typography>
						<Button className="profAdd" variant="outlined">
							Add Company
						</Button>
						<div className="Accords">
							<div className="sideAccord">
								<AccessmentAccordion setSelectedRecommedation ={false}/>
							</div>
						</div>
					</Grid>
					<Grid item xs={12} sm={12} md={8} lg={8}>
						<Alert style={{ backgroundColor: "#00d3dd" }} severity="info">Next Step! Complete your Company Assessment.</Alert>
						<Typography className="biz" variant="h5">
							Biz Assessment
						</Typography>
						<div className="companyBox">
							<img src={company} alt="comLogo" className="company" />
							<div className="companyInf">
								<div className="Location">
									<Typography>Location: N/A</Typography>
								</div>
								<div className="indust">
									<Typography>Industry: {bizInd[0].label}</Typography>
								</div>
								<div className="phase">
									<Typography>Business Phase: {bizPhase[0].label}</Typography>
								</div>
							</div>
						</div>
						<div className="questionare">
							<Accordion>
								<AccordionSummary
									expandIcon={<ExpandMoreIcon />}
									aria-controls="panel2a-content"
									id="panel2a-header"
								>
									<Typography className="">Channels</Typography>
								</AccordionSummary>
								<AccordionDetails>
									<div className='rev'>
										{
											channelQuestions.map((val, index) => {
												return (
													<div key={index}>
														<FormControl>
															<FormLabel id="demo-controlled-radio-buttons-group">
																{val.question}
															</FormLabel>
															<RadioGroup
																aria-labelledby="demo-controlled-radio-buttons-group"
																//name="controlled-radio-buttons-group"
																value={values[index]}
																onChange={(e) => handleChangeChannelsSegment(val.question, val.field, e, index)}
															>
																<FormControlLabel value="yes" checked={false} control={<Radio />} label="Yes" />
																<FormControlLabel value="no" checked={false} control={<Radio />} label="No" />

															</RadioGroup>
														</FormControl>
													</div>
												)

											})
										}
									</div>
								</AccordionDetails>
							</Accordion>
							<Accordion>
								<AccordionSummary
									expandIcon={<ExpandMoreIcon />}
									aria-controls="panel2a-content"
									id="panel2a-header"
								>
									<Typography className="">Customer segment</Typography>
								</AccordionSummary>
								<AccordionDetails>
									<div className='rev'>
										{
											customerSegmentQuestions.map((val, index) => {
												return (
													<div key={index}>
														<FormControl>
															<FormLabel id="demo-controlled-radio-buttons-group">
																{val.question}
															</FormLabel>
															<RadioGroup
																aria-labelledby="demo-controlled-radio-buttons-group"
																//name="controlled-radio-buttons-group"
																value={values[index]}
																onChange={(e) => handleChangeCustomerSegment(val.question, val.field, e, index)}
															>
																<FormControlLabel value="yes" checked={false} control={<Radio />} label="Yes" />
																<FormControlLabel value="no" checked={false} control={<Radio />} label="No" />

															</RadioGroup>
														</FormControl>
													</div>
												)

											})
										}
									</div>
								</AccordionDetails>
							</Accordion>
							<Accordion>
								<AccordionSummary
									expandIcon={<ExpandMoreIcon />}
									aria-controls="panel2a-content"
									id="panel2a-header"
								>
									<Typography className="">Market Intelligence</Typography>
								</AccordionSummary>
								<AccordionDetails>
									<div className='rev'>
										{
											marketIntelligenceQuestions.map((val, index) => {
												return (
													<div key={index}>
														<FormControl>
															<FormLabel id="demo-controlled-radio-buttons-group">
																{val.question}
															</FormLabel>
															<RadioGroup
																aria-labelledby="demo-controlled-radio-buttons-group"
																//name="controlled-radio-buttons-group"
																value={values[index]}
																onChange={(e) => handleChangeMarketSegment(val.question, val.field, e, index)}
															>
																<FormControlLabel value="yes" checked={false} control={<Radio />} label="Yes" />
																<FormControlLabel value="no" checked={false} control={<Radio />} label="No" />

															</RadioGroup>
														</FormControl>
													</div>
												)

											})
										}
									</div>

								</AccordionDetails>
							</Accordion>
							<Accordion>
								<AccordionSummary
									expandIcon={<ExpandMoreIcon />}
									aria-controls="panel2a-content"
									id="panel2a-header"
								>
									<Typography className="">Cost Structure</Typography>
								</AccordionSummary>
								<AccordionDetails>
									<div className='rev'>
										{
											costQuestions.map((val, index) => {
												return (
													<div key={index}>
														<FormControl>
															<FormLabel id="demo-controlled-radio-buttons-group">
																{val.question}
															</FormLabel>
															<RadioGroup
																aria-labelledby="demo-controlled-radio-buttons-group"
																//name="controlled-radio-buttons-group"
																value={values[index]}
																onChange={(e) => handleChangeCostSegment(val.question, val.field, e, index)}
															>
																<FormControlLabel value="yes" checked={false} control={<Radio />} label="Yes" />
																<FormControlLabel value="no" checked={false} control={<Radio />} label="No" />

															</RadioGroup>
														</FormControl>
													</div>
												)

											})
										}
									</div>

								</AccordionDetails>
							</Accordion>
							<Button
								variant='outlined'
								className='AssesSave'
								onClick={() => createReport()}

							>
								Save

							</Button>
						</div>

					</Grid>
				</Grid>
			</Container>
			<div className='footCus'>
				<Footernew />
			</div>
		</div>
	);
};
export default Customer;
