// import React, { Component } from 'react'
// import Chart from 'react-google-charts'
// const pieData = [
//   ['Task', 'Hours per Day'],
//   ['Work', 11],
//   ['Eat', 2],
//   ['Commute', 2],
//   ['Watch TV', 2],
//   ['Sleep', 7],
// ]
// const pieOptions = {
//   title: 'My Daily Activities',
//   pieHole: 0.4,
// }
// const PieChart = () => {
//     console.log('Pie data', pieData)
//     return (
//       <div className="container mt-5">
//         <h2>React Donut Chart Example</h2>
//         <Chart
//           width={"600px"}
//           height= {"320px"}
//           chartType="PieChart"
//           data={pieData} 
//         />
//       </div>
//     )
// }
// export default PieChart