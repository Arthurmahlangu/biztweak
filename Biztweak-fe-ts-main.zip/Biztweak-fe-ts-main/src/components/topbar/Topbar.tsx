import React, { useState } from "react";
import "./topbar.css";
// import logo from "../../assets/logo.png";
import { NotificationsNone, Language, Settings } from "@material-ui/icons";
import SearchIcon from '@mui/icons-material/Search';
import HomeIcon from '@mui/icons-material/Home';
import ArrowDropDownIcon from '@mui/icons-material/ArrowDropDown';
import PersonIcon from '@mui/icons-material/Person';
import Typography from "@material-ui/core/Typography";
import { supabase } from "../../supabaseClient";
import { useNavigate } from "react-router-dom";

export default function Topbar() {
const [searchInfo, setSearchInfo] = useState<any>("");
const [profileResults, setProfileResults] = useState<any>([]);
const [companyResults, setCompanyResults] = useState<any>([]);
const navigate = useNavigate();

  const user = supabase.auth.user();
  const email = user?.email;
  // console.log("Admin email", email)
 

  const SearchCompany = async  () => {
   let {data, error } = await supabase
   .from('Company')
   .select("*")
   .like('companyName', `%${searchInfo}%`)
   .like('location', `%${searchInfo}%`)
   .like('phase', `%${searchInfo}%`)
   console.log("Search data company",data)
   setCompanyResults(data)
   return data
  }

  const SearchProfile = async  () => {
    console.log("search" , searchInfo)
    let {data, error } = await supabase
    .from('profile')
    .select("*")
    .like('display_name', `%${searchInfo}%`)
    setProfileResults(data)
    return data
 
   }

   const SearchFunc = () => {
    SearchCompany().then((company : any) =>{
      SearchProfile().then((user : any) => {
        console.log("checking them", user, company)
        navigate('/SearchResults', { state: {userData: user, companyData: company }    });
      })
    })
   
    
   }
  
  return (
    <div className="topbar">
      <div className="topbarWrapper">
        <div className="topLeft">
          <div className="search">
            <input type="text" placeholder="Search"
            onChange={(e) => setSearchInfo(e.target.value)}
            />
            <button 
            onClick={SearchFunc}
            ><SearchIcon /></button>
          </div>
        </div>
        <div className="topRight">
          <div className="topbarIconContainer">
          <HomeIcon />
          </div>
          <div className="topbarIconContainer">
          <PersonIcon />
          </div>
          <div className="topbarIconContainer">
            <Typography>{email}</Typography>
          </div>
          <div className="topbarIconContainer">
          <ArrowDropDownIcon/>
          </div>
        </div>
      </div>
    </div>
  );
}
