import React from 'react';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
} from 'recharts';
import Container from 'react-bootstrap/Container';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';
import { useDispatch, useSelector } from 'react-redux';
import Typography from '@material-ui/core/Typography';
import {
  selectRecomendationState,
  setAllUserRecomendations,
  setSelectedRecomendation,
} from '../../Slice/createSlice';
import './chart.css';

export default function NewBar() {
  const state = useSelector(selectRecomendationState);

  const stateData = [];
  stateData.push(state);

  const stateDataview = [];
  stateDataview.push(state.persistedReducer);

  const reco = [];
  reco.push(stateDataview[0].RecomendationReducer);

  const selected = [];
  selected.push(reco[0].selectedRecomendation);

  let barConceptSep = [] as any[];
  barConceptSep.push(selected[0]?.segmentResponses);

  let reData2 = [] as any[];
  if (selected[0]?.segmentResponses && selected[0]?.segmentResponses != null) {
    barConceptSep.forEach((conectList: any) => {
      const j = Object.keys(conectList && conectList).forEach((name: any) => {
        let f = conectList[name].some((cl: any) => cl.type == 1);
        if (f == true) {
          const obj = {} as any;
          obj[name] = conectList[name];
          reData2.push(obj);
        }
      });
    });
  }

  let barData = [] as any[];
  if (selected[0]?.segmentResponses != null) {
    barData = reData2.map((data: any) => {
      const convertData = Object.values(data) as any[];

      return convertData ? [0] && convertData[0].length : 0;
    });
  }
  console.log('length', barData);
  let checking = reData2.map((names: any, i: any) => {
    console.log('Right here', names);
    return Object.keys(names);
  });

  let newList = [] as any[];
  let barVal = checking.map((x: any, index: number) => {
    const headList = x.map((head: any) => {
      newList.push(head);
    });
  });
  console.log('find names', newList);
  let barInfoArray = [] as any[];
  if (selected[0]?.segmentResponses != null) {
    barInfoArray = Object.keys(reData2);
  }
  // let count   = 0;
  const barKey = newList.map((name: any, index: number) => ({
    name,
    conceptValue: barData[index],
  }));

  console.clear();
  console.log('barKey', barKey);


  return (
    <div className="conceptBG">
      {/* <pre>{JSON.stringify(barKey)}</pre> */}
      <ResponsiveContainer width="95%" height={300}>
        <BarChart
          width={500}
          height={300}
          data={barKey}
          margin={{
            top: 5,
            right: 30,
            left: 20,
            bottom: 80,
          }}
          barSize={20}
        >
          <XAxis
            dataKey="name"
            angle={-45}
            textAnchor="end"
            padding={{ left: 2, right: 2 }}
          />
          <YAxis />
          <Tooltip />
          {/* <Legend /> */}
          <CartesianGrid strokeDasharray="3 3" />
          <Bar
            dataKey="conceptValue"
            fill="#8884d8"
            background={{ fill: '#eee' }}
          />
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
}
