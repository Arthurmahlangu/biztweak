import React from "react";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer
} from "recharts";
import { useDispatch, useSelector } from "react-redux";
import Typography from '@material-ui/core/Typography';
import { selectRecomendationState, setAllUserRecomendations , setSelectedRecomendation } from "../../Slice/createSlice";


export default function BarStructure() {


const state = useSelector(selectRecomendationState)


const stateData  = []
stateData.push(state)

const stateDataview  = []
stateDataview.push(state.persistedReducer)

const reco = []
reco.push(stateDataview[0].RecomendationReducer)

const selected = []
if (reco[0].selectedRecomendation !== null){ 
selected.push(reco[0].selectedRecomendation) 
}


let barConceptSep = [] as any[]
barConceptSep.push(selected[0]?.segmentResponses)

let reData2 = [] as any[]
if(selected[0]?.segmentResponses && selected[0]?.segmentResponses != null){
  barConceptSep.forEach((conectList : any) => {
   const j = Object.keys(conectList && conectList).forEach((name : any) => { 
   let f = conectList[name].some((cl : any) => cl.type == 2)
   if( f == true){
     const obj = {} as any
     obj[name] = conectList[name]  
     reData2.push( 
       obj
     )
   }
   
   })
  } )
  }
let barData = [] as any[]
if (selected[0]?.segmentResponses != null) {
  barData = reData2.map( 
    (data : any) => {
 const convertData  =  Object.values(data) as any[]

      return convertData?[0] && convertData[0].length  : 0      
    }
   
)
}
console.log("length",barData)
let checking = reData2.map((names : any, i : any) => {
console.log("Right here", names)
return Object.keys(names) 
}) 

let newList = [] as any[]
let barVal = checking.map((x : any , index : number) => {
 
 const headList =  x.map((head : any) => {
    newList.push(head)
  })
}) 
console.log("find names", newList) 
let barInfoArray = [] as any[]
if(selected[0]?.segmentResponses != null){  
barInfoArray = Object.keys(reData2)
}

const barKey = newList.map((name : any, index : number) => ({  name , structureValue : barData[index] }))

 

  return (
<ResponsiveContainer width="95%" height={300}>
    <BarChart
      width={700}
      height={300}
      data={barKey}
      margin={{
        top: 5,
        right: 30,
        left: 25,
        bottom: 90,
      }}
      barSize={20}
    >
      <XAxis dataKey="name" scale="point" angle={-45} textAnchor="end" padding={{ left: 10, right: 10 }} />
      <YAxis />
      <Tooltip />
      {/* <Legend /> */}
      <CartesianGrid strokeDasharray="3 3" />
      <Bar dataKey="structureValue" fill="#008B8B" background={{ fill: "#eee" }} />
    </BarChart>
    </ResponsiveContainer>
  );
}
