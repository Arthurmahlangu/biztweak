import React, { useState, useEffect } from 'react';
import DashNav from '../DasNav/Nav';
import { Container, Grid, Button, Typography, Divider } from '@material-ui/core';
import { green, pink } from '@mui/material/colors';
import Avatar from '@mui/material/Avatar';
import Box from '@mui/material/Box';
import Card from '@mui/material/Card';
import CardActions from '@mui/material/CardActions';
import CardContent from '@mui/material/CardContent';
import banner from "../../Images/banner.png"
import Accordion from '@material-ui/core/Accordion';
import AccordionSummary from '@material-ui/core/AccordionSummary';
import AccordionDetails from '@material-ui/core/AccordionDetails';
import ExpandMoreIcon from '@material-ui/icons/ExpandMore';
import { Api } from '../../services/endpoints';
import { IRecomendation } from '../../Interfaces/IRecomendation';
import { Link } from 'react-router-dom';
import NewBar from './BarChart';
import PChart from './PieChart';
import Footernew from '../Footer/Footernew';
import { supabase } from '../../supabaseClient';
import { useDispatch, useSelector } from "react-redux";
import { selectRecomendationState, setAllUserRecomendations, setSelectedRecomendation } from "../../Slice/createSlice";
import './Report.css'
import  Barspace from './Barspace'
import BarStructure from './BarStructure';

const bull = (
  <Box
    component="span"
    sx={{ display: 'inline-block', mx: '2px', transform: 'scale(0.8)' }}
  >
    •
  </Box>
);


const Report = () => {
  // const { Recomendations } = useSelector(state=>state)
  const dispatch = useDispatch();

  const [initialize, setInitialize] = useState(false)
  const user = supabase.auth.user()
  const recommendations: Array<IRecomendation> = [];
  const [allRecommendations, setAllRecommendations] = useState<IRecomendation[]>([]);
  useEffect(() => {
    !initialize &&
      getReco();
  },[]);

  const getReco = async () => {
    const user = supabase.auth.user()

    const activeUser =  user?.id
    setInitialize(true)
    const { data, error } = await supabase
      .from('Recomendations')
      .select('*')
      .eq('userId', activeUser)
    const recoData = data
    dispatch(setAllUserRecomendations(recoData))

  }

  const state = useSelector(selectRecomendationState)


  const _setSelectedRecomendation = (selected: any) => {
    dispatch(setSelectedRecomendation(selected))

  }

 
	  const _user = user?.id
    useEffect(() => {
  
        getUserData();
    },[]);
  const getUserData = async () => {
    const { data, error } = await supabase
  .from('profile')
  .select(`
      id, display_name, Role
  `)
  .eq('id', _user)
    const role = data && data[0]?.Role
    const userName = data && data[0]?.display_name
// console.log('UserName', userName)

return userName
}




  const AllRecomendations = state?.persistedReducer?.RecomendationReducer?.allUserRecomendations ?? [];
  // console.log("All User Reccom in state", AllRecomendations)
  const SelectedRecommendation = state?.persistedReducer?.RecomendationReducer?.selectedRecomendation ?? [];
  // console.log("User selected recomm" , SelectedRecommendation)
  let reData = [] as any[]
  if (SelectedRecommendation?.segmentResponses != null){
    reData.push(SelectedRecommendation.segmentResponses)
    console.log("pushing ReData", SelectedRecommendation?.segmentResponses)
  }
  // console.log("ReData list", reData)
  let reData2 = [] as any[]
   reData.forEach((conectList : any) => {
    console.log("c list", conectList)
    const j = Object.keys(conectList).forEach((name : any) => {
      
    let f = conectList[name].some((cl : any) => cl.type == 1)
    if( f == true){
      const obj = {} as any
      obj[name] = conectList[name]  
      reData2.push(
        obj
      )
    }
    })
  } )

  let reData3 = [] as any[]
  reData.forEach((conectList2 : any) => {
   console.log("c list", conectList2)
   const h = Object.keys(conectList2).forEach((name : any) => {
     
   let g = conectList2[name].some((cl2 : any) => cl2.type == 2)
   if( g == true){
     const obj2 = {} as any
     obj2[name] = conectList2[name]
     reData3.push(
       obj2
     )
   }
   })
 } )
  console.log("ReData list 2", reData3)
  const objectToArray = (obj : any) => Object.assign([], Object.values(obj))
  console.log("object conversion" , reData)
  console.log("testing 123", SelectedRecommendation?.segmentResponses)

  let testData = [] as any[]
  if (SelectedRecommendation?.segmentResponses != null){
    reData2.forEach((a : any) => {
      Object.keys(a).forEach((b : any) => testData.push(b))
    })
    console.log("testing 123", testData)
  }
  let testData2 = [] as any[]
  if (SelectedRecommendation?.segmentResponses != null){
    reData3.forEach((a : any) => {
      Object.keys(a).forEach((b : any) => testData2.push(b))
    })
    console.log("testing 123", testData2)
  }


  // Filtere outputs
  const filteredMark = SelectedRecommendation.segmentResponses?.Market && SelectedRecommendation.segmentResponses?.Market.filter((seg : any) => {
    return seg.value !== "No recommendation" 
  }) 
  console.log("Market list", filteredMark)
  // Customer Segment Filter
  const filteredCus = SelectedRecommendation.segmentResponses?.Customer && SelectedRecommendation.segmentResponses?.Customer.filter((seg : any) => {
    return seg.value !== "No recommendation" && seg.value !== "Job Opportunity Business Research Officer"
  }) 
  const filteredCusJob = SelectedRecommendation.segmentResponses?.Customer && SelectedRecommendation.segmentResponses?.Customer.filter((seg : any) => {
    return seg.value !== "No recommendation" 
  })
//Finance Filters
  const filteredFin = SelectedRecommendation.segmentResponses?.Financial && SelectedRecommendation.segmentResponses?.Financial.filter((seg : any) => {
    return seg.value !== "No recommendation" && seg.value !== "Job Opportunity : BookKeeper"
  }) 
  const filteredFinJob = SelectedRecommendation.segmentResponses?.Financial && SelectedRecommendation.segmentResponses?.Financial.filter((seg : any) => {
    return seg.value !== "No recommendation" 
  }) 
//Market Intelligence
  const filteredMarkInt = SelectedRecommendation.segmentResponses?.MarketInt && SelectedRecommendation.segmentResponses?.MarketInt.filter((seg : any) => {
    return seg.value !== "No Recommendation" && seg.value !== "No recommendation" && seg.value !== "Job Opportunity : Sales personel." && seg.value !== "Job Opportunity : Business Research Officer."
  }) 
   const filteredMarkIntJob = SelectedRecommendation.segmentResponses?.MarketInt && SelectedRecommendation.segmentResponses?.MarketInt.filter((seg : any) => {
    return seg.value !== "No recommendation" 
  }) 
  //Channel
  const filteredChannel = SelectedRecommendation.segmentResponses?.Channel && SelectedRecommendation.segmentResponses?.Channel.filter((seg : any) => {
    return seg.value !== "No recommendation" 
  }) 
  const filteredChannelJob = SelectedRecommendation.segmentResponses?.Channel && SelectedRecommendation.segmentResponses?.Channel.filter((seg : any) => {
    return seg.value !== "No recommendation" && seg.value !== "Job Opportunity : BookKeeper"
  }) 
  const filteredFunctional = SelectedRecommendation.segmentResponses?.Functional && SelectedRecommendation.segmentResponses?.Functional.filter((seg : any) => {
    return seg.value !== "No recommendation" 
  }) 
  const filteredCost = SelectedRecommendation.segmentResponses?.Cost && SelectedRecommendation.segmentResponses?.Cost.filter((seg : any) => {
    return seg.value !== "No recommendation" 
  })
  const filteredBizCust = SelectedRecommendation.segmentResponses?.BusinessCustomers && SelectedRecommendation.segmentResponses?.BusinessCustomers.filter((seg : any) => {
    return seg.value !== "No recommendation" 
  })

  //Filtered Revenue Streams 
  const filteredRev = SelectedRecommendation.segmentResponses?.Revenue && SelectedRecommendation.segmentResponses?.Revenue.filter((seg : any) => {
    return seg.value !== "No recommendation" && seg.value !== "Job Opportunity : Business Strategist"
  })
  const filteredRevJob = SelectedRecommendation.segmentResponses?.Revenue && SelectedRecommendation.segmentResponses?.Revenue.filter((seg : any) => {
    return seg.value !== "No recommendation" 
  })
  const filteredOwner = SelectedRecommendation.segmentResponses?.OwnershipMindset && SelectedRecommendation.segmentResponses?.OwnershipMindset.filter((seg : any) => {
    return seg.value !== "No recommendation" 
  })
  const filteredValue = SelectedRecommendation.segmentResponses?.Value && SelectedRecommendation.segmentResponses?.Value.filter((seg : any) => {
    return seg.value !== "No recommendation" 
  })
  console.log("filter structre", filteredValue)
  const filteredCurrent = SelectedRecommendation.segmentResponses?.CurrentAlternatives && SelectedRecommendation.segmentResponses?.CurrentAlternatives.filter((seg : any) => {
    return seg.value !== "No recommendation" 
  })
  //Partners
  const filteredPartners = SelectedRecommendation.segmentResponses?.Partners && SelectedRecommendation.segmentResponses?.Partners.filter((seg : any) => {
    return seg.value !== "No recommendation" 
  }) 
  const filteredPartnersJob = SelectedRecommendation.segmentResponses?.Partners && SelectedRecommendation.segmentResponses?.Partners.filter((seg : any) => {
    return seg.value !== "No recommendation" && seg.value !== "Job Opportunity : Business Developer"
  })
  const filteredComercial = SelectedRecommendation.segmentResponses?.Commercial && SelectedRecommendation.segmentResponses?.Commercial.filter((seg : any) => {
    return seg.value !== "No recommendation" 
  })
  const filteredTraction = SelectedRecommendation.segmentResponses?.Traction && SelectedRecommendation.segmentResponses?.Traction.filter((seg : any) => {
    return seg.value !== "No recommendation" 
  })
 
  const filteredUnique = SelectedRecommendation.segmentResponses?.Unique && SelectedRecommendation.segmentResponses?.Unique.filter((seg : any) => {
    return seg.value !== "No recommendation" 
  })
  const filteredGrowth = SelectedRecommendation.segmentResponses?.Growth && SelectedRecommendation.segmentResponses?.Growth.filter((seg : any) => {
    return seg.value !== "No recommendation" 
  })
  const filteredBusinessProcess = SelectedRecommendation.segmentResponses?.BusinessProcess && SelectedRecommendation.segmentResponses?.BusinessProcess.filter((seg : any) => {
    return seg.value !== "No recommendation" && seg.value !== "Job Opportunity :  Management & Administration"
  })
  const filteredBusinessProcessJob = SelectedRecommendation.segmentResponses?.BusinessProcess && SelectedRecommendation.segmentResponses?.BusinessProcess.filter((seg : any) => {
    return seg.value !== "No recommendation" 
  })
  const filteredEmployee = SelectedRecommendation.segmentResponses?.Employee && SelectedRecommendation.segmentResponses?.Employee.filter((seg : any) => {
    return seg.value !== "No recommendation" 
  })
  const filteredResources = SelectedRecommendation.segmentResponses?.Resources && SelectedRecommendation.segmentResponses?.Resources.filter((seg : any) => {
    return seg.value !== "No recommendation" 
  })
  const filteredCompliance = SelectedRecommendation.segmentResponses?.Compliance && SelectedRecommendation.segmentResponses?.Compliance.filter((seg : any) => {
    return seg.value !== "No recommendation" 
  })
  const filteredLegal = SelectedRecommendation.segmentResponses?.Legal && SelectedRecommendation.segmentResponses?.Legal.filter((seg : any) => {
    return seg.value !== "No recommendation" 
  })
  // const filteredLegal = SelectedRecommendation.segmentResponses?.Legal && SelectedRecommendation.segmentResponses?.Legal.filter((seg : any) => {
  //   return seg.value !== "No recommendation" 
  // })

  //Pie Logic
  console.log('state HealthReport', state )
  const stateData  = []
  stateData.push(state)
  // console.log("stateData .", stateData)
  const stateDataview  = []
  stateDataview.push(state.persistedReducer)
  // console.log("stateData", stateDataview)
  const reco = []
  reco.push(stateDataview[0].RecomendationReducer)
  // console.log('Recommended', reco)
  const selected = []
  selected.push(reco[0].selectedRecomendation)
  // console.log("selected Recomendation", selected[0]?.segmentResponses)
  let barInfoArray = [] as any[]
  if(selected[0]?.segmentResponses != null){
  barInfoArray = Object.keys(selected[0]?.segmentResponses)
  }
  let barData = [] as any[]
  if (selected[0]?.segmentResponses != null) {
    barData = Object.values(selected[0]?.segmentResponses).map( 
      (data : any) => {
        return data.length          
    // const barInfo = {
    //   data?.map(
        
    // }
      }
      
  )
  }
  
  
  const barKey = barInfoArray.map((name : any, index : number) => ({  name , value : barData[index] }))
  const barkeysProps = {  
    barkeyInfo: barKey
  }


  return (
    <div className='report-con'>
      <DashNav />
      <Container>
        <div className='report'>
          <Grid container>
              <Grid item xs={12} sm={12} md={2} lg={2}>
            </Grid>  
            <Grid item xs={12} sm={12} md={10} lg={10}>
              <img
                src={banner}
                alt='RepBanner'
                className='banner'
              />
              <Typography variant='h3'>Report Summary</Typography>
              <Typography>Company</Typography>
              <div className='pChart'>
                
                <PChart barkeyinfo={barKey} />
              </div>
              <div className='bGraph'>
                <Grid container >
                  <Grid item xs={12} sm={12} md={6} lg={6}>
                    <div className='g1'>
                    <Typography className='g1H' variant='h6'>Business Concept</Typography>
                  {<NewBar />}
                  </div>
                  </Grid>
                  <Grid item xs={12} sm={12} md={6} lg={6}>
                    <div className='g2'>
                      <Typography className='g2H' variant='h6'>Business Structure</Typography>
                    <BarStructure/>
                    </div>               
                    </Grid>
                </Grid>               
              </div>
              <div className='report-accord'>
              <Typography variant='h3'>Full Summary</Typography>
              <div className='accordionGrid'>
              <Typography variant='h5'>Full Report</Typography>
                <Grid container >
                  <Grid item xs={12} sm={12} md={6} lg={6}>
                  <div className='concept'>
                      <Typography
                      variant='h6'
                      >Business Concept</Typography>
                      <Accordion >
                        <AccordionSummary
                          expandIcon={<ExpandMoreIcon />}
                          aria-controls="panel1a-content"
                          id="panel1a-header"
                          className='repoAccord'
                        >
                          
                          <Typography>Business Concept</Typography>
                          </AccordionSummary>
                          <AccordionDetails>
                          <div className='list'>
                            {reData2 && reData2.map((x : any , index1 : number ) => {
                            
                          return (

                            <>
                            
                            { Object.values(x).map((accord : any, index : number) => {
                              const filtered = accord && accord.filter((seg : any) => {
                                return (seg.value == "No recommendation")
                                
                              })
                              console.log("filtered list", filtered)
                            const total = accord?.length
                            const accordPercent = Math.floor(((filtered?.length * 100) / total ))
                              console.log("accord", accordPercent)

                              return (
                                <div key={index}>
                                  
                                  <Accordion>
                                  <AccordionSummary
                                      expandIcon={<ExpandMoreIcon />}
                                      aria-controls="panel1a-content"
                                      id="panel1a-header"
                                      className='repoAccord'
                                    >
                                      <div className='Header'>
                                        <div className='Header1'>
                                        <Typography>{testData[index1]}</Typography>
                                        </div>
                                        <div className='Header2'>
                                        <Typography>{accordPercent}{"%"}</Typography>
                                        </div>
                                      </div>
                                      </AccordionSummary>
                                    <AccordionDetails>
                                    <div className='list'>
                                      {accord.map((list : any, index : number) => {
                                          const recoColor = list.value === "No recommendation" ? "#8FBC8B" : "#FBCEB1";
                                          
                                            return (
                                              <div className='divider' key={index}>
                                              <Accordion>
                                                <AccordionDetails style={{ backgroundColor: recoColor }}>
                                                  {list.key}
                                                </AccordionDetails>
                                              </Accordion>
                                              </div>
                                            )
                                      })}
                                      </div>
                                    </AccordionDetails>
                                  </Accordion>
                                  </div>
                                )
                                    
                            })}
                            </>
                          )
                          
                        
                          } 
                          )
                        }
                          </div>
                            
                            
                            </AccordionDetails>
                      </Accordion >
                      <Typography variant='h5'>Business Diagnosis</Typography>
                      <Accordion >
                        <AccordionSummary
                          expandIcon={<ExpandMoreIcon />}
                          aria-controls="panel2a-content"
                          id="panel2a-header"
                          className='repoAccord'
                        >
                          <Typography >Priority Elements</Typography>
                        </AccordionSummary>
                        <AccordionDetails>
                        <div className='list'>
                            {reData2.map((x : any , index1 : number ) => {
                            
                          return (
                            <>
                            { Object.values(x).map((accord : any, index : number) => {
                              const filtered = accord && accord.filter((seg : any) => {
                                return seg.value == "No recommendation"
                            
                              })
                            const total = accord?.length
                            const accordPercent = Math.floor((filtered?.length * 100) / total )
                          
                            
                            

                                return (
                                  <div key={index}>
                                    <Accordion>
                                    <AccordionSummary
                                        expandIcon={<ExpandMoreIcon />}
                                        aria-controls="panel1a-content"
                                        id="panel1a-header"
                                        className='repoAccord'
                                      >
                                        
                                        <div className='Header'>
                                          <div className='Header1'>
                                          <Typography>{testData[index1]}</Typography>
                                          </div>
                                          <div className='Header2'>
                                          <Typography>{accordPercent}{"%"}</Typography>
                                          </div>
                                        </div>
                                        </AccordionSummary>
                                      <AccordionDetails>
                                      <div className='list'>
                                        {accord.map((list : any, index : number) => {
                                        
                                        const recoColor = list.value === "No recommendation" ? "#8FBC8B" : "#FBCEB1";
                                              return (
                                                <div className='divider' key={index}>
                                                
                                                <Accordion>
                                                  <AccordionDetails style={{ backgroundColor: recoColor }}>
                                                    {list.key}
                                                  </AccordionDetails>
                                                </Accordion>
                                                </div>
                                              )
                                        })}
                                        </div>
                                      </AccordionDetails>
                                    </Accordion>
                                    </div>
                                    
                                  )
                              // }else{
                              //   return null
                              // }
                            
                            
                            })}
                            </>
                          )
                          
                        
                          } 
                          )
                        }
                          </div>
                        </AccordionDetails>
                      </Accordion>

                      <Accordion >
                        <AccordionSummary
                          expandIcon={<ExpandMoreIcon />}
                          aria-controls="panel2a-content"
                          id="panel2a-header"
                          className='repoAccord'
                        >
                          <Typography >Best Performing Areas</Typography>
                        </AccordionSummary>
                        <AccordionDetails>
                        <div className='list'>
                            {reData2.map((x : any , index1 : number ) => {
                            
                          return (
                            <>
                            { Object.values(x).map((accord : any, index : number) => {
                              const filtered = accord && accord.filter((seg : any) => {
                                return seg.value == "No recommendation"
                            
                              })
                            const total = accord?.length
                            const accordPercent = Math.floor((filtered?.length * 100) / total )
                          
                            // if (accord)
                            
                              if(accordPercent >= 60 ){
                                return (
                                  <div key={index}>
                                    <Accordion>
                                    <AccordionSummary
                                        expandIcon={<ExpandMoreIcon />}
                                        aria-controls="panel1a-content"
                                        id="panel1a-header"
                                        className='repoAccord'
                                      >
                                        
                                        <div className='Header'>
                                          <div className='Header1'>
                                          <Typography>{testData[index1]}</Typography>
                                          </div>
                                          <div className='Header2'>
                                          <Typography>{accordPercent}{"%"}</Typography>
                                          </div>
                                        </div>
                                        </AccordionSummary>
                                      <AccordionDetails>
                                      <div className='list'>
                                        {accord.map((list : any, index : number) => {
                                        
                                        const recoColor = list.value === "No recommendation" ? "#8FBC8B" : "#FBCEB1";
                                              return (
                                                <div className='divider' key={index}>
                                                
                                                <Accordion>
                                                  <AccordionDetails style={{ backgroundColor: recoColor }}>
                                                    {list.key}
                                                  </AccordionDetails>
                                                </Accordion>
                                                </div>
                                              )
                                        })}
                                        </div>
                                      </AccordionDetails>
                                    </Accordion>
                                    </div>
                                    
                                  )
                              }else{
                                return null
                              }
                            
                            
                            })}
                            </>
                          )
                          
                        
                          } 
                          )
                        }
                          </div>
                        </AccordionDetails>
                      </Accordion>

                      <Accordion >
                        <AccordionSummary
                          expandIcon={<ExpandMoreIcon />}
                          aria-controls="panel2a-content"
                          id="panel2a-header"
                          className='repoAccord'
                        >
                          <Typography >Major Gaps</Typography>
                        </AccordionSummary>
                        <AccordionDetails>
                        <div className='list'>
                            {reData2.map((x : any , index1 : number ) => {
                            
                          return (
                            <>
                            { Object.values(x).map((accord : any, index : number) => {
                              const filtered = accord && accord.filter((seg : any) => {
                                return seg.value == "No recommendation"
                            
                              })
                            const total = accord?.length
                            const accordPercent = Math.floor((filtered?.length * 100) / total )
                          
                            // if (accord)
                            
                              if(accordPercent < 60 ){
                                return (
                                  <div key={index}>
                                    <Accordion>
                                    <AccordionSummary
                                        expandIcon={<ExpandMoreIcon />}
                                        aria-controls="panel1a-content"
                                        id="panel1a-header"
                                        className='repoAccord'
                                      >
                                        
                                        <div className='Header'>
                                          <div className='Header1'>
                                          <Typography>{testData[index1]}</Typography>
                                          </div>
                                          <div className='Header2'>
                                          <Typography>{accordPercent}{"%"}</Typography>
                                          </div>
                                        </div>
                                        </AccordionSummary>
                                      <AccordionDetails>
                                      <div className='list'>
                                        {accord.map((list : any, index : number) => {
                                        
                                        const recoColor = list.value === "No recommendation" ? "#8FBC8B" : "#FBCEB1";
                                              return (
                                                <div className='divider' key={index}>
                                                
                                                <Accordion>
                                                  <AccordionDetails style={{ backgroundColor: recoColor }}>
                                                    {list.key}
                                                  </AccordionDetails>
                                                </Accordion>
                                                </div>
                                              )
                                        })}
                                        </div>
                                      </AccordionDetails>
                                    </Accordion>
                                    </div>
                                    
                                  )
                              }else{
                                return null
                              }
                            
                            
                            })}
                            </>
                          )
                          
                        
                          } 
                          )
                        }
                          </div>
                        
                        </AccordionDetails>
                      </Accordion>
                      </div>
                  </Grid>
                  <Grid item xs={12} sm={12} md={6} lg={6}>
                  <div className='structure'>
                    <Typography
                      variant='h6'
                      >Business Stucture</Typography>
                      <Accordion >
                        <AccordionSummary
                          expandIcon={<ExpandMoreIcon />}
                          aria-controls="panel1a-content"
                          id="panel1a-header"
                          className='repoAccord'
                        >
                          
                          <Typography>Business Structure</Typography>
                          </AccordionSummary>
                          <AccordionDetails>
                          <div className='list'>
                            {reData3 && reData3.map((x : any , index : number ) => {
                            
                          return (
                            <>
                            { Object.values(x).map((accord : any, index : number) => {
                              const filtered = accord && accord.filter((seg : any) => {
                                return seg.value == "No recommendation"
                            
                              })
                              const Empoylent = accord && accord.filter((seg : any) => {
                                return seg.value == "No recommendation"
                            
                              })
                            const total = accord?.length
                            const accordPercent = Math.floor(((filtered?.length * 100) / total ))
                      

                              console.log("accord", accordPercent)
                              return (
                                <div key={index}>
                                  <Accordion className="str">
                                  <AccordionSummary
                                      expandIcon={<ExpandMoreIcon />}
                                      aria-controls="panel1a-content"
                                      id="panel1a-header"
                                      className='repoAccord'
                                    >
                                      <div className='Header'>
                                        <div className='Header1'>
                                        <Typography>{testData2[index]}</Typography>
                                        </div>
                                        <div className='Header2'>
                                        <Typography>{accordPercent}{"%"}</Typography>
                                        </div>
                                      </div>
                                      
                                      </AccordionSummary>
                                    <AccordionDetails>
                                    <div className='list'>
                                      {accord.map((list : any, index : number) => {
                                          const recoColor = list.value === "No recommendation" ? "#8FBC8B" : "#FBCEB1";
                                          
                                            return (
                                              <div className='divider' key={index}>
                                              <Accordion>
                                                <AccordionDetails style={{ backgroundColor: recoColor }}>
                                                  {list.key}
                                                </AccordionDetails>
                                              </Accordion>
                                              </div>
                                            )
                                      })}
                                      </div>
                                    </AccordionDetails>
                                  </Accordion>
                                  </div>
                                )
                            
                            })}
                            </>
                          )
                          
                        
                          } 
                          )
                        }
                          </div>
                            
                            
                            </AccordionDetails>
                    </Accordion >
                      <Typography variant='h5'>Business Diagnosis</Typography>
                      <Accordion >
                        <AccordionSummary
                          expandIcon={<ExpandMoreIcon />}
                          aria-controls="panel2a-content"
                          id="panel2a-header"
                          className='repoAccord'
                        >
                          <Typography >Priority Elements</Typography>
                        </AccordionSummary>
                        <AccordionDetails>
                        <div className='list'>
                            {reData3.map((x : any , index1 : number ) => {
                            
                          return (
                            <>
                            { Object.values(x).map((accord : any, index : number) => {
                              const filtered = accord && accord.filter((seg : any) => {
                                return seg.value == "No recommendation"
                            
                              })
                            const total = accord?.length
                            const accordPercent = Math.floor((filtered?.length * 100) / total )
                          
                            
                            

                                return (
                                  <div key={index}>
                                    <Accordion className="str">
                                    <AccordionSummary
                                        expandIcon={<ExpandMoreIcon />}
                                        aria-controls="panel1a-content"
                                        id="panel1a-header"
                                        className='repoAccord'
                                      >
                                        
                                        <div className='Header'>
                                          <div className='Header1'>
                                          <Typography>{testData2[index1]}</Typography>
                                          </div>
                                          <div className='Header2'>
                                          <Typography>{accordPercent}{"%"}</Typography>
                                          </div>
                                        </div>
                                        </AccordionSummary>
                                      <AccordionDetails>
                                      <div className='list'>
                                        {accord.map((list : any, index : number) => {
                                        
                                        const recoColor = list.value === "No recommendation" ? "#8FBC8B" : "#FBCEB1";
                                              return (
                                                <div className='divider' key={index}>
                                                
                                                <Accordion>
                                                  <AccordionDetails style={{ backgroundColor: recoColor }}>
                                                    {list.key}
                                                  </AccordionDetails>
                                                </Accordion>
                                                </div>
                                              )
                                        })}
                                        </div>
                                      </AccordionDetails>
                                    </Accordion>
                                    </div>
                                    
                                  )
                              // }else{
                              //   return null
                              // }
                            
                            
                            })}
                            </>
                          )
                          
                        
                          } 
                          )
                        }
                          </div>
                        </AccordionDetails>
                      </Accordion>

                      <Accordion >
                        <AccordionSummary
                          expandIcon={<ExpandMoreIcon />}
                          aria-controls="panel2a-content"
                          id="panel2a-header"
                          className='repoAccord'
                        >
                          <Typography >Best Performing Areas</Typography>
                        </AccordionSummary>
                        <AccordionDetails>
                        <div className='list'>
                            {reData3.map((x : any , index1 : number ) => {
                            
                          return (
                            <>
                            { Object.values(x).map((accord : any, index : number) => {
                              const filtered = accord && accord.filter((seg : any) => {
                                return seg.value == "No recommendation"
                            
                              })
                            const total = accord?.length
                            const accordPercent = Math.floor((filtered?.length * 100) / total )
                          
                            // if (accord)
                            
                              if(accordPercent >= 60 ){
                                return (
                                  <div key={index}>
                                    <Accordion className="str">
                                    <AccordionSummary
                                        expandIcon={<ExpandMoreIcon />}
                                        aria-controls="panel1a-content"
                                        id="panel1a-header"
                                        className='repoAccord'
                                      >
                                        
                                        <div className='Header'>
                                          <div className='Header1'>
                                          <Typography>{testData2[index1]}</Typography>
                                          </div>
                                          <div className='Header2'>
                                          <Typography>{accordPercent}{"%"}</Typography>
                                          </div>
                                        </div>
                                        </AccordionSummary>
                                      <AccordionDetails>
                                      <div className='list'>
                                        {accord.map((list : any, index : number) => {
                                        
                                        const recoColor = list.value === "No recommendation" ? "#8FBC8B" : "#FBCEB1";
                                              return (
                                                <div className='divider' key={index}>
                                                
                                                <Accordion>
                                                  <AccordionDetails style={{ backgroundColor: recoColor }}>
                                                    {list.key}
                                                  </AccordionDetails>
                                                </Accordion>
                                                </div>
                                              )
                                        })}
                                        </div>
                                      </AccordionDetails>
                                    </Accordion>
                                    </div>
                                    
                                  )
                              }else{
                                return null
                              }
                            
                            
                            })}
                            </>
                          )
                          
                        
                          } 
                          )
                        }
                          </div>
                        </AccordionDetails>
                      </Accordion>

                      <Accordion >
                        <AccordionSummary
                          expandIcon={<ExpandMoreIcon />}
                          aria-controls="panel2a-content"
                          id="panel2a-header"
                          className='repoAccord'
                        >
                          <Typography >Major Gaps</Typography>
                        </AccordionSummary>
                        <AccordionDetails>
                        <div className='list'>
                            {reData3.map((x : any , index1 : number ) => {
                            
                          return (
                            <>
                            { Object.values(x).map((accord : any, index : number) => {
                              const filtered = accord && accord.filter((seg : any) => {
                                return seg.value == "No recommendation"
                            
                              })
                            const total = accord?.length
                            const accordPercent = Math.floor((filtered?.length * 100) / total )
                          
                            // if (accord)
                            
                              if(accordPercent < 60 ){
                                return (
                                  <div key={index}>
                                    <Accordion className="str">
                                    <AccordionSummary
                                        expandIcon={<ExpandMoreIcon />}
                                        aria-controls="panel1a-content"
                                        id="panel1a-header"
                                        className='repoAccord'
                                      >
                                        
                                        <div className='Header'>
                                          <div className='Header1'>
                                          <Typography>{testData2[index1]}</Typography>
                                          </div>
                                          <div className='Header2'>
                                          <Typography>{accordPercent}{"%"}</Typography>
                                          </div>
                                        </div>
                                        </AccordionSummary>
                                      <AccordionDetails>
                                      <div className='list'>
                                        {accord.map((list : any, index : number) => {
                                        
                                        const recoColor = list.value === "No recommendation" ? "#8FBC8B" : "#FBCEB1";
                                              return (
                                                <div className='divider' key={index}>
                                                
                                                <Accordion>
                                                  <AccordionDetails style={{ backgroundColor: recoColor }}>
                                                    {list.key}
                                                  </AccordionDetails>
                                                </Accordion>
                                                </div>
                                              )
                                        })}
                                        </div>
                                      </AccordionDetails>
                                    </Accordion>
                                    </div>
                                    
                                  )
                              }else{
                                return null
                              }
                            
                            
                            })}
                            </>
                          )
                          
                        
                          } 
                          )
                        }
                          </div>
                        
                        </AccordionDetails>
                      </Accordion>
                      </div> 
                  </Grid>
                </Grid>
                </div>
              </div>
              <div className='recommendations'>
                <div className="recoContainter">
           

                <Box sx={{ flexGrow: 1 }}>
                <Grid container spacing={6}>
                  <Grid item xs={8}>
                  <CardContent>
                <div className="Heading">Report Recommendations</div>
                  <p>
                  Please share your details if you interested in receiving the learning metarial to help you with the weaknesses
                  in your bussiness or business idea
                </p>
                </CardContent>
                  </Grid>
                  {/* <Grid item xs={4}>
                  <CardContent>
                    
                  <Avatar sx={{ bgcolor: green[500] }} className="logo">
                        </Avatar>
                    <div className='Heading' >
                      Choose Plan
                    </div>
                    <Typography variant="body2">
                     Become a member today and save more than 75%.
                      <br />
                    </Typography>
                  </CardContent>
                  <CardActions>
                    <Button variant="contained">Get Courses</Button>
                  </CardActions> 
                  </Grid> */}
                </Grid>
              </Box>

                <Grid container spacing={2}>
                  <Grid item xs={12} sm={12} md={6} lg={6}>
                   {filteredGrowth?.length > 0 ? <Accordion >
                      <AccordionSummary
                        expandIcon={<ExpandMoreIcon />}
                        aria-controls="panel2a-content"
                        id="panel2a-header"
                        className='arcHeader'
                      >
                       <Avatar sx={{ bgcolor: green[500] }} className="avatorPosition">
                        </Avatar>
                        <div className='sectionHeading'>Strategic Planning</div>
                      </AccordionSummary>
                      <AccordionDetails>
                      <div className='list'>
                          {
                            filteredGrowth?.map(
                              (mark : any) => {
                           
                                return (
                                  <>
                                    <p>{mark.value}</p>
                                  </>
                                )
                              })
                            }
                          
                        </div>
                        </AccordionDetails>
                    </Accordion> : <></>} 
                   {filteredMark?.length > 0 ? <Accordion>
                      <AccordionSummary
                        expandIcon={<ExpandMoreIcon />}
                        aria-controls="panel2a-content"
                        id="panel2a-header"
                      >
                              <Avatar sx={{ bgcolor: green[500] }} className="avatorPosition">
                        </Avatar>
                        <div className='sectionHeading'>Markerting and Sales</div>
                      </AccordionSummary>
                      <AccordionDetails>
                        <div className='list'>
                          {
                            filteredMark?.length == 0 ? 
                            <Typography>No Market and Sales Recomendation</Typography>
                            :
                            filteredMark?.map(
                              (mark : any) => {
                           
                                return (
                                  <>
                                    <p>{mark.value}</p>
                                  </>
                                )
                              })
                            }
                          
                        </div>
                      </AccordionDetails>
                    </Accordion> : <></>}
                 { filteredValue?.length > 0 ?  <Accordion>
                    <AccordionSummary
                      expandIcon={<ExpandMoreIcon />}
                      aria-controls="panel2a-content"
                      id="panel2a-header"
                    >
                          <Avatar sx={{ bgcolor: green[500] }} className="avatorPosition">
                      </Avatar>
                      <div className='sectionHeading'>Product Development</div>
                    </AccordionSummary>
                    <AccordionDetails>
                   <div className="productDev">
                    <div className='list'>
                        {
                          filteredCus?.map(
                            (mark : any) => {
                          
                              return (
                                <>
                                  <p>{mark.value}</p>
                                </>
                              )
                            })
                          }
                        
                      </div>
                    <div className='list'>
                        {
                          filteredValue?.map(
                            (mark : any) => {
                          
                              return (
                                <>
                                  <p>{mark.value}</p>
                                </>
                              )
                            })
                          }
                        
                      </div>
                      </div>
                    </AccordionDetails>
                  </Accordion> : <></>}
                   { filteredFin?.length > 0 ? <Accordion>
                      <AccordionSummary
                        expandIcon={<ExpandMoreIcon />}
                        aria-controls="panel2a-content"
                        id="panel2a-header"

                      >
                            <Avatar sx={{ bgcolor: green[500] }} className="avatorPosition">
                        </Avatar>
                        <div className='sectionHeading'>Financial Managemennt</div>
                      </AccordionSummary>
                      <AccordionDetails>
                      <div className='list'>
                          {
                            filteredFin?.map(
                              (mark : any) => {
                           
                                return (
                                  <>
                                    <p>{mark.value}</p>
                                  </>
                                )
                              })
                            }
                          
                        </div>
                      </AccordionDetails>
                    </Accordion> : <></>}
                   { filteredLegal?.length > 0 ?  <Accordion >
                      <AccordionSummary
                        expandIcon={<ExpandMoreIcon />}
                        aria-controls="panel2a-content"
                        id="panel2a-header"
                      >
                              <Avatar sx={{ bgcolor: green[500] }} className="avatorPosition">
                        </Avatar>
                        <div className='sectionHeading'>Legal + Compliance</div>
                      </AccordionSummary>
                      <AccordionDetails>
                        <Typography>
                        <div className='list'>
                          {
                            filteredLegal?.map(
                              (mark : any) => {
                           
                                return (
                                  <>
                                    <p>{mark.value}</p>
                                  </>
                                )
                              })
                            }
                          
                        </div>
                        <div className='list'>
                          {
                            filteredCompliance?.map(
                              (mark : any) => {
                           
                                return (
                                  <>
                                    <p>{mark.value}</p>
                                  </>
                                )
                              })
                            }
                          
                        </div>

                        </Typography>
                      </AccordionDetails>
                    </Accordion> : <></>}


                  </Grid>
                  <Grid item xs={12} sm={12} md={6} lg={6}>
                    {filteredMarkInt?.length > 0 ?  <Accordion>
                      <AccordionSummary
                        expandIcon={<ExpandMoreIcon />}
                        aria-controls="panel2a-content"
                        id="panel2a-header"
                      >
                         <Avatar sx={{ bgcolor: green[500] }} className="avatorPosition">
                        </Avatar>
                        <div className='sectionHeading'>Market Intelligence</div>
                      </AccordionSummary>
                      <AccordionDetails>
                      <div className='list'>
                          {
                            filteredMarkInt?.map(
                              (mark : any) => {
                           
                                return (
                                  <>
                                    <p>{mark.value}</p>
                                  </>
                                )
                              })
                            }
                          
                        
                        </div>
                      </AccordionDetails>
                    </Accordion> : <></>}

                   {filteredEmployee?.length > 0 ? <Accordion>
                      <AccordionSummary
                        expandIcon={<ExpandMoreIcon />}
                        aria-controls="panel2a-content"
                        id="panel2a-header"
                      >
                         <Avatar sx={{ bgcolor: green[500] }} className="avatorPosition">
                        </Avatar>
                        <div className='sectionHeading'>Talent Management</div>
                      </AccordionSummary>
                      <AccordionDetails>
                    
                      <div className='list'>
                          {
                            filteredEmployee?.length == 0 ? 
                            <Typography>No Talent Management Recomendation</Typography>
                            :
                            filteredEmployee?.map(
                              (mark : any) => {
                           
                                return (
                                  <>
                                    <p>{mark.value}</p>
                                  </>
                                )
                              })
                            }
                          
                        
                        </div>
                      </AccordionDetails>
                    </Accordion> : <></>}

                   { filteredBusinessProcess?.length > 0 ?  <Accordion >
                      <AccordionSummary
                        expandIcon={<ExpandMoreIcon />}
                        aria-controls="panel2a-content"
                        id="panel2a-header"
                      >
                            <Avatar sx={{ bgcolor: green[500] }} className="avatorPosition">
                        </Avatar>
                        <div className='sectionHeading'>Business Process Management</div>
                      </AccordionSummary>
                      <AccordionDetails>
                        <Typography>
                        <div className='list'>
                          {
                            filteredBusinessProcess?.length == 0 ? 
                            <Typography>No Business Process Recomendation</Typography>
                            :
                            filteredBusinessProcess?.map(
                              (bizProcess : any) => {
                           
                                return (
                                  <>
                                    <p>{bizProcess.value}</p>
                                  </>
                                )
                              })
                            }
                          
                        
                        </div>
                        </Typography>
                      </AccordionDetails>
                    </Accordion> : <></>}
             
                  

                  </Grid>

                </Grid>
                <div className='Employment'>
                  <div className='empHead'>
                    <Typography className="empTypo" >
                    The following are professionals you need in order to improve the processes, 
                    systems in your bussiness, as well as bussiness perfomance.
                    </Typography>
                  </div>
                  
                    <Accordion className="employAccord" >
                      <AccordionSummary
                        expandIcon={<ExpandMoreIcon />}
                        aria-controls="panel2a-content"
                        id="panel2a-header"
                      >
                         <Avatar sx={{ bgcolor: green[500] }} className="avatorPosition">
                        </Avatar>
                        <div className='sectionHeading'>Skills required</div>
                      </AccordionSummary>
                <AccordionDetails>
                        <Typography>
                        <div className='list'>
                          {
                            filteredMarkIntJob?.length == 0 ? 
                            <Typography></Typography>
                            :
                            filteredMarkIntJob?.map(
                              (mark : any) => {
                           
                                return (
                                  <>
                                    <p>{mark.value.includes("Job Opportunity") ? mark.value : null}</p>
                                  </>
                                )
                              })
                            }
                          
                        </div>
                        <div className='list'>
                          {
                            filteredCusJob?.length == 0 ? 
                            <Typography></Typography>
                            :
                            filteredCusJob?.map(
                              (mark : any) => {
                           
                                return (
                                  <>
                                    <p>{mark.value.includes("Business Research Officer") ? mark.value : null}</p>
                                  </>
                                )
                              })
                            }
                          
                        </div>
                        <div className='list'>
                          {
                            filteredFinJob?.length == 0 ? 
                            <Typography></Typography>
                            :
                            filteredFinJob?.map(
                              (mark : any) => {
                           
                                return (
                                  <>
                                    <p>{mark.value.includes("Job Opportunity") ? mark.value : null}</p>
                                  </>
                                )
                              })
                            }
                          
                        </div>
                        <div className='list'>
                          {
                            filteredPartnersJob?.length == 0 ? 
                            <Typography></Typography>
                            :
                            filteredPartnersJob?.map(
                              (mark : any) => {
                           
                                return (
                                  <>
                                    <p>{mark.value.includes("Job Opportunity") ? mark.value : null}</p>
                                  </>
                                )
                              })
                            }
                          
                        </div>
                        
                        <div className='list'>
                          {
                            filteredRevJob?.length == 0 ? 
                            <Typography></Typography>
                            :
                            filteredRevJob?.map(
                              (mark : any) => {
                           
                                return (
                                  <>
                                    <p>{mark.value.includes("Job Opportunity") ? mark.value : null}</p>
                                  </>
                                )
                              })
                            }
                          
                        </div>
                        <div className='list'>
                          {
                            filteredBusinessProcessJob?.length == 0 ? 
                            <Typography></Typography>
                            :
                            filteredBusinessProcessJob?.map(
                              (mark : any) => {
                           
                                return (
                                  <>
                                    <p>{mark.value.includes("Job Opportunity") ? mark.value : null}</p>
                                  </>
                                )
                              })
                            }
                          
                        </div>
                        </Typography>
                      </AccordionDetails>
                    </Accordion>
                 
                
                </div>

                </div>
               

                <div className="Bspace">
                <Barspace/>
              </div>
              </div>
              
            </Grid>
          </Grid>


        </div>
        <div className='foot'>
          <Footernew />
        </div>
      </Container>
    </div>
  )


}

export default Report
