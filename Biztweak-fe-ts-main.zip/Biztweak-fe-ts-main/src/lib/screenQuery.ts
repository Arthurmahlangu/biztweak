
const mobileWidth = 640;
const tabletPortraitWidth = 820;
const tabletWidth = 1200;
const smallPCWidth = 1320;
interface IScreenDimensions{
  width:number,
  height:number
}
export function getWindowDimensions(): IScreenDimensions {
  const hasWindow = typeof window !== 'undefined';
  const width = hasWindow ? window.innerWidth : 1024;
  const height = hasWindow ? window.innerHeight : 2000;
  return {
    width,
    height,
   }as IScreenDimensions;
}

export function isMobile():boolean{
  const dimensions = getWindowDimensions();
  return dimensions.width < mobileWidth;
}
export function isTabletPortrait():boolean{
  const dimensions = getWindowDimensions();
  return dimensions.width >= tabletPortraitWidth  && dimensions.width<tabletWidth ;
}
export function isTablet():boolean{
  const dimensions = getWindowDimensions();
  return dimensions.width > tabletPortraitWidth && dimensions.width<tabletWidth ;
}

export function isPC():boolean{
  const dimensions = getWindowDimensions();
  return dimensions.width>smallPCWidth
}


export function isSmallPC():boolean{
  const dimensions = getWindowDimensions();
  return dimensions.width> tabletWidth && dimensions.width< smallPCWidth;
}

