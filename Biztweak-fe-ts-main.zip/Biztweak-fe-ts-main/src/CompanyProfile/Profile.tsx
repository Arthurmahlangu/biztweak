import React, { useState } from "react";
import {
    Grid,
    Container,
    Typography, 
    TextField,
    Button
}
    from "@material-ui/core";
import UserNavbar from "../components/UserNav/UserNav";
import { Api } from '../services/endpoints';
import './Profile.css';
import Footernew from "../components/Footer/Footernew";
import { ICompany } from "src/Interfaces/IRecomendation";
import { Link, useLocation } from "react-router-dom";
import CloudUploadIcon from '@material-ui/icons/CloudUpload';
import Icon from '@material-ui/core/Icon';
import { supabase } from "../supabaseClient";
import { makeStyles, createStyles, Theme } from '@material-ui/core/styles';
// import Button from '@material-ui/core/Button';
import IconButton from '@material-ui/core/IconButton';
import PhotoCamera from '@material-ui/icons/PhotoCamera';
import { isMobile } from "../lib/screenQuery"
import Autocomplete from "react-google-autocomplete";
// import MapboxAutocomplete from "react-mapbox-autocomplete";

var _isMobile = isMobile();
const linkStyle = {
    margin: "1rem",
    textDecoration: "none",
    marginTop: "5%"
};
const useStyles = makeStyles((theme: Theme) =>
    createStyles({
        root: {
            '& > *': {
                margin: theme.spacing(1),
            },
        },
        input: {
            display: 'none',
        },
    }),
);
type LocationState = {
	bizInd: Array <{
	  value: number;
	  label: string
	}>, 
	bizPhase: Array<{
	  value: number;
	  label: string
	}>
  }

const Profile = () => {
    const location = useLocation();
    const bizInd = (location.state as LocationState)?.bizInd;
	const bizPhase = (location.state as LocationState)?.bizPhase;
    const [companyName, setCompanyName] = useState<string>("");
    const [logo, setLogo] = useState([]);
    const [phase, setPhase] = useState<string>("");
    const [registered, setRegistered] = useState<string>("no");
    const [registerNum, setRegisterNum] = useState<string>("");
    const [registerDate, setRegisterDate] = useState<Date>();
    const [locationS, setLocation] = useState<string>("");
    const [employees, setEmployees] = useState<number>(0);
    const [annTurnover, setAnnTurnover] = useState<number>(0);
    const [monTurnover, setMonTurnover] = useState<number>(0);
    const [industry, setIndustry] = useState<string>();
    const [product, setProduct] = useState<string>();
    const [longitude, setLongitude] = useState('');
    const [latitude, setLatitude] = useState('');
    const [placeAddress, setPlaceAddress] = useState('');

    const classes = useStyles();

 let action = "action";

  const createProfile = async () =>{

    const user = supabase.auth.user()
    const _user = user?.id
    const ind = bizInd[0]?.label && bizInd[0]?.label
    const ph = bizPhase[0]?.label && bizPhase[0]?.label
    console.log("industry", ind)
console.log("Phase", ph)
    // locationS = gps:{lat:latitude,
    //     long: longitude
    //   },    
    //  address:placeAddress
    console.log("testing 123")
    const payload = {
    "userId" : _user,
     "companyName": companyName,
     "location":locationS,
     "phase" : ph,
     "industry" : ind,
     "employees" : employees,
     "registered" : registered,
     "registrationNumber" : registerNum,
     "registrationDate" : registerDate, 
     "monTurnover" : monTurnover,
     "annTurnover" : annTurnover,
     "product" : product,
    //  "action": action,
   } as ICompany
   console.log('Result is' , payload) 
     const result = await Api.POST_CreateCompany(payload)
     console.log("company profile", result)
   } 
   async function uploadLogo(event : any) {
    const logoFile = event.target.files[0]
    const mineType = logoFile.type;
    const ext = mineType.replace('image/png')
    const { data, error } = await supabase
      .storage
      .from('logo')
      .upload(`${new Date().getTime()}.${ext}`, logoFile, {
        cacheControl: '3600',
        upsert: false
      })
      if (error) {
              alert('Could not upload your logo, please try again');
            } else {
                alert('Logo Uploaded');
            }
            console.log("image file",data)
}

    const create = () => {
        createProfile();

    }



//   const handleRegistered = (event: React.ChangeEvent<HTMLInputElement>) => {
//     console.log("testing")
//     setRegistered((event.target as HTMLInputElement).value);
//     console.log('it works', registered)
//   };

    
    return (
        <div className="profile-con">
            <UserNavbar />
            <Container>
                <div className="profile-grid">
                    <Grid container>
                        <Grid item xs={12} sm={12} md={2} lg={2}>
                            {/* <div className='profileInfo'>
                                <Typography>Profile</Typography>
                                <img
                                    src={avatar}
                                    alt='avimage'
                                    className='avImg'
                                    />
                                <Typography>John Smith</Typography>
                                <Divider/>
                                <div className='conInfo'>
                                    <Typography>JohnSmith@gmail.com</Typography>
                                    <p>
                                    2009 MA in English Literature
                                    Harvard University, Cambridge, MA
                                    3.7 GPA
                                    </p>
                                </div>
                            </div> */}
                            {/* <Button variant='outlined' className='btnCompany2'>
                                    + Add Company
                            </Button> */}
                        </Grid>
                        <Grid item xs={12} sm={12} md={10} lg={10}>
                            <h5 className='poptypo' style={{ fontSize: _isMobile ? "" : "30px" }}>
                                Complete Company Profile
                            </h5>
                            <div className="companyName">
                                <>
                                    {!_isMobile && <Typography>Company Name</Typography>}
                                    <TextField
                                        style={{ width: _isMobile ? "100%" : "65%" }}
                                        // variant="outlined"
                                        className="comName"
                                        label="Company name"
                                        onChange={(e) => setCompanyName(e.target.value)}
                                        size="small"
                                    />
                                </>
                            </div>
                            <div className="companyLogo" style={{ marginTop: _isMobile ? "10px" : "" }}>
                                <Typography>Company Logo</Typography>
                                <div className="uplaodBtn">
                                    <input
                                        style={{ width: _isMobile ? "100%" : "65%" }}
                                        accept="image/*"
                                        className={classes.input}
                                        id="contained-button-file"
                                        multiple
                                        type="file"
                                        onChange={uploadLogo}
                                    />
                                    <label htmlFor="contained-button-file">
                                        <Button variant="contained" color="primary" component="span">
                                            Upload
                                        </Button>
                                    </label>
                                    <input accept="image/*" className={classes.input} id="icon-button-file" type="file" />
                                    <label htmlFor="icon-button-file">
                                        <IconButton color="primary" aria-label="upload picture" component="span">
                                            <PhotoCamera />
                                        </IconButton>
                                    </label>
                                </div>
                            </div>

                            {/* <div className="registered"> */}
                            <div className="registered">
                                <Typography>Is Your company registered?</Typography>
                                <div className="radio-control">
                                <div className="radio-btn-container">
                                    <div
                                    className="radio-btn"
                                    onClick={() => {
                                        setRegistered("yes")
                                    }}
                                    >
                                    <input
                                        type="radio"
                                        value={registered}
                                        name="yes"
                                        checked={registered == "yes"}
                                    />
                                    Yes
                                    <div className="regNum">
                                    {registered == "yes" ? 
                                    <div className="companyIn" style={{ marginLeft: _isMobile ? "16%" : "" }}>
                                {!_isMobile && <Typography className="indTypon">Registration Number</Typography>}
                                <div className="rNumber">
                                <TextField
                                    style={{ width: _isMobile ? "100%" : "65%" }}
                                    // variant="outlined"
                                    className="rn"
                                    label="Registration number"
                                    onChange={(e) => setRegisterNum(e.target.value)}
                                    size="small"
                                />
                                </div>
                            </div>
                            : null
                            }
                            </div>
                            <div className="regDate">
                            {registered == "yes" ? 
                            <div className="companyIn" style={{ marginLeft: _isMobile ? "16%" : "" }}>
                                {!_isMobile && <Typography className="indTypod">Registration Date</Typography>}
                                <div className="dateR">
                                <input
                                    style={{ width: _isMobile ? "100%" : "65%" }}
                                    type="date"
                                    className="datep"
                                    // label="Registration Date"
                                    onChange={(e) => {
                                            try
                                            {
                                                const date = new Date(e.target.value)
                                                setRegisterDate(date)
                                            }catch{

                                            }
                                        }
                                    }
                                    // size="small"
                                />
                            </div>
                            </div>
                            : null
                            }
                            </div>
                                    </div>
                                    <div
                                    className="radio-btn"
                                    onClick={() => {
                                        setRegistered("no")
                                    }}
                                    >
                                    <input
                                        type="radio"
                                        value={registered}
                                        name="no"
                                        checked={registered == "no"}
                                    />
                                    No
                                    </div>
                                   
                                </div>
                                </div>
                                </div>
                            <div className="sort">
                                {!_isMobile && <Typography>Company Location</Typography>}
                                <div className="companyLocation">
                                    <Autocomplete
                                       apiKey={"AIzaSyAh4YQ9kbOGczVboOpEwcCqSSgH8KmvZl0"}
                                       onPlaceSelected={(place) => {
                                         console.log(place);
                                       }}
                                       options={{
                                        types: ["(Regions)"],
                                        componentRestrictions: { country: "ZA" },
                                      }}
                                       
                                    />;
                                </div>
                                {!_isMobile && <Typography>Number of employees</Typography>}
                                <div className="numEmployees">

                                    <TextField
                                        style={{ width: _isMobile ? "100%" : "65%" }}
                                        
                                        className="comName"
                                        placeholder="Number of employees at your company..."
                                        onChange={(e) => setEmployees(Number(e.target.value))}
                                        label="Number of employees"
                                        size="small"
                                    />
                                </div>
                                {!_isMobile && <Typography>Annual Turnover</Typography>}
                                <div className="annualTurnover">

                                    <TextField
                                        style={{ width: _isMobile ? "100%" : "65%" }}
                                     
                                        className="annTurn"
                                        placeholder="What is your yearly turnover..." name="annual_turnover"
                                        label="Annual Turnover"
                                        onChange={(e) => setAnnTurnover(Number(e.target.value))}
                                        size="small"
                                    />
                                </div>
                                {!_isMobile && <Typography>Monthly Turnover (6 months)</Typography>}
                                <div className="turnover">

                                    <TextField
                                        style={{ width: _isMobile ? "100%" : "65%" }}
                                      
                                        className="annTurn"
                                        placeholder="What was your monthly turnover in the past 6 months..."
                                        label="Monthly Turnover"
                                        onChange={(e) => setMonTurnover(Number(e.target.value))}
                                        size="small"
                                    />
                                </div>
                                {!_isMobile && <Typography>Products/Services</Typography>}
                                <div className="Products">

                                    <TextField
                                        style={{ width: _isMobile ? "100%" : "65%" }}
                                   
                                        className="annTurn"
                                        label="Products"
                                        size="small"
                                        onChange={(e) => setProduct(e.target.value)}
                                        placeholder="What products or services is your company offering?"
                                    />
                                </div>
                                <Link to='/HealthR' style={linkStyle}>
                                    <Button
                                        style={{ marginTop: "10%" }}
                                        variant='outlined'
                                        className='btnProfSave'
                                        onClick={() => create()}
                                    >
                                        Save
                                    </Button>
                                </Link>
                            </div>


                        </Grid>
                    </Grid>
                </div>
            </Container>
            <div className="footProf">
                <Footernew />
            </div>
        </div>

    )
}

export default Profile

