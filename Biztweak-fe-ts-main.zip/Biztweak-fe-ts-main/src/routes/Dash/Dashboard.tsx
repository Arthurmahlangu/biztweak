import React, { useState } from 'react';
import { Container, MenuItem } from '@material-ui/core';
import { Grid, Typography, Button, Divider } from '@material-ui/core';
import Dialog from '@material-ui/core/Dialog';
import DialogActions from '@material-ui/core/DialogActions';
import DialogContent from '@material-ui/core/DialogContent';
import DialogContentText from '@material-ui/core/DialogContentText';
import DashNav from '../../components/DasNav/Nav';
import dash from '../../Images/Dash.png'
import avatar from '../../Images/avatar.png'
import pop1 from '../../Images/pop1.png'
import pop2 from '../../Images/pop2.png'
import Select from '@material-ui/core/Select';
import { Link } from 'react-router-dom'
import { useNavigate } from 'react-router-dom';
import Footernew from '../../components/Footer/Footernew';
import './Dashboard.css'
import { useDispatch } from 'react-redux';
import { setSelectedRecomendation } from "../../Slice/createSlice";
import { isMobile } from '../../lib/screenQuery';
import AccessmentAccordion from '../../components/AssessmentsAccordion/AccessmentsAccordion';
const _isMobile = isMobile();

const linkStyle = {
    margin: "1rem",
    textDecoration: "none",

};
const dropStyle = {
    minWidth: "200px",
    width: _isMobile ? "40%" : "70%"
}

const Dashboard = () => {
    const [open, setOpen] = React.useState(false);
    const navigate = useNavigate();

    const dispatch = useDispatch();

    const [bizIndlist, setBizindlist] = useState([
        { value: 0, label: 'Please Select Industry' },
        { value: 1, label: 'Admin/ Business support' },
        { value: 2, label: 'Agrigulture,Forestry and hunting' },
        { value: 3, label: 'Arts, Entertainment and Recreation' },
        { value: 4, label: 'Construstion' },
        { value: 5, label: 'Education' },
        { value: 6, label: 'Finance and Insurance' },
        { value: 7, label: 'Healthcare and Social assistance' },
        { value: 8, label: 'Hospitality' },
        { value: 9, label: 'Information Technology' },
        { value: 10, label: 'Manufacturing' },
        { value: 11, label: 'Mining and Mineral Processing' },
        { value: 12, label: 'Professional, Scientific and Technical service' },
        { value: 13, label: 'Real Estate' },
        { value: 14, label: 'Retail/ Fasion' },
        { value: 15, label: 'Transport and Logistics' },
        { value: 16, label: 'Other' },
    ])
    const [bizPhaseList, setBizPhaseList] = useState([
        { value: 1, label: 'Please Select phase' },
        { value: 2, label: 'I want to sell' },
        { value: 3, label: 'I want to learn how to find customers' },
        { value: 4, label: 'I want to learn how to fundraise' },
        { value: 5, label: 'I have a business but am not making money' },
        { value: 6, label: <span>I have an idea, <br /> but don’t know what to do next</span > },
        { value: 7, label: <span>I have products/ services, <br /> but I have poor sales</span > },
        {
            value: 8, label: <span>We are generating revenue, <br /> we would like to grow through investment</span>
        },
        { value: 9, label: <span>I would like to be an entrepreneur, <br />  but don’t know where to start</span> },
    ])

    const [bizInd, setBizind] = useState<string>('')
    const [bizPhase, setBizPhase] = useState<string>('')

    const NavigateFunc = () => {

        dispatch(setSelectedRecomendation({}));

        if (bizPhase == '2') {
            navigate('/AssesSales', { state: { bizInd: bizIndlist.filter(x => x.value === parseInt(bizInd)), bizPhase: bizPhaseList.filter(x => x.value === parseInt(bizPhase)) } });
        } else if (bizPhase == '3') {
            navigate('/Customer', { state: { bizInd: bizIndlist.filter(x => x.value === parseInt(bizInd)), bizPhase: bizPhaseList.filter(x => x.value === parseInt(bizPhase)) } });
        } else if (bizPhase == '4') {
            navigate('/Funding', { state: { bizInd: bizIndlist.filter(x => x.value === parseInt(bizInd)), bizPhase: bizPhaseList.filter(x => x.value === parseInt(bizPhase)) } });
        }
        else if (bizPhase == '5') {
            navigate('/NoMoney', { state: { bizInd: bizIndlist.filter(x => x.value === parseInt(bizInd)), bizPhase: bizPhaseList.filter(x => x.value === parseInt(bizPhase)) } });
        }
        else if (bizPhase == '6') {
            navigate('/Concept', { state: { bizInd: bizIndlist.filter(x => x.value === parseInt(bizInd)), bizPhase: bizPhaseList.filter(x => x.value === parseInt(bizPhase)) } });
        } else if (bizPhase == '7') {
            navigate('/Poor', { state: { bizInd: bizIndlist.filter(x => x.value === parseInt(bizInd)), bizPhase: bizPhaseList.filter(x => x.value === parseInt(bizPhase)) } });
        }
        else if (bizPhase == '9') {
            navigate('/StartUp', { state: { bizInd: bizIndlist.filter(x => x.value === parseInt(bizInd)), bizPhase: bizPhaseList.filter(x => x.value === parseInt(bizPhase)) } });
        }
        else if (bizPhase == '8') {
            navigate('/Investment', { state: { bizInd: bizIndlist.filter(x => x.value === parseInt(bizInd)), bizPhase: bizPhaseList.filter(x => x.value === parseInt(bizPhase)) } });
        }
        console.log('BizPhase is =', bizPhase)
        console.log('BizPhase is =', bizInd)
    }

    const handleClickOpen = () => {
        setOpen(true);
    };

    const handleClose = () => {
        setOpen(false);
    };

    const _isMobile = isMobile();

    return (
        <>
            <div className='Dash-con'>
                <DashNav />
                <Container>
                    <div>
                        <Grid container >
                            <Grid item xs={12} sm={12} md={4} lg={4}>
                                <AccessmentAccordion setSelectedRecommedation={false} />
                                <div className='Dash1'>
                                    {!_isMobile && <Button variant='outlined' className='btnCompany2' onClick={handleClickOpen}>
                                        + Add Company
                                    </Button>
                                    }
                                </div>
                            </Grid>
                            <Grid item xs={12} sm={12} md={8} lg={8}>
                                <img
                                    src={dash}
                                    alt='dashimage'
                                    className='dashImg'
                                    style={{ marginLeft: _isMobile ? "5%" : "10%", marginTop: _isMobile ? "10%" : "" }}
                                />
                                {/* <Button
                                    variant='outlined'
                                    className='btnCompany'
                                    onClick={handleClickOpen}
                                    style={{ marginLeft: "10%"}}
                                >
                                    + Add Company
                                </Button> */}
                                <Button
                                    className='profAdd'
                                    variant='outlined'
                                    onClick={handleClickOpen}
                                    style={{ marginLeft: _isMobile ? "10%" : "" }}
                                >
                                    + Add Company
                                </Button>
                            </Grid>

                        </Grid>

                    </div>
                </Container>
                {/*******************
             * Add pop up
             * ******************* */}
                <div className='DashPop'>
                    <Dialog
                        open={open}
                        onClose={handleClose}
                        aria-labelledby="alert-dialog-title"
                        aria-describedby="alert-dialog-description"
                    >
                        {/* <DialogTitle id="alert-dialog-title">{"Use Google's location service?"}</DialogTitle> */}
                        <DialogContent>
                            <DialogContentText id="alert-dialog-description">
                                <img
                                    src={pop1}
                                    alt='pop1image'
                                    className='pop1Img'
                                    style={{ maxWidth: _isMobile ? "250px" : "" }}
                                />
                                <img
                                    src={pop2}
                                    alt='pop2image'
                                    className='pop2Img'
                                    style={{ maxWidth: _isMobile ? "250px" : "", maxHeight: _isMobile ? "200px" : "" }}
                                />
                                {/* <Typography className='bizIndustry'>Business Industry</Typography> */}
                                <div style={{ minWidth: "100%", left: "0px", marginTop: _isMobile ? "20%" : "10%" }}>
                                    <Typography className='bizIndustry'>Business Industry</Typography>
                                    <Select
                                        className='dropdownItem'
                                        onChange={(e: any) => { setBizind(e.target.value as string) }}
                                        style={dropStyle}
                                    >

                                        {
                                            bizIndlist?.map((bizInd) => (
                                                // <option value={bizInd.value}>{bizInd.label}</option>
                                                <MenuItem value={bizInd.value}>{bizInd.label}</MenuItem>
                                            ))
                                        }
                                    </Select>
                                </div>
                                {/*  */}
                                <div style={{ minWidth: "100%", left: "0px", marginTop: "5%" }}>
                                    <Typography className='bizIndustry'>Business Phase</Typography>
                                    <Select
                                        labelId="demo-simple-select-label"
                                        id="demo-simple-select"

                                        label="Business Phase"
                                        onChange={(e: any) => { e && setBizPhase(e.target.value as string) }}
                                        style={dropStyle}
                                    >
                                        {/* <select
                                            className='dropdownItem2'

                                            style={dropStyle}

                                        > */}

                                        {
                                            bizPhaseList?.map((bizPhase) => (
                                                // <option value={bizPhase.value}>{bizPhase.label}</option>
                                                <MenuItem value={bizPhase.value}>{bizPhase.label}</MenuItem>
                                            ))
                                        }
                                    </Select>
                                </div>
                            </DialogContentText>
                        </DialogContent>
                        <DialogActions>

                            <Button
                                className='popSave'
                                variant='outlined'
                                onClick={(e) => NavigateFunc()}
                            >
                                Save

                            </Button>
                        </DialogActions>
                    </Dialog>
                </div>

            </div >
            <div>
                <Footernew />
            </div>

        </>
    )


}

export default Dashboard;