import React, { useState } from 'react';
import Grid from '@material-ui/core/Grid';
import { Link } from 'react-router-dom';
import Typography from '@material-ui/core/Typography';
import TextField from '@material-ui/core/TextField';
import signin from '../Images/signin.png';
import Container from '@material-ui/core/Container';
import Checkbox from '@material-ui/core/Checkbox';
import Button from '@material-ui/core/Button';
import Navbar from '../components/Navbar/Navbar';
import { supabase } from '../supabaseClient';
import { useNavigate } from 'react-router-dom';
import Footernew from '../components/Footer/Footernew';
// import cookie from 'cookiejs';
import '../Login/Login.css';
import { isMobile } from '../lib/screenQuery';
// import { sign } from 'crypto';
const _isMobile = isMobile();

const linkStyle = {
	margin: "1rem",
	textDecoration: "none",
	color: 'black'
};


const Login = () => {
	// const [ loading, setLoading ] = useState(false);
	const [email, setEmail] = useState('');
	const [password, setPassword] = useState('');
	const navigate = useNavigate();

	const signIn = async () => {

		const { user, session, error } = await supabase.auth.signIn({
			email: email,
			password: password,
		})
		if (error) {
			alert(error.message);
			return;
		}
		return user
	}

	const getUserData = async (user: any) => {
		const { data, error } = await supabase
			.from('profile')
			.select(`
	                id, display_name, Role
	            `)
			.eq('id', user.id)
		const role = data && data[0]?.Role
		console.log('role number', role, user)
		try {
			if (role === 1) {
				navigate('/Dashboard');

			} else if (role === 2) {
				navigate('/AdminDash');

			}
		} catch (error) {
			console.log(error);
		}
		return data
	}

	const runFunctions = async () => {
		const user = await signIn();
		if (user) {
			getUserData(user);
		}
	}


	return (
		<div className="login-container">
			<Navbar />
			<Container maxWidth="sm">
				<Grid container>
					<Grid item xs={12} sm={12} md={5} lg={5}>
						<div className="imagegrid">
							<img src={signin} alt="signin" className="signinIMG" />
						</div>
					</Grid>
					<Grid item xs={12} sm={12} md={7} lg={7}>
						<div className="loginForm" style={{ padding: _isMobile ? "35px 0px" : "20px", left: _isMobile ? "10px" : "", maxWidth: _isMobile ? "100%" : "" }}>
							<div className="formTypo" style={{ fontFamily: "Rockwell !important" }}>
								<Typography className="loginHeading" variant="h3" style={{ margin: _isMobile ? "" : "15px", fontFamily: "Rockwell !important" }}>
									Login Account
								</Typography>
							</div>
							<p className='bodyText' style={{ margin: _isMobile ? "" : "15px" }}>
								Follow the instructions to make it easier to login and you will be able to explore
								inside.
							</p>
							<div className="input1" style={{ margin: _isMobile ? "" : "10px" }}>
								<TextField
									id="filled-basic"
									label="Email Address"
									variant="filled"
									fullWidth
									value={email}
									onChange={(e) => setEmail(e.target.value)}
								/>
							</div>
							<div className="input1" style={{ margin: _isMobile ? "" : "10px" }}>
								<TextField
									id="outlined-password-input"
									label="Password"
									type="password"
									autoComplete="current-password"
									fullWidth
									variant="filled"
									onChange={(e) => setPassword(e.target.value)}
								/>
							</div>
							<div className="checkP" style={{ marginTop: _isMobile ? "" : "25px" }}>
								<div className="checkBox">
									<Checkbox inputProps={{ 'aria-label': 'uncontrolled-checkbox' }} />
								</div>
								<div className="chackPara" style={{ fontSize: "small" }}>
									<p>Keep me logged in</p>
								</div>
							</div>
							<Button variant="outlined" className="Btnlogin" style={{ marginTop: _isMobile ? "" : "10px" }} onClick={() => runFunctions()}>
								Login
							</Button>
							<div className="forgotLinks" style={{ left: _isMobile ? "12em" : "" }}>
								<div className="forgotPass" style={{ marginTop: _isMobile ? "" : "10px" }}>
									<Link to="/Forgot" className='forgotp' style={{ color: 'silver', fontSize: "small" }}>Forgot Password?</Link>
								</div>
								<div className="noAcc" style={{ marginTop: _isMobile ? "" : "30px", left: _isMobile ? "2em" : "" }}>
									<Link to="/sign_up" className='noAccess' style={{ color: 'black', fontSize: "small" }}>Don't have an account <span style={{ color: 'blue' }} >Sign up</span>?</Link>
								</div>
							</div>
						</div>
					</Grid>
				</Grid>

			</Container>
			<div className='footsi'>
				<Footernew />
			</div>
		</div >
	);
};

export default Login;
