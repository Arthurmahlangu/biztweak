import React , { useState , useEffect } from "react";
import {BrowserRouter as Router  , Routes, Route} from 'react-router-dom'
import { supabase } from './supabaseClient'
import Home from './routes/Home'
import Blog from './routes/Blog'
import AboutPage from './routes/About';
import Login from './routes/SignIn';
import Register from './routes/Register';
import Dashboard from "./routes/Dash/Dashboard";
import Profile from "./CompanyProfile/Profile";
import AssessBasic from "./components/Assesment/AssesSales";
import Report from "./components/Report/Report";
import Getcourse from "./components/Course/Getcourse"
import Coursepage from "./components/Course/Coursepage"
import Forgot from "./components/forgot/Forgot";
import Admin from "./Admin/AdminDash";
import AdminAllAsses from "./Admin/AdminAllAsses";
import List from "./Admin/List";
import AddAdmin from "./Admin/AddAdmin";
import AddUser from "./Admin/AdminComponents/AddUser/AddUser";
import AdminMail from "./Admin/AdminMail";
import AdminAdd from "./Admin/AdminAdd";
import AdminMailFull from "./Admin/AdminMailFull";
import AdminUserList from "./Admin/AdminUserList";
import AdminRole from "./Admin/AdminRole";
import SendMail from "./Admin/AdminComponents/SendMail/SendMail";
import AllAsses from "./Admin/AdminComponents/AllAsses/AllAsses";
import Funding from "./components/Assesment/Funding/Funding";
import Customer from "./components/Assesment/Customer/Customer";
import AdminFull from "./Admin/AddMinFull";
import HealthReport from "./components/Assesment/HealthReport/HealthReport";
import HealthReportFin from "./components/Assesment/HealthReport/HealthR";
import PoorSales from "./components/Assesment/Poor/Poor";
import Concept from "./components/Assesment/Concept/Concept";
import NoMoney from "./components/Assesment/NoMoney/NoMoney";
import Investment from "./components/Assesment/Investment/Investment";
import PChart from "./components/Report/PieChart";
import NewBar  from "./components/Report/BarChart";
import BarStructure from "./components/Report/BarStructure";
import ConceptBar from "./Admin/AdminComponents/Charts/Bar";
import StructureBar from "./Admin/AdminComponents/Charts/Bar2";
import './Login/Login.css'
import SellFilter from "./Filters/SellFilter/SellFilter";
import IdeaConcept from "./Filters/IdeaConcept/IdeaConcept";
import EarlyStage from "./Filters/EarlyStage/EarlyStage";
import FundingFilter from "./Filters/FundingFilter/FundingFilter";
import CustomerFilter from "./Filters/CustomerFilter/CustomerFilter";
import StartUp from "./Filters/StartUp/StartUp";
import Accelerate from "./Filters/Accelerate/Accelerate";
import Structure from "./Admin/AdminComponents/Charts/structure";
import UserList from "./Admin/AdminComponents/featuredInfo/UserList";
import BootstrapBlog from "./components/Posts/FullArticle/HowToBootstrap";
import CrowdFunding from "./components/Posts/FullArticle/crowdFunding";
import FiveTips from "./components/Posts/FullArticle/FiveTips";
import CommonMistakes from "./components/Posts/FullArticle/CommonMistakes";
import Post from "./components/Posts/Post/Post";
import SearchResult from "./Admin/AdminComponents/SearchPage/SearchResults";


import './Login/Login.css'
import AdminCompany from "./Admin/AdminCompany";
import UserSendMail from "./Admin/AdminComponents/UserSendMail/UserSendMail";
import UserAdminMail from "./Admin/UserAdminMail";


function App() {
  

  
  return (
    <div className="App">
      
      <Router>
        <Routes>
          <Route path='/' element={<Home />} />
          <Route path='/About' element={< AboutPage />} />
          <Route path='/sign_up' element={<Register />} /> 
          <Route path='/login' element={<Login />} />
          <Route path='/Post' element={<Post />} /> 
          <Route path='/Dashboard' element={<Dashboard />} />
          <Route path='/Profile' element={<Profile />} />
          <Route path='/Report' element={<Report />} />
          <Route path='/AssesSales' element={<AssessBasic />} />
          <Route path='/Getcourse' element={<Getcourse />} />
          <Route path='/Coursepage' element={<Coursepage />} />
          <Route path='/Forgot' element={<Forgot />} />
          <Route path='/AdminDash' element={<Admin />} />
          <Route path='/AdminDash/Company/:id' element={<AdminCompany />} />
          <Route path='/AdminAllAsses' element={<AdminAllAsses />} />
          <Route path='/SellFilter' element={<SellFilter />} />
          <Route path='/FundingFilter' element={<FundingFilter />} />
          <Route path='/CustomerFilter' element={<CustomerFilter />} />
          <Route path='/IdeaConcept' element={<IdeaConcept />} />
          <Route path='/EarlyStage' element={<EarlyStage />} />
          <Route path='/StartUp' element={<StartUp />} />
          <Route path='/Accelerate' element={<Accelerate />} />
          <Route path='/AdminMail' element={<AdminMail />} />
          <Route path='/UserAdminMail' element={<UserAdminMail />} />
          <Route path='/UserList' element={<UserList />} />
          <Route path='/AdminMailFull' element={<AdminMailFull />} />
          <Route path='/AdminUserList' element={<AdminUserList />} />
                <Route path='/AdminRole' element={<AdminRole />} />
          <Route path='/List' element={<List />} />
          <Route path='/AddAdmin' element={<AddAdmin />} />
          <Route path='/AddUser' element={<AddUser />} />
          <Route path='/AdminAdd' element={<AdminAdd />} />
          <Route path='/SendMail' element={<SendMail />} />
          <Route path='/UserSendMail' element={<UserSendMail />} />       
          <Route path='/AllAsses' element={<AllAsses />} />
          <Route path='/Funding' element={<Funding />} />
          <Route path='/Customer' element={<Customer />} />
          <Route path='/AdminFull' element={<AdminFull />} />
          <Route path='/HealthReport' element={<HealthReport />} />
          <Route path='/HealthR' element={<HealthReportFin />} />
          <Route path='/Poor' element={<PoorSales />} />
          <Route path='/Concept' element={<Concept />} />
          <Route path='/StartUp' element={<StartUp />} />
          <Route path='/Investment' element={<Investment />} />
          <Route path='/NoMoney' element={<NoMoney />} />
          <Route path='/PieChart' element={<PChart />} />
          <Route path='/BarChart' element={<NewBar />} />
          <Route path='/Bar' element={<ConceptBar />} />
          <Route path='/Bar2' element={<StructureBar />} />
          <Route path='/Structure' element={<Structure />} />
          <Route path='/HowToBootstrap' element={<BootstrapBlog />} />
          <Route path='/BarStructure' element={<BarStructure />} />
          <Route path='/crowdFunding' element={<CrowdFunding />} />
          <Route path='/HowToBootstrap' element={<BootstrapBlog />} />
          <Route path='/FiveTips' element={<FiveTips />} />
          <Route path='/CommonMistakes' element={<CommonMistakes />} />
          <Route path='/SearchResults' element={<SearchResult />} />
        </Routes>
      </Router>
    </div>
  );
}

export default App;